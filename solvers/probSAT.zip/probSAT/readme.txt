----------------------------------------------------------
probSAT v2014 
Authors: Adrian Balint
Ulm University - Institute of Theoretical Computer Science 
2014
----------------------------------------------------------

Usage of probSAT:
./probSAT <DIMACS CNF instance> <seed>
