#!/bin/sh

cd smallsat/simp
make rs
cp smallsat_static ../../bin/smallsat

