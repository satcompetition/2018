#!/bin/bash

set -e
set -x

(
cd m4ri-20140914
make clean
rm -rf .libs
rm -rf myinstall
)

rm -rf build
rm -f bin/crypto*
rm -f ./*.tar.gz
rm -f ./*.zip
rm -rf myinstall

(
cd bin
cp "${1}" starexec_run_default
)

tar czvf "cmsat55_${1}.tar.gz" ./*
