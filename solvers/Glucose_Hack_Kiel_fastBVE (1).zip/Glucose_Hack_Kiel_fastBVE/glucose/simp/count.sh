for i in $(find .. -type f | grep -e "cc$" -e "h$" | grep -v Main ); do 
	echo "Checking "$i
	shortName=$(echo $i | sed -e "s/.*\///g")
	other=$(find ../../glucose-3.0/ -name $shortName)
	../../../editdistance/editdistance $i $other
done
