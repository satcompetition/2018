/*
 * ControllerInterface.cc
 *
 *  Created on: 03.09.2017
 *      Author: markus
 */

#include <candy/sonification/ControllerInterface.h>

ControllerInterface::ControllerInterface() {
	// TODO Auto-generated constructor stub

}

ControllerInterface::~ControllerInterface() {
	// TODO Auto-generated destructor stub
}

