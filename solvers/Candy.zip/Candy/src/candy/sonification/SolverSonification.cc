/*
 * SolverSonification.cc
 *
 *  Created on: Jan 30, 2017
 *      Author: markus
 */

#include <candy/sonification/SolverSonification.h>

SolverSonification::SolverSonification()
 : Sonification() {

}

SolverSonification::SolverSonification(int port)
 : Sonification(port) {

}

SolverSonification::SolverSonification(const char* address, int port)
 : Sonification(address, port) {

}

SolverSonification::~SolverSonification() { }


void SolverSonification::start(int nVars, int nClauses) {
  sendNumber("/start", 1);
  sendNumber("/variables", nVars);
  sendNumber("/clauses", nClauses);
}

void SolverSonification::stop(int sat) {
  sendNumber("/stop", sat);
}

void SolverSonification::restart() {
  sendNumber("/restart", 1);
}

void SolverSonification::decisionLevel(int level, int delay = 0) {
  scheduleSendNumber("/decision", level, delay);
}

void SolverSonification::conflictLevel(int level) {
  sendNumber("/conflict", level);
}

void SolverSonification::assignmentLevel(int level) {
  sendNumber("/assignments", level);
}

void SolverSonification::learntSize(int size) {
  sendNumber("/learnt", size);
}
