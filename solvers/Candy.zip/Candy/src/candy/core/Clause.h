/*
 * Clause.h
 *
 *  Created on: Feb 15, 2017
 *      Author: markus
 */

#ifndef SRC_CANDY_CORE_CLAUSE_H_
#define SRC_CANDY_CORE_CLAUSE_H_

#include "candy/core/SolverTypes.h"
#include <candy/core/Statistics.h>
#include <iostream>

namespace Candy {

// bits 0..11
#define BITS_LBD 12
#define LBD_MASK (static_cast<uint16_t>(4095))

#define SELECTABLE_BIT 12
#define LEARNT_BIT 13
#define DELETED_BIT 14
#define FROZEN_BIT 15

class Clause {
    uint16_t length;
    uint16_t header;

    float activity_;

    Lit literals[1];

public:
    Clause(const std::vector<Lit>& list, uint16_t lbd) {
        copyLiterals(list.begin(), list.end(), literals);
        length = static_cast<decltype(length)>(list.size());
        header = 0;
        setLearnt(true); // only learnts have lbd
        setLBD(lbd);
        activity_ = 0;
        assert(std::unique(begin(), end()) == end());
    }

    Clause(std::initializer_list<Lit> list) {
        copyLiterals(list.begin(), list.end(), literals);
        length = static_cast<decltype(length)>(list.size());
        header = 0; // all flags false; lbd=0
        activity_ = 0;
    }

    Clause(const std::vector<Lit>& list) {
        copyLiterals(list.begin(), list.end(), literals);
        length = static_cast<decltype(length)>(list.size());
        header = 0; // not frozen, not deleted and not learnt; lbd=0
        activity_ = 0;
    }

    template<typename Iterator>
    Clause(Iterator begin, Iterator end) {
        copyLiterals(begin, end, literals);
        length = static_cast<decltype(length)>(std::distance(begin, end));
        header = 0; // not frozen, not deleted and not learnt; lbd=0
        activity_ = 0;
    }

    Clause(const Clause& clause) {
        copyLiterals(clause.begin(), clause.end(), literals);
        length = clause.length;
        header = clause.header;
        activity_ = clause.activity_;
    }

    ~Clause();

    //void* operator new (std::size_t size) = delete;
    void operator delete (void* p) = delete;

    typedef Lit* iterator;
    typedef const Lit* const_iterator;

    inline Lit& operator [](int i) {
        return literals[i];
    }

    inline const Lit operator [](int i) const {
        return literals[i];
    }

    inline const_iterator begin() const {
        return literals;
    }

    inline const_iterator end() const {
        return literals + length;
    }

    inline iterator begin() {
        return literals;
    }

    inline iterator end() {
        return literals + length;
    }

    inline uint16_t size() const {
        return length;
    }

    inline const Lit first() const {
        return literals[0];
    }

    inline const Lit second() const {
        return literals[1];
    }

    inline const Lit back() const {
        return literals[length-1];
    }

    bool contains(const Lit lit) const;
    bool contains(const Var var) const;

    void printDIMACS() const;
    void printDIMACS(std::vector<lbool> values) const;

    inline void swap(uint16_t pos1, uint16_t pos2) {
        assert(pos1 < length && pos2 < length);
        Lit tmp = literals[pos1];
        literals[pos1] = literals[pos2];
        literals[pos2] = tmp;
    }

    inline bool isLearnt() const {
        return (header >> LEARNT_BIT) & 1;
    }

    inline void setLearnt(bool flag) {
        header = (header & ~(1 << LEARNT_BIT)) | ((flag ? 1 : 0) << LEARNT_BIT);
    }

    inline bool isSelectable() const {
        return (header >> SELECTABLE_BIT) & 1;
    }

    inline void setSelectable(bool flag) {
        header = (header & ~(1 << SELECTABLE_BIT)) | ((flag ? 1 : 0) << SELECTABLE_BIT);
    }

    inline bool isFrozen() const {
        return (header >> FROZEN_BIT) & 1;
    }

    inline void setFrozen(bool flag) {
        header = (header & ~(1 << FROZEN_BIT)) | ((flag ? 1 : 0) << FROZEN_BIT);
    }

    inline bool isDeleted() const {
        return (header >> DELETED_BIT) & 1;
    }

    inline void setDeleted() {
        header |= 1 << DELETED_BIT;
    }

    inline uint16_t getLBD() const {
        return header & LBD_MASK;
    }

    inline void setLBD(uint16_t i) {
        uint16_t flags = header & ~LBD_MASK;
        header = std::min(i, LBD_MASK);
        header |= flags;
    }

    inline float& activity() {
        return activity_;
    }

    inline uint16_t getHeader() const {
        return header;
    }

    /**
     *  subsumes : (other : const Clause&)  ->  Lit
     *
     *  Description:
     *       Checks if clause subsumes 'other', and at the same time, if it can be used to simplify 'other'
     *       by subsumption resolution.
     *
     *    Result:
     *       lit_Error  - No subsumption or simplification
     *       lit_Undef  - Clause subsumes 'other'
     *       p          - The literal p can be deleted from 'other'
     */
    inline Lit subsumes(const Clause& other) const {
        if (other.size() < size()) {
            return lit_Error;
        }

        Lit ret = lit_Undef;

        for (Lit c : *this) {
            // search for c or ~c
            for (Lit d : other) {
                if (c == d) {
                    goto ok;
                }
                else if (ret == lit_Undef && c == ~d) {
                    ret = c;
                    goto ok;
                }
            }
            // did not find it
            return lit_Error;
            ok: ;
        }

        return ret;
    }


    inline void strengthen(Lit p) {
        if (std::remove(begin(), end(), p) != end()) {
            --length;
        }
    }

    void setSize(uint16_t size) {//use only if you know what you are doing (only to be used after strengthen calls)
        length = size;
    }

private:
    template<typename InputIterator>
    inline void copyLiterals(InputIterator srcBegin, InputIterator srcEnd, Lit* target) {
        for(InputIterator srcIter = srcBegin; srcIter != srcEnd; ++srcIter) {
            *target = *srcIter;
            ++target;
        }
    }
};

} /* namespace Candy */

#endif /* SRC_CANDY_CORE_CLAUSE_H_ */
