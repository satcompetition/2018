/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#include "paramgraph.h"
#ifdef SPECS_PARAMGRAPH

void params_intern_appendMpUR_unconditional(uint32_t GUIDEONID, char* parName){
	params_intern_appendONode(GUIDEONID, "mpIi");
		params_intern_appendANode(currNID-1, "mpIi", SPECS_DTYPE_R, PARAM_FUZZMIN_MPII, PARAM_FUZZMAX_MPII);
	params_intern_appendONode(GUIDEONID, "mpIj");
		params_intern_appendANode(currNID-1, "mpIj", SPECS_DTYPE_R, PARAM_FUZZMIN_MPIJ, PARAM_FUZZMAX_MPIJ);
	params_intern_appendONode(GUIDEONID, "mpPkappa");
		params_intern_appendANode(currNID-1, "mpPkappa", SPECS_DTYPE_R, PARAM_FUZZMIN_MPPKAPPA, PARAM_FUZZMAX_MPPKAPPA);
	params_intern_appendONode(GUIDEONID, "mpPeta");
		params_intern_appendANode(currNID-1, "mpPeta", SPECS_DTYPE_R, PARAM_FUZZMIN_MPPETA, PARAM_FUZZMAX_MPPETA);
	params_intern_appendONode(GUIDEONID, "mpPtau");
		params_intern_appendANode(currNID-1, "mpPtau", SPECS_DTYPE_R, PARAM_FUZZMIN_MPPTAU, PARAM_FUZZMAX_MPPTAU);
	params_intern_appendONode(GUIDEONID, "mpPpsi");
		params_intern_appendANode(currNID-1, "mpPpsi", SPECS_DTYPE_R, PARAM_FUZZMIN_MPPPSI, PARAM_FUZZMAX_MPPPSI);
	params_intern_appendONode(GUIDEONID, "mpMaxConvergenceDiff");
		params_intern_appendANode(currNID-1, "mpMaxConvergenceDiff", SPECS_DTYPE_R, PARAM_FUZZMIN_MPMAXCONVERGENCEDIFF, PARAM_FUZZMAX_MPMAXCONVERGENCEDIFF);

}

void params_intern_appendMpForGuideGENIEMPCDCL(uint32_t GUIDEONID){
	params_intern_appendMpUR_unconditional(GUIDEONID, "mpUpdateRule");
}

void params_intern_appendMpForGuideGENIEMPSLS(uint32_t GUIDEONID){
	params_intern_appendMpUR_unconditional(GUIDEONID, "mpUpdateRule");

}

void params_intern_appendMpForGuideGENIEMPDECIMATE(uint32_t GUIDEONID){
	params_intern_appendMpUR_unconditional(GUIDEONID, "mpUpdateRule");

}

void params_intern_appendMpForGuideGENIEMPSLSADA(uint32_t GUIDEONID){
	params_intern_appendMpUR_unconditional(GUIDEONID, "mpUpdateRule");

}

#endif
