/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#ifndef G_GENIEMPDECIMATE_H_
#define G_GENIEMPDECIMATE_H_

#include "../guidance.h"

void guide_geniempdecimate_printHelp();
void guide_geniempdecimate_apply(int, char**);
void guide_geniempdecimate_enforceAfterAdaptation();

#endif /* G_GENIEMPDECIMATE_H_ */
