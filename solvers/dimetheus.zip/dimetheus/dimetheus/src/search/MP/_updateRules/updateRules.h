/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#ifndef UPDATERULES_H_
#define UPDATERULES_H_

#include "../mp.h"

#define MP_UPDATERULE_MINVALUE 6
#define MP_UPDATERULE_MAXVALUE 10

#define MP_UPDATERULE_L0_BP 6				//Level 0: Belief Propagation.
#include "ur_l0_bp.h"

#define MP_UPDATERULE_L0_SP 7				//Level 0: Survey Propagation.
#include "ur_l0_sp.h"

#define MP_UPDATERULE_L0_EMBPG 8			//Level 0: Expectation Maximization BP Global.
#include "ur_l0_embpg.h"

#define MP_UPDATERULE_L0_EMSPG 9			//Level 0: Expectation Maximization SP Global.
#include "ur_l0_emspg.h"

#define MP_UPDATERULE_L2_4_IJMPP 10			//Level 2-: ijMPP.
#include "ur_l2_4_ijmpp.h"

static inline void mp_updateRules_printHelp(){
	mp_updateRule_L0_BP_printHelp();
	mp_updateRule_L0_SP_printHelp();
	mp_updateRule_L0_EMBPG_printHelp();
	mp_updateRule_L0_EMSPG_printHelp();
	mp_updateRule_L2_4_IJMPP_printHelp();
}

//Methods that are provided by this module.
static inline void mp_extern_updateRules_printNamesAndIDs(char* prefix){
	printf("%s MP-UPDATE-RULES: MP_UPDATERULE_L0_BP %d\n", prefix, MP_UPDATERULE_L0_BP);
	printf("%s MP-UPDATE-RULES: MP_UPDATERULE_L0_SP %d\n", prefix, MP_UPDATERULE_L0_SP);
	printf("%s MP-UPDATE-RULES: MP_UPDATERULE_L0_EMBPG %d\n", prefix, MP_UPDATERULE_L0_EMBPG);
	printf("%s MP-UPDATE-RULES: MP_UPDATERULE_L0_EMSPG %d\n", prefix, MP_UPDATERULE_L0_EMSPG);
	printf("%s MP-UPDATE-RULES: MP_UPDATERULE_L2_4_IJMPP %d\n", prefix, MP_UPDATERULE_L2_4_IJMPP);
}

void (*mp_updateRule_prepare)();		//This points to the prepare methods of the message update rule used.
void (*mp_updateRule_msgUpdate)();		//This points to one of the message passing update rules that are available.
void (*mp_updateRule_computeBias)();	//This points to one of the message passing bias computations that are available.

//Methods to initialize this module (are being called by the one who wants to use the above methods).
void mp_extern_updateRules_switch(int32_t);//Use to switch the update rule without re-initializing the whole MP module.
void mp_updateRules_resetPlugin();
void mp_updateRules_initPlugin();
void mp_updateRules_disposePlugin();

#endif /* UPDATERULES_H_ */
