/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#ifndef SS_GENIEMPDECIMATE_H_
#define SS_GENIEMPDECIMATE_H_

#include "searchStrategies.h"

uint32_t search_strategy_geniempdecimate_midBlockSize;		//The number of variables that is to be assigned at once by decimation.
uint32_t search_strategy_geniempdecimate_numToAssign;		//The number of literals in the assignment array.
uint32_t* search_strategy_geniempdecimate_nextToAssign;		//An array holding the next variables to assign in the right order.

void search_strategy_geniempdecimate_printHelp();			//Show strategy help.

void search_strategy_geniempdecimate_reset();				//Reset everything for this strategy.
void search_strategy_geniempdecimate_init();				//Initialize everything for this strategy.
void search_strategy_geniempdecimate_dispose();				//Dispose everything for this strategy.

void search_strategy_geniempdecimate_aquireNextVariables();	//Adds the highest biased variables into the queue with opposite
															//ordering (worst of the best is first).
void search_strategy_geniempdecimate_orderToAssign();		//Adds the variables from the queue to the array with right order.
int32_t search_strategy_geniempdecimate_assignOrdered();	//Assigns the ordered variables.

void search_strategy_geniempdecimate_execute();				//Execute the search.

#endif /* SS_GENIEMPDECIMATE_H_ */
