/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#ifndef AR_GENIEMPCDCL_H_
#define AR_GENIEMPCDCL_H_

#include "abortRules.h"

uint32_t cdcl_abortRule_geniempcdcl_lastCheckedLearned;
uint32_t cdcl_abortRule_geniempcdcl_lastNumUnits;

void cdcl_abortRule_geniempcdcl_printHelp();
void cdcl_abortRule_geniempcdcl_prepare();
uint32_t cdcl_abortRule_geniempcdcl_check();
void cdcl_abortRule_geniempcdcl_signalMaintenance();
void cdcl_abortRule_geniempcdcl_signalRestart();


#endif /* AR_GENIEMPCDCL_H_ */
