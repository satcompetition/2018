/*	DIMETHEUS SAT SOLVER
 * 	Author:		Oliver Gableske	(oliver@gableske.net)
 *	Website:	http://www.gableske.net/dimetheus
 *  License:	See ./doc/license.txt
 */

#ifndef LICENSE_H_
#define LICENSE_H_

#define DIMETHEUS_LICENSE_HASH "fpoBd89Devo8VehsQEP1JmJBP/SHVXZTFl3HTp39RHXLHb4rXGVliDyKQRRQ06ikBKaqvKrDpAqNqDRC/JzVJB60YPl/yRa+mU9Yu1mQEm07eVggdFC5cKDxzrEZICujKLXJRNGSmwjnugvWHmbADDv6NeBPffPg4+oKaV9Ik7w="

#endif /* LICENSE_H_ */
