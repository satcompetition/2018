/* DIMETHEUS SAT SOLVER
*  Author:  Oliver Gableske (oliver@gableske.net)
*  Info:    This file was generated automatically by randforgen.sh
*  Website: http://www.gableske.net/dimetheus
*  License: See ./doc/license.txt
*/

#include "randomforest_crafted.h"

#define RANDOMFOREST_CRAFTED_NUMCHARS 26
const char* randomforest_crafted_characters = "abcdefghijklmnopqrstuvwxyz";
char* randomforest_crafted_treestring;

float_ty randomforest_crafted_getFattValueFromID(uint32_t ID){
    float_ty result = ZERO;

    switch(ID){
        case 0: result = MAIN_GET_FATT_N(); break;
        case 1: result = MAIN_GET_FATT_M(); break;
        case 2: result = MAIN_GET_FATT_R(); break;
        case 3: result = MAIN_GET_FATT_INITASS(); break;
        case 4: result = MAIN_GET_FATT_INITDIS(); break;
        case 5: result = MAIN_GET_FATT_INITPUREPOS(); break;
        case 6: result = MAIN_GET_FATT_INITPURENEG(); break;
        case 7: result = MAIN_GET_FATT_VCG_VNODEDEGREE_MIN(); break;
        case 8: result = MAIN_GET_FATT_VCG_VNODEDEGREE_MAX(); break;
        case 9: result = MAIN_GET_FATT_VCG_VNODEDEGREE_MEAN(); break;
        case 10: result = MAIN_GET_FATT_VCG_VNODEDEGREE_MEDIAN(); break;
        case 11: result = MAIN_GET_FATT_VCG_VNODEDEGREE_SENT(); break;
        case 12: result = MAIN_GET_FATT_VCG_VNODEDEGREE_RENT(); break;
        case 13: result = MAIN_GET_FATT_VCG_VNODEDEGREE_MENT(); break;
        case 14: result = MAIN_GET_FATT_VCG_VNODEDEGREE_STDDEV(); break;
        case 15: result = MAIN_GET_FATT_VCG_VNODEDEGREE_PGFA(); break;
        case 16: result = MAIN_GET_FATT_VCG_VNODEDEGREE_PGFB(); break;
        case 17: result = MAIN_GET_FATT_VCG_VNODEDEGREE_PGFC(); break;
        case 18: result = MAIN_GET_FATT_VCG_CNODEDEGREE_MIN(); break;
        case 19: result = MAIN_GET_FATT_VCG_CNODEDEGREE_MAX(); break;
        case 20: result = MAIN_GET_FATT_VCG_CNODEDEGREE_MEAN(); break;
        case 21: result = MAIN_GET_FATT_VCG_CNODEDEGREE_MEDIAN(); break;
        case 22: result = MAIN_GET_FATT_VCG_CNODEDEGREE_SENT(); break;
        case 23: result = MAIN_GET_FATT_VCG_CNODEDEGREE_RENT(); break;
        case 24: result = MAIN_GET_FATT_VCG_CNODEDEGREE_MENT(); break;
        case 25: result = MAIN_GET_FATT_VCG_CNODEDEGREE_STDDEV(); break;
        case 26: result = MAIN_GET_FATT_VCG_CNODEDEGREE_PGFA(); break;
        case 27: result = MAIN_GET_FATT_VCG_CNODEDEGREE_PGFB(); break;
        case 28: result = MAIN_GET_FATT_VCG_CNODEDEGREE_PGFC(); break;
        case 29: result = MAIN_GET_FATT_VCG_MAYBERAND(); break;
        case 30: result = MAIN_GET_FATT_VG_ESTAVGNDEG_MIN(); break;
        case 31: result = MAIN_GET_FATT_VG_ESTAVGNDEG_MAX(); break;
        case 32: result = MAIN_GET_FATT_VG_ESTAVGNDEG_MEAN(); break;
        case 33: result = MAIN_GET_FATT_VG_ESTAVGNDEG_MEDIAN(); break;
        case 34: result = MAIN_GET_FATT_VG_ESTAVGNDEG_SENT(); break;
        case 35: result = MAIN_GET_FATT_VG_ESTAVGNDEG_RENT(); break;
        case 36: result = MAIN_GET_FATT_VG_ESTAVGNDEG_MENT(); break;
        case 37: result = MAIN_GET_FATT_VG_ESTAVGNDEG_STDDEV(); break;
        case 38: result = MAIN_GET_FATT_VG_ESTAVGNDEG_PGFA(); break;
        case 39: result = MAIN_GET_FATT_VG_ESTAVGNDEG_PGFB(); break;
        case 40: result = MAIN_GET_FATT_VG_ESTAVGNDEG_PGFC(); break;
        case 41: result = MAIN_GET_FATT_VG_VNODEDEGREE_MIN(); break;
        case 42: result = MAIN_GET_FATT_VG_VNODEDEGREE_MAX(); break;
        case 43: result = MAIN_GET_FATT_VG_VNODEDEGREE_MEAN(); break;
        case 44: result = MAIN_GET_FATT_VG_VNODEDEGREE_MEDIAN(); break;
        case 45: result = MAIN_GET_FATT_VG_VNODEDEGREE_SENT(); break;
        case 46: result = MAIN_GET_FATT_VG_VNODEDEGREE_RENT(); break;
        case 47: result = MAIN_GET_FATT_VG_VNODEDEGREE_MENT(); break;
        case 48: result = MAIN_GET_FATT_VG_VNODEDEGREE_STDDEV(); break;
        case 49: result = MAIN_GET_FATT_VG_VNODEDEGREE_PGFA(); break;
        case 50: result = MAIN_GET_FATT_VG_VNODEDEGREE_PGFB(); break;
        case 51: result = MAIN_GET_FATT_VG_VNODEDEGREE_PGFC(); break;
        case 52: result = MAIN_GET_FATT_VG_NUMCOMP(); break;
        case 53: result = MAIN_GET_FATT_VG_VCOMPSIZES_MIN(); break;
        case 54: result = MAIN_GET_FATT_VG_VCOMPSIZES_MAX(); break;
        case 55: result = MAIN_GET_FATT_VG_VCOMPSIZES_MEAN(); break;
        case 56: result = MAIN_GET_FATT_VG_VCOMPSIZES_MEDIAN(); break;
        case 57: result = MAIN_GET_FATT_VG_VCOMPSIZES_SENT(); break;
        case 58: result = MAIN_GET_FATT_VG_VCOMPSIZES_RENT(); break;
        case 59: result = MAIN_GET_FATT_VG_VCOMPSIZES_MENT(); break;
        case 60: result = MAIN_GET_FATT_VG_VCOMPSIZES_STDDEV(); break;
        case 61: result = MAIN_GET_FATT_VG_VCOMPSIZES_PGFA(); break;
        case 62: result = MAIN_GET_FATT_VG_VCOMPSIZES_PGFB(); break;
        case 63: result = MAIN_GET_FATT_VG_VCOMPSIZES_PGFC(); break;
        case 64: result = MAIN_GET_FATT_VG_VCOMPDIAMS_MIN(); break;
        case 65: result = MAIN_GET_FATT_VG_VCOMPDIAMS_MAX(); break;
        case 66: result = MAIN_GET_FATT_VG_VCOMPDIAMS_MEAN(); break;
        case 67: result = MAIN_GET_FATT_VG_VCOMPDIAMS_MEDIAN(); break;
        case 68: result = MAIN_GET_FATT_VG_VCOMPDIAMS_SENT(); break;
        case 69: result = MAIN_GET_FATT_VG_VCOMPDIAMS_RENT(); break;
        case 70: result = MAIN_GET_FATT_VG_VCOMPDIAMS_MENT(); break;
        case 71: result = MAIN_GET_FATT_VG_VCOMPDIAMS_STDDEV(); break;
        case 72: result = MAIN_GET_FATT_VG_VCOMPDIAMS_PGFA(); break;
        case 73: result = MAIN_GET_FATT_VG_VCOMPDIAMS_PGFB(); break;
        case 74: result = MAIN_GET_FATT_VG_VCOMPDIAMS_PGFC(); break;
        case 75: result = MAIN_GET_FATT_VG_NUMAP(); break;
        case 76: result = MAIN_GET_FATT_CG_CNODEDEGREE_MIN(); break;
        case 77: result = MAIN_GET_FATT_CG_CNODEDEGREE_MAX(); break;
        case 78: result = MAIN_GET_FATT_CG_CNODEDEGREE_MEAN(); break;
        case 79: result = MAIN_GET_FATT_CG_CNODEDEGREE_MEDIAN(); break;
        case 80: result = MAIN_GET_FATT_CG_CNODEDEGREE_SENT(); break;
        case 81: result = MAIN_GET_FATT_CG_CNODEDEGREE_RENT(); break;
        case 82: result = MAIN_GET_FATT_CG_CNODEDEGREE_MENT(); break;
        case 83: result = MAIN_GET_FATT_CG_CNODEDEGREE_STDDEV(); break;
        case 84: result = MAIN_GET_FATT_CG_CNODEDEGREE_PGFA(); break;
        case 85: result = MAIN_GET_FATT_CG_CNODEDEGREE_PGFB(); break;
        case 86: result = MAIN_GET_FATT_CG_CNODEDEGREE_PGFC(); break;
        case 87: result = MAIN_GET_FATT_CG_AVGDEGPERLIT_MIN(); break;
        case 88: result = MAIN_GET_FATT_CG_AVGDEGPERLIT_MAX(); break;
        case 89: result = MAIN_GET_FATT_CG_AVGDEGPERLIT_MEAN(); break;
        case 90: result = MAIN_GET_FATT_CG_AVGDEGPERLIT_MEDIAN(); break;
        case 91: result = MAIN_GET_FATT_CG_AVGDEGPERLIT_SENT(); break;
        case 92: result = MAIN_GET_FATT_CG_AVGDEGPERLIT_RENT(); break;
        case 93: result = MAIN_GET_FATT_CG_AVGDEGPERLIT_MENT(); break;
        case 94: result = MAIN_GET_FATT_CG_AVGDEGPERLIT_STDDEV(); break;
        case 95: result = MAIN_GET_FATT_CG_AVGDEGPERLIT_PGFA(); break;
        case 96: result = MAIN_GET_FATT_CG_AVGDEGPERLIT_PGFB(); break;
        case 97: result = MAIN_GET_FATT_CG_AVGDEGPERLIT_PGFC(); break;
        case 98: result = MAIN_GET_FATT_B_VLITBALANCE_MIN(); break;
        case 99: result = MAIN_GET_FATT_B_VLITBALANCE_MAX(); break;
        case 100: result = MAIN_GET_FATT_B_VLITBALANCE_MEAN(); break;
        case 101: result = MAIN_GET_FATT_B_VLITBALANCE_MEDIAN(); break;
        case 102: result = MAIN_GET_FATT_B_VLITBALANCE_SENT(); break;
        case 103: result = MAIN_GET_FATT_B_VLITBALANCE_RENT(); break;
        case 104: result = MAIN_GET_FATT_B_VLITBALANCE_MENT(); break;
        case 105: result = MAIN_GET_FATT_B_VLITBALANCE_STDDEV(); break;
        case 106: result = MAIN_GET_FATT_B_VLITBALANCE_PGFA(); break;
        case 107: result = MAIN_GET_FATT_B_VLITBALANCE_PGFB(); break;
        case 108: result = MAIN_GET_FATT_B_VLITBALANCE_PGFC(); break;
        case 109: result = MAIN_GET_FATT_B_CLITBALANCE_MIN(); break;
        case 110: result = MAIN_GET_FATT_B_CLITBALANCE_MAX(); break;
        case 111: result = MAIN_GET_FATT_B_CLITBALANCE_MEAN(); break;
        case 112: result = MAIN_GET_FATT_B_CLITBALANCE_MEDIAN(); break;
        case 113: result = MAIN_GET_FATT_B_CLITBALANCE_SENT(); break;
        case 114: result = MAIN_GET_FATT_B_CLITBALANCE_RENT(); break;
        case 115: result = MAIN_GET_FATT_B_CLITBALANCE_MENT(); break;
        case 116: result = MAIN_GET_FATT_B_CLITBALANCE_STDDEV(); break;
        case 117: result = MAIN_GET_FATT_B_CLITBALANCE_PGFA(); break;
        case 118: result = MAIN_GET_FATT_B_CLITBALANCE_PGFB(); break;
        case 119: result = MAIN_GET_FATT_B_CLITBALANCE_PGFC(); break;
        case 120: result = MAIN_GET_FATT_B_CSIZE2(); break;
        case 121: result = MAIN_GET_FATT_B_CSIZE3(); break;
        case 122: result = MAIN_GET_FATT_B_CSIZE4(); break;
        case 123: result = MAIN_GET_FATT_B_CSIZE5(); break;
        case 124: result = MAIN_GET_FATT_B_CSIZE6(); break;
        case 125: result = MAIN_GET_FATT_B_CSIZE7(); break;
        case 126: result = MAIN_GET_FATT_HP_HORNFRAC(); break;
        case 127: result = MAIN_GET_FATT_HP_VHORNFRAC_MIN(); break;
        case 128: result = MAIN_GET_FATT_HP_VHORNFRAC_MAX(); break;
        case 129: result = MAIN_GET_FATT_HP_VHORNFRAC_MEAN(); break;
        case 130: result = MAIN_GET_FATT_HP_VHORNFRAC_MEDIAN(); break;
        case 131: result = MAIN_GET_FATT_HP_VHORNFRAC_SENT(); break;
        case 132: result = MAIN_GET_FATT_HP_VHORNFRAC_RENT(); break;
        case 133: result = MAIN_GET_FATT_HP_VHORNFRAC_MENT(); break;
        case 134: result = MAIN_GET_FATT_HP_VHORNFRAC_STDDEV(); break;
        case 135: result = MAIN_GET_FATT_HP_VHORNFRAC_PGFA(); break;
        case 136: result = MAIN_GET_FATT_HP_VHORNFRAC_PGFB(); break;
        case 137: result = MAIN_GET_FATT_HP_VHORNFRAC_PGFC(); break;
        case 138: result = MAIN_GET_FATT_HP_CHORNDIST_MIN(); break;
        case 139: result = MAIN_GET_FATT_HP_CHORNDIST_MAX(); break;
        case 140: result = MAIN_GET_FATT_HP_CHORNDIST_MEAN(); break;
        case 141: result = MAIN_GET_FATT_HP_CHORNDIST_MEDIAN(); break;
        case 142: result = MAIN_GET_FATT_HP_CHORNDIST_SENT(); break;
        case 143: result = MAIN_GET_FATT_HP_CHORNDIST_RENT(); break;
        case 144: result = MAIN_GET_FATT_HP_CHORNDIST_MENT(); break;
        case 145: result = MAIN_GET_FATT_HP_CHORNDIST_STDDEV(); break;
        case 146: result = MAIN_GET_FATT_HP_CHORNDIST_PGFA(); break;
        case 147: result = MAIN_GET_FATT_HP_CHORNDIST_PGFB(); break;
        case 148: result = MAIN_GET_FATT_HP_CHORNDIST_PGFC(); break;
        case 149: result = MAIN_GET_FATT_BIG_VNODEDEGREE_MIN(); break;
        case 150: result = MAIN_GET_FATT_BIG_VNODEDEGREE_MAX(); break;
        case 151: result = MAIN_GET_FATT_BIG_VNODEDEGREE_MEAN(); break;
        case 152: result = MAIN_GET_FATT_BIG_VNODEDEGREE_MEDIAN(); break;
        case 153: result = MAIN_GET_FATT_BIG_VNODEDEGREE_SENT(); break;
        case 154: result = MAIN_GET_FATT_BIG_VNODEDEGREE_RENT(); break;
        case 155: result = MAIN_GET_FATT_BIG_VNODEDEGREE_MENT(); break;
        case 156: result = MAIN_GET_FATT_BIG_VNODEDEGREE_STDDEV(); break;
        case 157: result = MAIN_GET_FATT_BIG_VNODEDEGREE_PGFA(); break;
        case 158: result = MAIN_GET_FATT_BIG_VNODEDEGREE_PGFB(); break;
        case 159: result = MAIN_GET_FATT_BIG_VNODEDEGREE_PGFC(); break;
        case 160: result = MAIN_GET_FATT_BIG_VFRAC(); break;
        case 161: result = MAIN_GET_FATT_BIG_NUMCOMP(); break;
        case 162: result = MAIN_GET_FATT_BIG_VCOMPSIZES_MIN(); break;
        case 163: result = MAIN_GET_FATT_BIG_VCOMPSIZES_MAX(); break;
        case 164: result = MAIN_GET_FATT_BIG_VCOMPSIZES_MEAN(); break;
        case 165: result = MAIN_GET_FATT_BIG_VCOMPSIZES_MEDIAN(); break;
        case 166: result = MAIN_GET_FATT_BIG_VCOMPSIZES_SENT(); break;
        case 167: result = MAIN_GET_FATT_BIG_VCOMPSIZES_RENT(); break;
        case 168: result = MAIN_GET_FATT_BIG_VCOMPSIZES_MENT(); break;
        case 169: result = MAIN_GET_FATT_BIG_VCOMPSIZES_STDDEV(); break;
        case 170: result = MAIN_GET_FATT_BIG_VCOMPSIZES_PGFA(); break;
        case 171: result = MAIN_GET_FATT_BIG_VCOMPSIZES_PGFB(); break;
        case 172: result = MAIN_GET_FATT_BIG_VCOMPSIZES_PGFC(); break;
        case 173: result = MAIN_GET_FATT_BIG_VCOMPDIAMS_MIN(); break;
        case 174: result = MAIN_GET_FATT_BIG_VCOMPDIAMS_MAX(); break;
        case 175: result = MAIN_GET_FATT_BIG_VCOMPDIAMS_MEAN(); break;
        case 176: result = MAIN_GET_FATT_BIG_VCOMPDIAMS_MEDIAN(); break;
        case 177: result = MAIN_GET_FATT_BIG_VCOMPDIAMS_SENT(); break;
        case 178: result = MAIN_GET_FATT_BIG_VCOMPDIAMS_RENT(); break;
        case 179: result = MAIN_GET_FATT_BIG_VCOMPDIAMS_MENT(); break;
        case 180: result = MAIN_GET_FATT_BIG_VCOMPDIAMS_STDDEV(); break;
        case 181: result = MAIN_GET_FATT_BIG_VCOMPDIAMS_PGFA(); break;
        case 182: result = MAIN_GET_FATT_BIG_VCOMPDIAMS_PGFB(); break;
        case 183: result = MAIN_GET_FATT_BIG_VCOMPDIAMS_PGFC(); break;
        case 184: result = MAIN_GET_FATT_BIG_NUMAP(); break;
        case 185: result = MAIN_GET_FATT_UP_POSLITCONFFRAC(); break;
        case 186: result = MAIN_GET_FATT_UP_NEGLITCONFFRAC(); break;
        case 187: result = MAIN_GET_FATT_UP_POSLITUPCOUNT_MIN(); break;
        case 188: result = MAIN_GET_FATT_UP_POSLITUPCOUNT_MAX(); break;
        case 189: result = MAIN_GET_FATT_UP_POSLITUPCOUNT_MEAN(); break;
        case 190: result = MAIN_GET_FATT_UP_POSLITUPCOUNT_MEDIAN(); break;
        case 191: result = MAIN_GET_FATT_UP_POSLITUPCOUNT_SENT(); break;
        case 192: result = MAIN_GET_FATT_UP_POSLITUPCOUNT_RENT(); break;
        case 193: result = MAIN_GET_FATT_UP_POSLITUPCOUNT_MENT(); break;
        case 194: result = MAIN_GET_FATT_UP_POSLITUPCOUNT_STDDEV(); break;
        case 195: result = MAIN_GET_FATT_UP_POSLITUPCOUNT_PGFA(); break;
        case 196: result = MAIN_GET_FATT_UP_POSLITUPCOUNT_PGFB(); break;
        case 197: result = MAIN_GET_FATT_UP_POSLITUPCOUNT_PGFC(); break;
        case 198: result = MAIN_GET_FATT_UP_NEGLITUPCOUNT_MIN(); break;
        case 199: result = MAIN_GET_FATT_UP_NEGLITUPCOUNT_MAX(); break;
        case 200: result = MAIN_GET_FATT_UP_NEGLITUPCOUNT_MEAN(); break;
        case 201: result = MAIN_GET_FATT_UP_NEGLITUPCOUNT_MEDIAN(); break;
        case 202: result = MAIN_GET_FATT_UP_NEGLITUPCOUNT_SENT(); break;
        case 203: result = MAIN_GET_FATT_UP_NEGLITUPCOUNT_RENT(); break;
        case 204: result = MAIN_GET_FATT_UP_NEGLITUPCOUNT_MENT(); break;
        case 205: result = MAIN_GET_FATT_UP_NEGLITUPCOUNT_STDDEV(); break;
        case 206: result = MAIN_GET_FATT_UP_NEGLITUPCOUNT_PGFA(); break;
        case 207: result = MAIN_GET_FATT_UP_NEGLITUPCOUNT_PGFB(); break;
        case 208: result = MAIN_GET_FATT_UP_NEGLITUPCOUNT_PGFC(); break;
        case 209: result = MAIN_GET_FATT_RW_Q05(); break;
        case 210: result = MAIN_GET_FATT_RW_Q10(); break;
        case 211: result = MAIN_GET_FATT_RW_Q25(); break;
        case 212: result = MAIN_GET_FATT_RW_Q50(); break;
        case 213: result = MAIN_GET_FATT_RW_Q75(); break;
        case 214: result = MAIN_GET_FATT_RW_Q90(); break;
        case 215: result = MAIN_GET_FATT_RW_Q95(); break;
        case 216: result = MAIN_GET_FATT_RW_VWEIGHTS_MIN(); break;
        case 217: result = MAIN_GET_FATT_RW_VWEIGHTS_MAX(); break;
        case 218: result = MAIN_GET_FATT_RW_VWEIGHTS_MEAN(); break;
        case 219: result = MAIN_GET_FATT_RW_VWEIGHTS_MEDIAN(); break;
        case 220: result = MAIN_GET_FATT_RW_VWEIGHTS_SENT(); break;
        case 221: result = MAIN_GET_FATT_RW_VWEIGHTS_RENT(); break;
        case 222: result = MAIN_GET_FATT_RW_VWEIGHTS_MENT(); break;
        case 223: result = MAIN_GET_FATT_RW_VWEIGHTS_STDDEV(); break;
        case 224: result = MAIN_GET_FATT_RW_VWEIGHTS_PGFA(); break;
        case 225: result = MAIN_GET_FATT_RW_VWEIGHTS_PGFB(); break;
        case 226: result = MAIN_GET_FATT_RW_VWEIGHTS_PGFC(); break;
        case 227: result = MAIN_GET_FATT_ELS_NUMC(); break;
        case 228: result = MAIN_GET_FATT_ELS_SIZES_MIN(); break;
        case 229: result = MAIN_GET_FATT_ELS_SIZES_MAX(); break;
        case 230: result = MAIN_GET_FATT_ELS_SIZES_MEAN(); break;
        case 231: result = MAIN_GET_FATT_ELS_SIZES_MEDIAN(); break;
        case 232: result = MAIN_GET_FATT_ELS_SIZES_SENT(); break;
        case 233: result = MAIN_GET_FATT_ELS_SIZES_RENT(); break;
        case 234: result = MAIN_GET_FATT_ELS_SIZES_MENT(); break;
        case 235: result = MAIN_GET_FATT_ELS_SIZES_STDDEV(); break;
        case 236: result = MAIN_GET_FATT_ELS_SIZES_PGFA(); break;
        case 237: result = MAIN_GET_FATT_ELS_SIZES_PGFB(); break;
        case 238: result = MAIN_GET_FATT_ELS_SIZES_PGFC(); break;
        default : result = -1.0; break;
    }

    return result;
}

char *randomforest_crafted_tree_1[34] = {
    "bz0.06531{ba0.76467{fa0.909091{fm2.00509{bm0.756585{bk0.418243{gz0.899821{gb0.999664{hj0.069168{553}fs0.886605{hz0.636976{553}f",
    "k0.353341{553}{552}}{552}}{527}}bh8.36508{fd2.8197{de0.535195{412}{411}}{488}}{411}}aw0.870026{fb7.80071{gj200.5{bl1.24427{fa0.",
    "382184{595}ha0.728812{596}cy570{595}{596}}{595}}{596}}{595}}dw0.358965{ex0.25{428}{430}}dx0.5{406}ee0.858417{431}go0.313607{431",
    "}{432}}ha0.700002{bz0.0295775{ie0.177141{416}if0.666613{437}ai13.5{566}{439}}bx0.236622{bk2.89319{593}{591}}gd1{592}{410}}gz0.9",
    "{do2.66372{az0.604892{bv1.32725{545}db467{ho0.08032{fr0.930446{545}{544}}{545}}gd0.269039{544}{545}}{544}}de2.41986{498}{429}}a",
    "l0.905992{dn0.021112{557}{556}}fy0.921341{fn1.38061{542}{543}}{543}}fv3.40068{fb3.58602{cd1807.5{hw0.229101{am1.93533{502}{569}",
    "}dd9.28147{fs0.883128{570}{569}}dg1.25e-05{573}{574}}gv0.206908{hn0.508248{575}{576}}hz0.226857{hy0.479687{gz0.857572{577}{576}",
    "}{576}}{577}}ez0.191064{en0.950192{fb4.2378{558}fe0.149824{hr9{559}{558}}{559}}dd3.58285{559}{558}}{484}}er0.0773375{dt0.029130",
    "5{fx1.25903{eo0.897154{ga10.1349{fg0.987637{586}{585}}{585}}{585}}{586}}{499}}em0.295882{fv9.46366{en0.948197{580}bw83.9653{eq0",
    ".404749{581}{578}}{580}}id0.154336{ao69.1226{dc3.3291{580}{579}}{580}}{579}}{578}}co14{hy0.397027{ao205.487{co13{415}{425}}{426",
    "}}dd7.74018{417}eo0.92906{424}{418}}io1.31505{bx0.032881{co15.5{422}{421}}{423}}bm0.751657{420}{419}}dz1.5229{cv0.64{bh1.2955{b",
    "l0.0529645{be1.17273{dj102{448}{445}}ab118158{445}{450}}fo0.000165{440}{446}}db495.5{ha0.656{ff0.905041{480}{469}}ec0.957219{56",
    "2}{560}}am0.724945{bo0.624762{443}gi28032{441}bk0.216058{447}{441}}gu4{480}{443}}ha0.576{gh5128{dw0.0083335{az0.52741{de0.00023",
    "3{462}{461}}be1.25557{bn0.762369{456}{479}}{455}}cd400{477}bs107{454}{460}}db1214{cy772{ac554.009{457}{459}}{458}}dx0.0013385{e",
    "j0.000372{453}{464}}du0.001391{479}{463}}gs1.5{dy0.499991{411}bm0.825241{ep0.845193{bn0.647665{fr0.950312{549}{551}}{551}}{549}",
    "}ar0.014523{hz0.02199{550}be1.72619{550}{551}}cz76{551}{549}}fs0.971058{fg0.847512{bp32{547}bo0.598428{dy0.996884{dz0.984991{54",
    "8}{546}}{548}}{547}}bh1.43035{de0.0096465{547}di5{548}{546}}fk0.248962{546}fp0.438907{fv72.5{548}ft97.5{546}{548}}fn0.708632{54",
    "6}bo0.593143{548}{546}}au1.97621{563}{481}}ie0.0002795{az0.638112{co4{ha0.64{ak229.5{gb6.3e-05{dp6.52353{530}{531}}{531}}{529}}",
    "al5.81237{564}dd7.14029{dv0.010309{529}bw26.2023{528}{589}}cd1377.5{589}ff0.900362{589}{529}}bf1.25{bi2.37342{450}fd1.19931{450",
    "}{442}}ek0.005466{448}{442}}aa5200{ej0.0076575{444}cc3000{gj2600{444}{449}}bx4.3e-05{449}cb3400{451}du0.013514{451}{452}}en0.99",
    "9965{452}cp3{468}{451}}ec0.996186{ei0.5{dl25.025{ih0.64241{470}{472}}dy3.32564{471}gi1452.17{429}{427}}cx39{im9.57427{ay0.00261",
    "25{ha0.262144{534}{533}}dc8.5543{do7.88687{536}{537}}ea6.27772{532}{541}}df32.6605{436}co6.5{538}{535}}gz0.255599{554}{555}}dz2",
    ".50158{gc0.001271{gt13{476}{468}}fz1.86394{473}{465}}ah17{df368.204{cy26{475}{466}}{467}}ik426699{478}{474}}fm1.10796{dk275{gy8",
    ".6793{hc122{cd711{hh18.6558{fk0.174145{522}fu9.5{561}{587}}fu28{522}{503}}iv4.5{ek1.24123{438}fv28.2695{592}{555}}{526}}gy5.584",
    "87{gn29.1597{ez0.63162{523}{555}}gv2.67482{fu40{503}{504}}gy4.94592{504}ai120{504}{505}}aa5008.5{cc4199.5{505}ec0.9515{505}{506",
    "}}{506}}im13.7246{hu4.94547{cc14688{507}bq78{435}{508}}dt0.257667{iq0.339079{he0.008122{560}{485}}{561}}gy12.2508{508}{509}}ek1",
    ".56029{fy0.632834{bk0.346286{512}{511}}{510}}eb0.122465{510}{509}}cx26.5{hd0.002718{ce218534{bq350{515}{516}}{517}}hc91950.5{cz",
    "899.5{512}{513}}{514}}bi1.89769{ax0.987598{519}{518}}cd369834{bw39.4019{520}{524}}{521}}bi2.87534{ig0.450094{aa422332{ba0.72793",
    "2{go0.727861{gm0.292482{da92.7611{413}{409}}{590}}aq0.010263{565}ec0.965944{500}bi2.77162{588}{496}}gs12755{fy0.98399{gz0.12709",
    "3{407}{567}}fw2{523}{489}}{434}}{497}}bu0.382497{au2.29091{cm7{ig0.906404{fr0.936071{487}{482}}{482}}{487}}ie0.5{if0.722271{fs0",
    ".898235{557}{556}}{501}}{486}}ac2.48942{gf31.5{433}{439}}dc2.75352{cp7.5{cw0.100001{485}{483}}{485}}iu2{408}{414}}gf45{de2.3015",
    "2{493}al1.54637{ed0.998297{eq0.151163{491}{490}}{492}}hp0.0999165{ev0.0048075{dn5.98694{582}{583}}hu4.44556{im1.591{dw0.171177{",
    "583}{588}}{584}}{583}}hs13.4168{cy66.5{572}dj25.025{573}ha0.656007{572}do9.34224{571}{574}}hd0.022026{587}{588}}bo0.402652{fg0.",
    "998821{495}{496}}fs0.932832{494}jd0.610427{gl0.879624{hm116.336{dl36.5498{524}{525}}{525}}{524}}{524}",
};

char *randomforest_crafted_tree_2[36] = {
    "bn0.639522{bo0.398032{ad3170{da1195.47{er0.124169{gz0.40365{dr0.228768{ba0.639273{484}{409}}ab3356{ic0.101724{ez0.29866{fn1.683",
    "77{483}{485}}{485}}{483}}{499}}hs3.33967{en0.987689{dv0.8{fp0.369175{500}{412}}hm0.175638{gn0.156553{552}ep0.839852{552}{553}}{",
    "552}}gz0.899845{468}{411}}bb0.255227{hm1.38153{dc8.61622{hb0.663316{576}{577}}{577}}{576}}br30.8285{bz0.395236{406}{588}}hz0.22",
    "585{fz0.22921{575}{576}}{575}}eb0.260374{by0.019058{et0.083981{cy10{430}hc42{427}{429}}{428}}fa0.583333{aq0.43426{565}{582}}hi3",
    "4.5{431}hh712.687{bg8.5138{432}{431}}{431}}in0.763314{bb0.466685{584}hw2.54169{584}{583}}er0.161751{cn3.5{581}hp0.001413{581}{5",
    "80}}ha0.608{hs19.3338{580}{579}}{578}}an4.28022{ar0.018364{ig0.0585645{fn1.2912{527}gx0.007715{502}{406}}io0.481203{be3.75203{5",
    "69}ic0.005834{db8699{570}{568}}co3.5{569}{570}}hz0.637155{586}ec0.949155{586}{585}}ax3.18741{hj3.29595{587}{588}}bi8.21223{571}",
    "br34.2098{dl750.052{573}ac3.90313{bk6.12408{572}au6.87114{572}{573}}{573}}gy0.452136{572}{574}}ic0.0005785{fb7.86804{du0.56342{",
    "eb0.0774835{595}dz7.5398{596}{595}}hu0.728542{595}ax0.291407{596}{595}}{595}}fs0.869076{ej4.44597{559}aa1268{558}{559}}{558}}it",
    "10.5{bs139{bc0.333162{417}{418}}ek0.592078{426}az0.785397{et0.098374{425}do9.11165{425}{424}}{424}}fh0.709686{ff0.902683{419}co",
    "16.5{421}{420}}fz1.17177{cw0.006782{498}{423}}{422}}fv0.023656{gd0.998004{bu0.0295105{496}{495}}bz0.992093{ar0.0975785{ew0.7558",
    "29{416}{415}}{433}}{497}}io0.0178715{iv7{bv1.3533{543}fx0.955361{542}al1.56187{542}{543}}{494}}ir0.991592{iv4{ho0.64{iw2{ip1309",
    "08{ha0.612443{593}{594}}bl0.340568{427}{429}}aq0.102585{590}ho0.108311{583}{591}}bj0.0237765{im0.311843{557}bx0.0576225{556}{55",
    "7}}{556}}bu2.95092{ec0.994103{cn7{582}{413}}fy0.036343{491}{490}}cn8{ei0.416666{525}{524}}jb1.94405{524}db360.5{iz0.562122{go0.",
    "687499{524}{525}}{524}}{524}}fv0.0299315{493}hk7.23058{491}{492}}ar0.116795{bv0.740564{dy0.63492{bn0.734448{bu0.0125445{fw22.5{",
    "ie0.505747{cc151.5{cv0.214958{487}cb97.5{487}{482}}{482}}{482}}{563}}db30{561}{486}}bo0.654505{ak268{fh0.704249{fn0.0043{ay0.00",
    "0491{456}{455}}{454}}{477}}aw0.001224{fq0.999997{458}{453}}{457}}bf1.11373{au1.99803{bh1.10986{464}{463}}gg40000{481}{459}}eq0.",
    "999845{az0.514694{461}{460}}be1.1152{462}{479}}en0.975192{gr2{bg1.77857{gq0.0141355{550}ep0.84906{550}{551}}gc0.500001{fq0.9753",
    "18{hf15{549}cd885{551}{549}}ia0.0016615{551}{549}}dx0.5{501}{566}}cv0.337592{ce14913{ja0.303542{414}{567}}{489}}bg1.44205{bz0.0",
    "0091{dy0.999422{bm0.863248{548}{547}}{547}}{546}}dt4{fu57.5{548}fo0.424779{ec0.949758{548}ap2{548}{546}}{546}}{546}}bm0.875498{",
    "dz0.435038{dv0.005814{447}ce25696{441}{447}}bu0.712656{ek0.0003325{441}{443}}{443}}bf1.28295{446}bi1.25163{440}{469}}ir1{ep0.92",
    "5084{fv3.16231{ih0.825{bw6.16593{408}cy6{523}{410}}dc3.35507{ao0.995408{566}hx3.27346{439}{414}}{437}}hm24.9398{gk1.12435{do2.7",
    "4635{an1.37983{545}{544}}fh0.774168{cn6.5{538}{541}}bn0.770932{436}{539}}by0.093267{593}bu3.81909{592}{591}}hc58{hh44.374{ep0.8",
    "43248{bh1.06819{535}{537}}bo0.670491{533}{532}}ga89.3852{540}{534}}gu13{ay0.163773{555}{489}}{554}}fd1.94808{fx2.53383{bw5.3182",
    "5{if0.325641{465}{470}}{471}}fx2.9767{dy2.80944{473}{468}}ec0.999621{476}{467}}dj14{fb3.28032{472}{475}}ho0.0003985{474}hy0.007",
    "848{466}{478}}bm0.879312{dq17.0903{cc5000{eo0.999873{cd3000{cc2800{ah70{444}{480}}{449}}do3.29499{az0.678725{ce3600{451}{452}}e",
    "c0.998521{fr0.999714{452}{451}}{451}}{449}}{444}}em0.018692{br587.479{451}{480}}{452}}dw0.250113{cc2151.5{564}{480}}an1.42138{5",
    "45}{544}}do4.36103{cy84{cb2944{442}{448}}fd1.17878{cy204{aj71.8722{cd3584{445}{450}}{450}}{445}}{442}}fc5.69525{ea4.52546{564}{",
    "528}}ha0.64{aw0.003867{be1.08648{531}{529}}bk5.75077{cc1290{de6.36711{531}{530}}{531}}{530}}ga23.868{cc1375{528}{529}}bf1.31793",
    "{fk0.000446{528}{589}}{589}}gs70{hy0.424212{bv0.500186{ai320{gm1.76803{iu1{560}{582}}{509}}fz0.341661{hi15{510}aa66309.5{511}iq",
    "0.835842{511}{512}}{510}}cd15136.5{hc4262.5{av2.5{au2.01566{fm1.20578{jb1.75{587}{525}}{583}}{582}}an2.43494{438}{407}}br7.3331",
    "2{507}ig0.106852{507}{508}}bc0.422582{bl0.122787{di0.107591{407}{509}}bm0.837974{438}{508}}{508}}im10.4546{br5.82722{iw1.71212{",
    "ah1{439}hc30.5{522}hs5.51596{503}{522}}dm7.33333{526}{523}}ai80{bx0.424138{be1.59091{592}{562}}{503}}{504}}il0.121671{506}{505}",
    "}id0.011132{cc302952{fu320{ic0.0033985{517}{516}}{518}}ac3.32456{ez0.706871{519}el1.25987{518}{519}}dr0.441844{521}{520}}ab2385",
    "50{ai436{az0.957117{ab145852{cc66735{511}{512}}{512}}aa18349{ik13.2777{561}{483}}az0.966904{560}cw0.100001{485}{486}}{513}}hr23",
    "36.5{cn5505{gy24.7524{515}{516}}aq0.430376{435}{434}}{514}",
};

char *randomforest_crafted_tree_3[34] = {
    "eq0.315841{bu0.76582{fy0.01418{jd0.583988{ec0.974137{bw0.073703{aq0.083886{ce98{527}fl0.380952{488}{502}}co7{ic0.103448{ib0.054",
    "233{482}{487}}{482}}if0.75119{ce144{487}{482}}{487}}az0.839145{486}bj0.284637{561}{433}}cc4391.5{ix2{415}ac0.620588{498}{496}}{",
    "497}}fc0.029845{496}fx0.0456015{cp8{500}{501}}{495}}fc0.035636{494}ij8.20642e+13{ix2{in0.251778{hf2{bo0.0540315{595}du0.563559{",
    "fx1.43016{595}bo0.065627{596}{595}}fy1.30481{596}{595}}{557}}fr0.932098{fr0.926317{el1.40328{fm1.80622{552}{553}}ep0.840003{cn2",
    "49{553}ij972740{552}{553}}{552}}{552}}{556}}fx0.080732{492}ac1.36605{491}in0.946926{490}az0.68531{500}{501}}{493}}ag159.5{bc0.2",
    "50413{ba0.509413{bl2.09437{hp0.249306{bi7.21594{do5.20051{575}cv0.4608{575}{576}}gh338.5{fs0.872043{ib0.001054{576}{577}}{577}}",
    "{576}}fk0.486252{fa0.01626{bi6.06867{558}dd3.86281{558}{559}}{558}}{559}}bi8.04106{bt5.38099{571}hx0.454762{569}hu0.831929{id0.",
    "024238{570}{569}}{570}}dm907.857{ay2.95013{573}{574}}es0.019903{ai4396{572}bk6.28504{572}{574}}{573}}ej2.57707{cw0.112859{485}d",
    "c4.27161{fw1{483}{406}}{409}}eb0.200531{484}fg0.983054{ft10.5{586}{585}}ff0.9939{585}{586}}ge0.212121{cz84.5{db29.5{ij21.5283{5",
    "66}{437}}cc1332.5{cm5{439}{410}}{408}}be1.80588{bg2.62757{590}{565}}{416}}gy0.157135{fb3.97295{ek1.53751{438}{413}}cm2.5{er0.96",
    "8011{543}{542}}gh16.5{542}{543}}gs12{ey0.958333{cb764.5{545}el1.53491{gh425{523}{545}}{544}}em0.295301{545}{544}}ey1{fx3.30281{",
    "428}{430}}gm0.561691{fy2.06943{524}{525}}{524}}cy179.5{hc53{im9.0629{423}bh2.35172{407}{422}}co17.5{fe0.165792{420}{421}}{419}}",
    "ek0.815341{hw3.46{424}es0.021362{426}{425}}ez0.958651{417}{418}}by0.128413{bk0.557739{ea0.0949125{aw0.009857{bm0.88263{br486{bo",
    "0.639143{455}bq336{456}{457}}ab8.83765e+06{458}{453}}bm0.889614{eo0.999969{dj265.5{481}{461}}ay9.4e-05{479}aj510{479}{462}}bh1.",
    "10676{bc0.489997{481}{459}}bq898{463}{464}}ec0.972655{bn0.199184{411}ey0.547619{412}{560}}bs76{gi340{477}{563}}de0.002152{ab199",
    "96{440}{460}}{454}}fn0.42026{bg1.27139{fd0.475733{440}{446}}am0.435364{el0.000153{447}gg25696{441}{447}}ao472.082{fz0.251253{44",
    "1}{443}}fh0.700657{443}{441}}gz0.9{hp4.9e-05{dy0.999772{ce232{547}bo0.595857{546}hh31{547}{546}}cc4900{gb0.0011115{fq0.974548{5",
    "46}fk0.249858{dj126.5{546}{548}}{548}}{546}}{546}}ez0.738391{fm0.88971{546}{548}}{548}}bo0.526269{cn3{em0.349579{549}aw0.033136",
    "{fa0.810715{549}{551}}{551}}{562}}ar0.003391{550}ea0.853159{551}{550}}ft23{hs4.05692{bb0.63557{al2.84046{fg0.807212{471}bl0.074",
    "4655{470}{469}}im11.2336{hw0.58002{472}{592}}hy0.676365{591}fr0.980994{594}{593}}bq377{bl0.047041{gg11296{465}{466}}cb936{473}{",
    "474}}ex0.947368{dj14{468}{467}}{476}}ew0.615295{fl0.2{ao25.0488{499}{578}}br79.2432{fd0.765127{578}{581}}dz3.66948{el1.54852{58",
    "0}ew0.47828{579}fm2.26805{579}{580}}ap0.102417{581}{580}}ay0.068511{jc0.215233{fc6.52467{cu0.315554{554}{555}}fw136.5{ik3.63405",
    "e+06{hn0.0544065{541}{536}}{540}}az0.22248{534}{538}}fk0.011484{475}{478}}dd5.6668{ho0.015497{427}im9.46525{429}{436}}es0.01530",
    "65{hk5.04887{431}{432}}{430}}bu1.8149{dv0.041667{cu0.659745{cy164{gh3584{445}{450}}{445}}bm0.877354{bw2.06598{444}{451}}{480}}e",
    "w0.998106{442}{448}}bo0.651725{cd5100{al2.63093{fv108.998{ce3200{gg2800{444}{449}}dn3.08227{ce3400{451}{452}}df47.1529{aj71.480",
    "3{451}{452}}{451}}{444}}am3.94077{bp61{451}{449}}{564}}ep0.999895{452}{451}}ha0.5248{fd3.95967{fc1.9309{450}{442}}ik9.45905e+06",
    "{dw0.008969{ez0.993314{530}{531}}{531}}{538}}dd7.67322{az0.539624{dl174.481{bv5.38082{528}{529}}cb1820{589}{528}}bt5.49096{564}",
    "{589}}{589}}ai308{gs23.5{jd0.32{ik78.3104{df34.089{bp2{525}{522}}bq47.5{503}{504}}gy5.17439{bp2{fp0.392636{dc6.70607{592}{584}}",
    "{439}}{504}}gx1.70018{504}{505}}fu16.5{gt8.5{bm0.805101{gf83{524}{525}}{414}}{526}}bk3.77279{jb1.27184{cd4892{587}{567}}fm1.598",
    "26{523}{588}}ha0.51504{iv4{ew0.679442{583}{582}}{582}}ba0.671639{584}al4.11203{583}{584}}hk4.75372{cz321.5{gq0.259655{ib0.00811",
    "35{505}{435}}ad394{434}{523}}dj2.33333{506}{489}}dq50.4809{cw0.16807{ip24.6537{561}fx0.322983{bu0.093147{486}{560}}bz0.103806{4",
    "89}{483}}ad812.5{507}ge0.945626{507}{508}}cd23429.5{508}{509}}gv5.31532{ba0.768429{di0.061666{aw1.7457{521}cz19863{588}{587}}bv",
    "0.560371{519}{520}}dt0.261875{bv0.353511{512}fu180{510}{511}}bq197.5{509}{510}}dq84.8751{hm82.6658{515}bl0.107426{514}ai440{512",
    "}{513}}by0.26244{ic0.0033955{517}gj25{ax0.996826{515}{516}}{516}}{518}",
};

char *randomforest_crafted_tree_4[34] = {
    "bg2.00643{by0.208156{bv0.835273{cv0.5248{ea0.459358{bk0.22502{bj0.183708{560}ew0.999908{cb25696{441}{447}}{447}}an0.399931{aj38",
    "8.223{443}ac195.859{443}{441}}{440}}by0.004783{bg1.25889{gt4{480}{446}}{443}}ha0.256{566}bc0.451655{562}be1.44444{469}{489}}bo0",
    ".638464{fd0.697964{bh1.38158{cy116{477}dd0.0043{440}{454}}{563}}gu1.5{bn0.671744{gd0.0072185{ar6.7e-05{fq0.974938{549}bn0.64645",
    "9{ej1.50683{551}{549}}{551}}fb2.3582{549}{551}}{549}}{550}}dj19.5{fo0.367615{547}{548}}bg1.44183{cz2208{548}{547}}fg0.849104{fo",
    "0.41096{548}gb2{546}{548}}{546}}fg0.800474{az0.464546{be1.10676{gu2.5{481}{459}}bf1.10878{464}{463}}ce25000{bp527{458}az0.47948",
    "7{462}{479}}{453}}ff0.900641{ed0.999149{456}eo0.999976{461}{457}}at40{460}{455}}bm0.880938{fb3.58269{ir1{dz2.77096{hh81041.1{cz",
    "125{dk14{566}{439}}{470}}{468}}gu13{592}{467}}cc4600{bu2.3657{de2.10819{452}de2.38502{cb2800{444}ce3200{449}ab155300{451}{444}}",
    "co6{444}ap0.000568{444}{451}}{449}}ax0.001007{gg6400{444}{451}}bc0.489694{451}{452}}io3.7533{ez0.650558{gy0.157135{582}fz1.3169",
    "6{545}bk1.39228{545}dp0.228342{545}{544}}aa5828{ak85{592}{564}}hz0.218751{466}{591}}bz0.028625{cd1934{437}{436}}ao7.65755{ab562",
    "7{410}{408}}{593}}am2.67408{hg24{bv1.076{fe0.001082{445}cd3328{445}{450}}fy1.92177{450}{442}}ea1.25759{ay0.002736{448}{442}}bl0",
    ".051586{hj0.655586{465}{473}}gt8.25{471}{476}}im2.93391{cv0.387109{bz1.7e-05{534}{475}}gu2.5{dq28.4153{ft79.5{az0.564531{589}{5",
    "64}}dq14.4326{528}ga30.1482{529}{528}}{589}}dq16.5534{530}bf1.22302{fb7.08325{529}{531}}fy6.12569{ej0.009629{530}{531}}{531}}hz",
    "5.4e-05{is0.526316{br260.189{472}{538}}{474}}ah4{cn11{555}{554}}cz5111{478}ep0.844152{ia0.000341{532}{535}}ga138.132{536}{533}}",
    "gx3.4457{ik62.6165{er0.426928{cn6{bq27.5{522}hc36{522}{503}}if0.208052{526}jb0.014304{434}cw0.0588245{435}{525}}ap0.356449{ai12",
    "{501}{486}}bs6{ig0.904023{ig0.9{523}{487}}fn1.29645{482}co7{482}{487}}af110{ex0.25{483}{561}}eb0.204194{di0.118678{560}gc0.6362",
    "73{485}{486}}{407}}ij9134.85{il0.290293{fu80{505}ai196{506}{507}}fp0.31536{al2.20927{eh0.455936{504}ez0.70275{504}{505}}fu40{50",
    "3}{504}}bb0.587279{iz0.872897{414}{567}}{439}}ip921.25{507}ax0.979343{gz0.354218{438}dj10{cb37845{fa0.555556{523}{414}}{489}}hy",
    "0.23075{582}{583}}{508}}ho0.069791{ea0.352738{bq367.5{ds0.356857{516}{515}}bu0.518193{id0.010656{517}{516}}{518}}er0.576214{519",
    "}bj1.24465{520}bb0.56357{521}ir0.71789{521}{520}}dk264.833{ab72743.5{gh4617.5{gy12.3079{508}{509}}{509}}bj0.736096{511}cd47899{",
    "510}fq0.98857{510}{511}}aa119054{fu220{ab140222{511}{512}}{513}}{514}}es0.382473{fm0.208093{bz0.036337{bc0.33916{ar0.0328435{af",
    "364{422}{421}}{423}}cu0.166772{419}je0.245{av3{gs2.5{411}{468}}{415}}{420}}hh495.015{fu55.5{426}{417}}hh591.494{dq106.551{425}{",
    "418}}bc0.337267{424}fk0.000216{425}{424}}au3.2259{gs4{dp1.99056{bb0.515312{im1.16977{557}{556}}fw1.5{fx0.968302{am1.55074{542}b",
    "p76.5{543}{542}}{543}}fp0.337678{411}{412}}dz1.45623{433}{416}}bs27{hu2.93156{hm12.2032{dk53{414}{593}}ij9.8121e+07{591}{431}}c",
    "v0.247726{cu0.454382{ej2.87786{524}fq0.985132{524}{525}}{525}}ed0.972104{ab12934.5{583}{587}}ay0.729137{582}{588}}fv8.63261{hx8",
    ".92103{428}{499}}ft2.5{430}ha0.526208{427}{429}}im1.64566{ej2.60141{dp4.14819{gf16.5{bl0.010211{527}{502}}{411}}fe0.0782265{al7",
    ".17254{gd0.563326{596}el0.128838{595}fy1.30154{596}{595}}{596}}{595}}fe0.123272{dm898.441{gd0.917829{gy0.792888{571}{574}}{573}",
    "}hw0.613817{572}{573}}ah2{an1.12024{584}{587}}dw0.50732{bh6.53989{559}ff0.991962{do3.59234{cy2.5{559}{558}}{558}}{559}}av8{558}",
    "{559}}ib0.0067135{eu0.201261{bp5.5{gp0.305455{406}id0.010109{584}ak15{587}{574}}av9.5{en0.950506{dp6.11369{570}hh6.09322{570}{5",
    "69}}ee0.839929{570}{569}}gn6.44153{569}{568}}ev0.0621525{dy4.04636{576}bc0.135945{dn7.12266{575}{576}}{575}}gy2.13351{hz0.21674",
    "6{575}{577}}{576}}it112{aj99.0967{eb0.331105{578}in1.6465{581}dw0.497959{581}{580}}ic0.056055{580}io2.38578{il21684.6{579}ew0.4",
    "68365{579}{580}}{580}}hh3.48253{gk0.459148{hs2.06423{585}ff0.992802{586}{585}}{586}}{586}}df35.4627{hc131{de2.30179{ad955{bg3{a",
    "l0.165995{500}go0.808154{553}dl5.94759{hv0.105695{hj0.110528{552}gk0.080136{552}{553}}{553}}{553}}cv0.214958{485}{483}}{493}}cd",
    "1323{fm1.70804{fq0.974751{491}{490}}eq0.0084135{409}{590}}{492}}ey1{413}{494}}dg0.001644{fl0.166666{497}bf3.69231{cp5{488}{565}",
    "}{484}}de2.18001{496}db121{490}{495}",
};

char *randomforest_crafted_tree_5[36] = {
    "bf2.05421{bz0.0676845{fx1.28868{cm3{az0.718564{ab695570{at23.5{az0.621375{gg200{415}{460}}dc0.0204395{454}{477}}el0.000328{at50",
    "{461}{456}}dv0.0056005{481}{455}}dc0.0005025{bn0.781707{bg1.25127{bn0.780223{479}{464}}{453}}ha0.64{459}{481}}fg0.800405{ft609{",
    "cy1016{479}{462}}{463}}fs0.999984{457}{458}}gt1.5{bh1.70833{550}bf1.85{hy0.092651{550}dz0.994156{db22{549}{551}}{551}}fd1.045{a",
    "q0.0142765{bn0.64598{549}dg0.000477{551}fe0.249422{551}{549}}{549}}{549}}ea0.493551{563}bn0.723325{ez0.735506{bb0.639308{548}{5",
    "46}}ai63{ff0.923851{546}el0.999448{548}{546}}bh1.48736{548}{546}}fm0.835117{547}dl32{bm0.860232{546}fh0.769682{547}{548}}dy0.99",
    "8846{548}{547}}bc0.486884{ic0.06125{ap0.200003{416}dy5.20512{437}{410}}ed0.909716{hs5{az0.619593{439}{566}}{562}}dk11{560}{469}",
    "}fc0.503659{fc0.417455{gg28032{441}{447}}ez0.996374{443}{441}}fz0.475733{bm0.87314{cd33288{443}{441}}{440}}{446}}bg1.22424{fd1.",
    "62848{ah44{ex0.947917{bv1.85712{aj719.912{gj27008{471}{476}}{468}}gh480{470}{473}}fo0.0027375{448}{442}}fd1.17878{bp102{dl70.71",
    "07{cc3328{445}{450}}dw0.014083{450}gg3584{445}{450}}cw0.255535{445}{480}}{442}}ib0.000555{cw0.49{ip3.20104e+06{dx0.004649{dy7.1",
    "2681{529}{531}}bp60{531}en0.999938{530}cc1625{531}{530}}ft10.5{hu4.87874{dt2{535}{537}}{532}}{467}}an4.36445{564}at26.5{fy6.072",
    "38{528}{529}}gg1655.5{589}ff0.90042{589}{528}}bu3.03449{ah17{hj1.14916{465}{475}}hz0.000108{474}{478}}bk3.9079{cz9720{472}{466}",
    "}bo0.674368{dq158.524{539}{533}}hx46.5696{538}{534}}am1.9849{en0.971993{fp0.358667{if0.440092{545}{544}}ht21{bz0.0002185{544}{5",
    "45}}{545}}gi18592{fv119.655{480}bl0.003487{451}{444}}ao476.587{443}{441}}eq0.999377{ej0.015434{dn3.82395{gh3200{449}bl0.007176{",
    "gg3400{451}{452}}gz0.534393{hm0.734847{df47.1722{451}{452}}{451}}{451}}{449}}ex0.985294{436}cn7{aa2800{444}{449}}gg2800{444}{45",
    "1}}aa5100{444}ay0.000527{451}{452}}aa67322.5{is0.581319{gz0.239149{is0.0357445{fv1.02884{486}fo0.020106{bg1.49956{hl6.73712{483",
    "}{485}}{486}}{560}}ii8{en0.949484{if0.254111{407}{408}}bp2{438}{561}}cv0.214958{ce96{cc88.5{482}{487}}{487}}{482}}df38.164{cn6{",
    "522}ez0.633953{db14{439}{501}}{525}}cz166{ec0.953497{dq21.0113{ar0.190671{523}{503}}{504}}{503}}ej1.89631{bj1.84194{505}{504}}e",
    "p0.84773{fy1.59867{489}{523}}{504}}hy0.35324{cd50448.5{ij28192.1{509}ax0.993035{510}gv5.03066{510}{511}}{511}}il0.100086{gy10.4",
    "625{ik229.782{el1.11534{ec0.949847{507}{506}}{506}}{507}}aw0.995057{508}ij20114.7{508}{509}}fa0.7{567}{505}}hf1{cb179574{er0.31",
    "3163{hb0.2058{435}{489}}{515}}ie0.023267{bm0.851738{518}{517}}dn3.75064{ap0.658498{435}{434}}{516}}fu218{em0.264564{bj0.665534{",
    "512}ao11.4269{511}{512}}ec0.952654{489}{526}}ij87134.2{dw0.497215{513}hn0.223402{514}{513}}{514}}es0.275767{fs0.96306{hi3{fq0.9",
    "70171{ic0.015479{de5.60194{ar0.004835{fk0.5{502}{527}}fp0.215681{hw0.123964{558}ey0.875{558}eu0.28645{559}fc2.62925{558}{559}}{",
    "558}}ay0.133603{595}ey0.43643{596}er0.905011{du0.563465{596}{595}}{595}}bi0.0068055{557}ax0.522018{556}aw1.73815{585}{586}}ai75",
    "6{dz0.911826{dg0.261561{519}{518}}{520}}{521}}er0.0949065{eq0.166768{bc0.126968{bf15.0833{dy4.07508{bx0.197666{569}{571}}hx0.63",
    "2905{bn0.132426{570}{569}}{570}}dg6{574}es0.0180385{by0.116475{573}{572}}{573}}bj6.47182{bq299{ab16019.5{hm1.09255{575}{576}}{5",
    "76}}{575}}hm1.12286{aq0.0233095{568}{577}}ey0.8{ib0.001394{577}{576}}{576}}ha0.239159{gd0.16445{cu0.315554{554}{555}}{499}}hj2.",
    "38213{ev0.001065{bf3.14286{hm0.741225{411}{439}}{412}}{586}}eb0.332655{dd8.59276{588}{587}}{587}}jd0.306238{eu0.189764{gh177.5{",
    "fy0.945705{bj1.55007{542}ea2.37767{543}{542}}{543}}hh22.3294{578}ep0.877236{428}{430}}gb0.570299{ad52.5{579}cy104{579}gl1{580}e",
    "n0.95038{579}{580}}ep0.839802{580}ep0.848847{581}{580}}bz0.155613{gv0.591001{el1.48183{fu118{an2.65352{432}{428}}{431}}{406}}cw",
    "0.070001{ij1.13203e+08{524}bz0.0894085{525}{524}}{525}}et0.0163355{de3.1479{414}dc6.31048{582}ip3.99038e+06{583}{582}}bt3.48481",
    "{ej3.71701{583}{584}}{584}}an1.27536{fy2.10282{hm678.726{et0.0787065{411}{417}}hh579.477{418}{424}}ik874764{423}ec0.960763{426}",
    "{425}}by0.028697{ar0.025926{gs13{gm0.152427{427}fe0.094729{427}{429}}{419}}hl4.3558{ht2.5{468}{430}}{420}}hc53{ac32.9456{gd0.21",
    "9276{iv1{gx0.0642575{594}{593}}{591}}iu1{592}{438}}{422}}fg0.820028{421}id0.045514{cd33867{431}{524}}{432}}br0.102386{fv0.02169",
    "3{by0.993271{je0.429656{498}{496}}{497}}{495}}aa141423{bq56{bt1.11166{dj14{iu2{di0.001005{553}ia0.484382{553}fn1.71662{552}hs2.",
    "02072{552}{553}}es0.748512{490}{500}}aa160{cm7{483}{485}}{485}}bg3.19753{fc3.97975{590}{409}}{484}}ds0.003809{ai86.5{492}{488}}",
    "cv0.4096{eo0.899389{gz0.479075{413}{565}}{491}}{433}}cz2378.5{493}{494}",
};

char *randomforest_crafted_tree_6[38] = {
    "ba0.738007{bv0.826334{cz3002{an0.0180455{ce1537{is0.024038{df2.17855{486}ii4137.95{cb189{411}{488}}{412}}di0.001628{bs48.5{ds0.",
    "0841575{415}{501}}{412}}cm7{el1.34328{482}cb88.5{482}{487}}cb135{487}ic0.103704{482}{487}}{494}}iz0.41028{ho0.0635735{bv0.34743",
    "1{dr0.407589{433}{561}}eu0.189601{al2.71195{566}{430}}fq0.965554{de1.40372{579}{580}}{579}}dv0.733333{di1.5e-06{bk0.007107{557}",
    "{556}}fa0.316667{aj15.1103{523}{500}}{565}}fg0.962284{ek1.86416{em0.248928{553}{552}}hn0.8097{fq0.963882{552}fq0.963945{553}{55",
    "2}}{553}}jb0.339934{584}{583}}fx0.0646705{493}fe0.075024{492}hc63.5{fb0.70064{490}iu2.5{582}{588}}{491}}je0.429856{ce4961{bp140",
    ".5{eq0.005744{ba0.505613{527}{415}}ha0.8{dm33.6667{496}{498}}dq0.010119{557}{556}}cb208{bw0.425814{fz1.17365{502}{595}}bu0.4922",
    "21{bq202{cz11452.5{el0.144258{596}bk6.72399{596}{595}}{595}}{596}}{595}}{595}}{497}}ax1.23755{if0.275353{496}{585}}{495}}gg8080",
    ".5{bb0.433784{gc0.948804{dm142.637{fe0.124765{bc0.13563{el2.11819{577}gk1.22105{cd2695{576}{577}}{576}}fq0.958647{fh0.9836{576}",
    "{575}}hs6.73694{575}{576}}fu19{588}{587}}em0.217167{dn10.2563{er0.056027{hw0.263701{569}{571}}ak22{568}{406}}ev0.0617015{bn0.11",
    "8146{574}{572}}ax3.54366{573}{574}}iu2{dn8.3198{ep0.848847{581}{580}}{570}}eq0.200994{dr3.1e-05{586}gj258{586}{585}}{586}}fd1.9",
    "9106{bs23{cn6.5{483}{485}}gp0.386103{559}fa0.0134395{hc23{558}{559}}{558}}ff0.970044{409}{484}}ha0.3008{bs24{eb0.158938{df14.53",
    "97{if0.664444{437}ig0.888633{439}{566}}{413}}dr0.357032{ap0.391908{410}{408}}{407}}hr25{416}{499}}in5.01777{eq0.226662{gl0.0465",
    "045{al1.55169{543}bf2.4{543}em0.292436{er0.923704{542}{543}}{542}}gb0.302213{545}{544}}gm0.111196{fg0.958221{gq0.0729485{ex0.23",
    "6842{579}{411}}{412}}er0.156627{584}{581}}bu4.56788{579}{578}}iv4.5{eq0.234026{en0.951411{590}{428}}dk54{ep0.913018{594}{593}}{",
    "591}}ge0.926491{cw0.082354{ij1.13203e+08{524}{525}}{525}}{524}}bx0.036378{ad3173.5{cw0.0050525{io1.29527{422}{421}}{423}}eh0.33",
    "3332{420}{419}}bo0.385335{ep0.88998{418}{417}}fo0.000273{426}ab1.97841e+06{424}{425}}bz0.05899{am1.08237{fs0.99984{fb1.39267{en",
    "0.998996{hi8.5{dm4{412}{560}}id0.078125{411}{469}}ff0.90161{bg1.26471{cd442{460}{440}}{454}}bh1.48889{477}{563}}gf10{bg1.45213{",
    "hs17.5{547}bn0.730418{eb0.464485{fw21.5{dj18.5{546}{548}}{546}}{548}}hz0.009974{547}{548}}bf1.48618{fe0.252714{fo0.386263{546}{",
    "548}}bb0.639671{az0.959079{546}{548}}{546}}ep0.853289{546}{551}}aj9{562}az1.21027{fe0.270913{550}{551}}bn0.671346{ds0.022957{bh",
    "1.94107{eh0.491939{549}{551}}fo0.413185{551}{549}}{549}}{550}}am0.182885{bh1.11385{bm0.889745{dv0.0016845{463}{462}}be1.10769{d",
    "e8{fp0.002289{481}{459}}{481}}{464}}cd2220.5{db616{gs3{481}{455}}{461}}gg25000{bh1.25291{az0.644984{479}{458}}fa0.996183{456}{4",
    "57}}{453}}bk0.22502{cd25696{441}{447}}ai598{bo0.64304{440}{446}}bk0.389133{ai1352{443}{441}}cc48264{443}{440}}im0.052693{bo0.64",
    "7024{cb2028{ax0.241056{fv119.249{564}{468}}aj68.3474{544}hl0.980635{545}{544}}dn3.99834{ec0.998526{cm6{bx8.35e-05{449}{444}}ax0",
    ".0041205{451}{452}}hl0.368483{bv1.78056{cc5600{bh1.27761{444}{480}}{451}}cc5100{bg1.25154{ab120342{451}{452}}gg3600{gh2800{444}",
    "{451}}ec0.99879{452}{444}}fh0.701703{451}{452}}{451}}{449}}cn3.5{co2.5{al5.37833{564}bw33.4766{cy206{gi692{az0.596458{589}{564}",
    "}{528}}{529}}gj1796{589}{528}}ba0.809891{ec0.999055{531}at26{530}fd5.89758{db400.5{531}{530}}{531}}{480}}ex0.971354{ap0.0027675",
    "{448}{442}}fb1.96991{gh4608{aa3328{445}{450}}{445}}dy2.29598{450}bk1.19931{450}{442}}fa0.960718{cp8{ex0.369904{ec0.949886{dq21.",
    "3429{436}{539}}hk0.999744{545}io1.10459{533}dz7.95373{544}{532}}gc0.113285{fe0.0957845{427}de2.96097{429}dg0.002307{427}{429}}{",
    "430}}im10.0919{ib0.0125955{gc0.000405{534}bi6.57081{554}ga51.8985{dk1331{541}{536}}{537}}ft10{555}{472}}is0.129133{ad2366{ho0.1",
    "24896{432}{431}}{431}}au2.28099{er0.177311{535}{592}}{593}}fn0.0156505{cy29{fr0.999931{cw0.0189685{466}{475}}br872.14{467}{468}",
    "}ap0.02004{476}{474}}iq0.4{hr36{dj30{470}gz0.69255{538}{480}}{478}}gd0.000411{gu11{473}{465}}{471}}cz675{fu52.5{ix1{cc611{cb236",
    "{au1.52298{439}fa0.844445{522}dk35.6667{522}{503}}dd2.51921{439}dl21.7141{503}ax0.938579{503}{504}}ik44.9174{gk0.044589{434}dl2",
    "2.5338{561}ir0.0875825{560}{485}}cu0.422339{592}{504}}ex0.5{dg0.0854635{dm34.75{ad434{588}{587}}ds0.0003005{cz523{583}{582}}{58",
    "2}}bd1.25{bh1.35714{525}{414}}fa0.584722{523}{567}}ay0.531478{435}{526}}df124.467{hk4.74277{cz320.5{ai120{504}{505}}{506}}dm4{h",
    "c4929{506}{507}}{507}}ip1287.48{ho0.171239{dm4.41667{508}{509}}bi1.94817{508}{507}}ej1.76419{hj6.08531{509}{510}}{509}}hj3.1375",
    "2{az0.911261{di0.070992{dh0.108731{ba0.761679{521}{520}}{520}}{519}}df223.066{df213.915{bh1.625{515}{489}}{516}}an0.208002{517}",
    "{518}}bj0.607762{cz980.5{513}{514}}bj0.73878{fz0.308194{ip2747.82{bk0.344857{512}{511}}{512}}cv0.32768{489}{511}}dt0.133951{hm1",
    "56.126{cd4996.5{ec0.970182{555}{582}}{489}}{438}}{510}",
};

char *randomforest_crafted_tree_7[36] = {
    "eb0.097358{iv3.5{fk0.0098495{bh1.236{cv0.4608{hj0.327793{by8.5e-06{ea1.17878{dj102{fn0.003686{450}ce3328{445}{450}}{445}}{442}}",
    "cb2944{442}{448}}gc0.000638{bh1.20277{ct1.25{468}{476}}dp2.6284{467}{466}}gb0.0414775{474}gd0.000268{465}{473}}am3.15968{ec0.99",
    "9803{el0.0001635{fk6.5e-05{479}{462}}ep0.999951{460}{461}}at90{463}fm0.0002355{bh1.10366{481}{459}}ah910{479}fg0.800196{479}{46",
    "4}}cv0.64{dj102.75{bl0.029421{530}bf1.29948{bo0.662978{531}{530}}{531}}ao36.6774{529}{531}}fy5.68928{de5.74671{564}{589}}bf1.25",
    "347{cy193{528}az0.502807{528}{529}}dn7.41076{gi1182.5{589}{528}}{589}}bg1.28748{fz1.05232{al0.615024{ex0.994998{fu67{477}ff0.90",
    "1396{ai148{440}{455}}{454}}dm346{ez0.996183{456}{457}}ax0.000149{453}{458}}bg1.2333{bj1.00827{446}{480}}{440}}bf1.26073{ce5000{",
    "444}cn4{451}{452}}cb3200{cd2800{444}{449}}ap0.000275{ej0.0063175{452}{449}}gh3600{451}dr0.0003705{451}{452}}at58{ba0.789385{eh0",
    ".211756{415}{561}}{563}}fc0.417634{ed0.999151{gj28032{441}{447}}{447}}bc0.489967{443}fs0.999989{441}{443}}bk0.292482{bm0.81{cp4",
    "{cn2{527}de0.192372{411}ap0.452151{412}{411}}df0.610845{cm7{483}{485}}fy0.0783585{fp0.299509{553}{552}}ir0.950239{553}{552}}cy2",
    "1{bv0.0221225{ig0.908046{cm7{ib0.057143{487}{482}}{487}}{482}}bc0.418254{gb0.903559{486}{561}}bk0.050481{gx0.0127855{560}io6.40",
    "086{560}{483}}{561}}cw0.178874{486}ai13.5{566}fx0.295837{439}{522}}en0.95038{hr1.5{co3{502}{484}}jd0.32{er0.916407{ea6.18592{59",
    "5}fz1.16621{dx0.608156{bg8.33784{595}{596}}{596}}bm0.43254{595}fa0.383586{596}{595}}aq0.0964155{595}{523}}gn0.566558{dt0.03957{",
    "565}{414}}{590}}is0.188101{ce1750.5{ce56.5{522}id0.133878{472}cu0.729{499}{469}}{433}}ac6.6173{434}fc1.51878{406}bv1.90689{471}",
    "{470}}gy2.00007{al0.120057{fc0.029845{bq167{eo0.900554{498}{496}}{497}}{495}}aq0.621991{dt0.148327{iw3.05769{fb2.87935{413}{567",
    "}}at28{es0.003534{440}{478}}{475}}{526}}{494}}bl0.235893{bc0.405645{au1.87871{520}{521}}ad15950{da76.2775{518}{517}}{519}}im0.2",
    "58576{493}fd0.025138{492}cy10{fx1.97918{523}{435}}dn5.13723{491}{490}}ad1290.5{fk0.194482{bq125{ab10514{df53.6389{ho0.182575{au",
    "1.76625{522}fn0.496435{592}{547}}gk1.75934{gi7.55422{524}{525}}da41.5934{ad37{522}{503}}{503}}bj1.85256{du0.05719{gs24{505}{506",
    "}}{505}}{504}}db30.5{506}hs3.75794{bk2.52351{592}fs0.970427{gw0.130961{594}{593}}{593}}ed0.948569{bm0.736627{gn52.6789{430}{428",
    "}}{591}}en0.972866{438}{427}}bk0.577103{df138.606{508}bq172.5{508}{509}}ap0.462291{he0.000452{bf11.6204{hn0.183771{427}{429}}ee",
    "0.91723{432}{430}}cn8{525}ee0.853803{il172.81{gx0.560913{525}{524}}{524}}{524}}aq0.392665{507}in8.99194{507}{508}}fx0.475303{bt",
    "1.3981{bm0.839063{hn0.405{fq0.975005{bo0.526826{bf1.95476{dy0.999142{549}hi32.5{551}{549}}{549}}aa441{eq0.982942{550}{551}}{550",
    "}}ez0.728889{gs9{549}{490}}ek1.41537{bc0.489719{el0.986815{551}{549}}{551}}{551}}fy0.0480525{bp11{501}{562}}ep0.83862{556}im1.5",
    "1824{557}{556}}bn0.724943{ay0.0025625{be1.47433{fu57{ep0.841881{548}{546}}{548}}bx1.85e-05{dm116.5{548}{546}}{546}}{546}}hr11{5",
    "47}bm0.86405{ed0.898134{ai25{548}{547}}{548}}{547}}au2.5648{db30.5{ib0.012496{407}{437}}dy5.58003{ab11193{408}{588}}{410}}am2.8",
    "1132{bb0.493204{579}{416}}im5.39559{ed0.896571{ac31.8593{559}cz40703{558}{559}}{558}}{409}}bp5.5{cy24{hf3{ft0.5{bm0.704295{hs7.",
    "31321{559}{588}}{439}}cw0.0270975{554}{555}}aa2121.5{499}{436}}ho0.16473{ej3.08074{hu4.50379{582}id0.0187825{582}{583}}hm11.343",
    "5{584}ad281{583}{584}}fu13{ba0.425461{eb0.328116{574}ff0.996606{573}{572}}el2.57676{573}{571}}dj16{588}hg57.5{587}{588}}fo2.109",
    "13{bh2.81596{gz0.713074{ha0.184759{hd0.17259{an5.86964{541}{537}}fh0.769927{534}{535}}is0.504289{bz0.0016805{538}{436}}dk1185{5",
    "32}{540}}gs2{cu0.7695{fl0.25{542}{543}}{543}}fm1.42798{fp0.351415{545}bt1.55032{545}{544}}{545}}ht20{is0.0589{eh0.382344{430}{4",
    "28}}{586}}ie0.345006{db350.5{578}ep0.855232{go0.650893{cw0.343{hj0.972773{580}{581}}{580}}{581}}{581}}fs0.909413{579}{580}}db29",
    "50{er0.0124925{ed0.895989{au6.12135{575}{576}}hz0.224222{576}{575}}gs8.5{da835.918{577}{576}}{576}}dv0.924713{ar0.004105{hg7.5{",
    "568}{570}}hz0.258215{dc9.47742{570}{569}}{570}}dl974.561{585}{586}}bb0.541864{dj72.3333{im9.26153{cp14.5{423}bq1176{421}{422}}c",
    "c38365.5{420}{419}}hz0.213495{ek0.600365{426}{425}}bn0.543835{hn0.252069{dc9.12142{417}{418}}{417}}dq114.207{424}{418}}hl4.2195",
    "5{fu278{bm0.839812{bu1.33082{489}fg0.826904{432}{431}}{515}}bv0.232971{517}cd235203{516}{518}}bl0.112751{hc69776{fq0.980695{489",
    "}{512}}ig0.054627{514}bk0.289843{ed0.895347{513}{514}}{513}}hy0.297955{fk0.0661685{438}{511}}bk0.428221{bl0.115461{511}hv5.0827",
    "1{510}fn0.701683{511}{510}}hu5.33715{509}{510}",
};

char *randomforest_crafted_tree_8[35] = {
    "aq0.205837{bn0.580812{cy178.5{eo0.923007{dg0.0001435{hy0.250486{ea0.97248{484}eu0.16931{gr0.5{409}{578}}ik63485.3{br112.5{579}{",
    "580}}fv9.15625{581}{580}}bq1140{ij6.9126e+06{be1.31438{dv0.993818{585}fz0.31935{585}{586}}{586}}dd5.12718{575}ah10{en0.949214{i",
    "a0.105627{576}{577}}{577}}ed0.897242{576}{575}}bi7.68881{hv0.443333{569}be3.81421{ih0.114667{569}{570}}{570}}dc10.122{gn3.39745",
    "{572}{568}}cu0.69255{573}{574}}et0.00161{gq0.251908{id0.25{431}cn6.5{483}{485}}aq0.090017{hm0.0869965{500}{565}}hk0.0443615{hh2",
    ".01064{hy0.809331{553}{552}}{552}}el1.39892{552}{553}}fo2.03877{aw1.77355{aw1.4361{432}{428}}{499}}dw0.499081{io0.020948{bb0.16",
    "2904{559}{558}}{558}}df14017.4{hz0.591864{er0.0073615{558}ew0.051951{559}bz0.004688{558}{559}}{559}}{558}}by0.0283565{gd0.28116",
    "5{ga4.5687{en0.98821{412}{411}}du0.0441915{bi4.14101{468}gh4525.5{429}{427}}{430}}bz0.0259255{419}{420}}cc34287.5{422}{421}}ee0",
    ".879021{hy0.337116{fa1{av12{502}{527}}{426}}bq735{ez0.339999{hy0.566732{406}{488}}fk0.919889{dk564.333{eb0.077705{ea5.7569{596}",
    "{595}}{596}}{596}}{595}}{425}}es0.027755{hl4.3514{424}{423}}eh0.328206{417}{418}}fm0.693123{bm0.878551{fu170{do1.61297{gg290{gr",
    "3{415}bb0.638504{469}{477}}bg1.26471{ah148{440}{455}}bp66{563}{454}}hm0.734847{aj148.547{ce4500{bn0.75634{be1.22995{449}bn0.756",
    "312{fe0.000411{444}cd2600{444}{449}}bq117{aj71.5875{449}{451}}{444}}gi3600{bk1.97548{451}{449}}{452}}{452}}aa5600{444}{451}}gg3",
    "138.5{427}{451}}do1.15987{ee0.998992{cd5000{456}{457}}dm724.5{gr3.5{458}{440}}{453}}fc0.433567{gh25696{441}{447}}bv0.251253{441",
    "}ga407.164{443}fx1.40815{441}{443}}an1.84823{fd0.557739{bo0.661485{fz0.475733{fk0.000683{479}{460}}{446}}bg1.10878{bg1.10568{be",
    "1.10366{481}{459}}{464}}bf1.1152{dl608{462}{463}}bo0.670671{461}cy1301{481}{479}}bf1.26786{gd1.5e-06{ea1.19931{bf1.21875{445}aa",
    "3584{445}{450}}{442}}by2.8e-05{448}fv477.33{442}{476}}am2.17917{cn9{ig0.272917{480}{470}}{468}}fs0.998513{fg0.806616{473}{471}}",
    "{467}}fc5.43541{dq30.6349{bw5.85821{hq18{465}{478}}ip234551{564}{472}}hm769.182{474}gd7.7e-05{466}{475}}cp2.5{dd6.96583{ea5.242",
    "05{br129.592{589}{528}}{529}}cb1741.5{589}dd8.16448{528}{589}}cy138{fb6.40787{bm0.885661{531}{530}}{531}}dq20.3316{530}ep0.9999",
    "02{531}ax0.000939{531}{530}}hb0.276845{df4.67779{bd3{dp0.800356{ib0.057307{co8{cu0.504869{487}{482}}{487}}{482}}ig0.874487{439}",
    "{566}}ds0.107374{439}{486}}eq0.208483{bw7.5827{dc4.83271{437}cv0.294912{408}{410}}ak27.5{iz0.100624{523}{413}}{416}}dv0.987484{",
    "bq80{fh0.820623{bh1.40967{587}{436}}cz490{414}{582}}bh1.75{ew0.641016{567}{583}}{489}}if0.128986{au1.97838{gs8{eq0.997782{540}{",
    "532}}fp0.430254{536}{537}}bz3.95e-05{534}bo0.674314{533}{535}}bx0.104453{gs9{538}{554}}{555}}fd2.27131{gz0.855{iu1{bm0.861348{b",
    "e1.44583{hh15{547}bg1.44281{548}{546}}bm0.855146{546}ds3.5e-05{ex0.341772{ff0.926037{548}ff0.926602{546}{548}}{546}}{548}}ej1.6",
    "1681{547}{548}}{590}}bm0.828705{bi0.0166595{fu64{ai16{549}bh1.87292{551}dg0.0112075{fa0.7925{fe0.253449{bg1.93809{551}{549}}{54",
    "9}}{551}}{549}}de0.0006695{bn0.645122{549}{551}}{550}}fh0.793589{429}{501}}ej1.59447{550}{551}}cw0.249844{gu1.5{cu0.478297{du0.",
    "041565{524}gl0.846056{525}{524}}bn0.625547{525}{524}}gd0.230109{bk2.89226{593}{591}}{592}}gw0.0554305{eb0.295869{bi0.0227075{bl",
    "4.55e-05{557}{556}}{556}}bt1.54652{543}cw0.4165{542}an1.40986{543}dp0.120905{543}{542}}fp0.349849{545}dz2.51146{545}hi20.5{544}",
    "ds3.95e-05{544}{545}}fk0.192012{hv4.49897{aa98090.5{ic0.005079{df97.0528{il0.464894{cb4594{505}{506}}{504}}dk135.167{506}{507}}",
    "gk2.00287{ij999.821{522}bt2.27344{560}{438}}ab1314.5{ib0.0070075{503}fa0.9{522}{503}}gf62.5{fs0.962819{503}{504}}{504}}bv0.4246",
    "14{ai600{ce182072{515}{516}}al1.00775{517}{518}}bw12.0136{dk495{ad21491{519}{520}}{520}}ds0.239499{521}cz1559{520}{521}}fy0.629",
    "273{ih0.0626365{cc114554{513}{514}}fz0.303865{cy2.5{ab185424{512}{513}}ds0.316305{ex0.126984{560}gh477{483}fk0.010964{486}{485}",
    "}{561}}fu198{511}{512}}bl0.11915{gt20.0987{510}il0.005505{511}{510}}eb0.12726{509}dx0.5{438}{508}}bz0.989024{fv0.320642{hc113{a",
    "r0.983204{ib0.0049345{fu21{cx80.5{490}{407}}{491}}am0.434709{561}{433}}{492}}dl37.6001{493}{498}}il5.56879{ix1{ge0.554716{dc9.9",
    "8014{ea1.52116{584}{571}}gm0.937235{hv0.628881{572}{574}}{573}}{434}}ad359{hg78.5{bj7.02999{582}{584}}bw12.5558{582}{583}}aj21.",
    "9644{588}{587}}bm0.862084{dj2{az0.839197{523}eb0.180528{435}{439}}fv3.5{gz0.9{414}{412}}{562}}dd3.03958{525}{526}}am0.0321365{g",
    "p0.547573{cb3747.5{495}{496}}{497}}{494}",
};

char *randomforest_crafted_tree_9[36] = {
    "aj11.2749{ba0.750127{az3.18517{gn117.369{ah4{ha0.371933{bs13.5{ap0.436594{408}is0.617102{407}{523}}dk21.1667{437}{410}}by0.5201",
    "35{ho0.636903{552}en0.949001{553}hn0.808791{553}dh0.0054265{553}{552}}hi282{en0.95225{491}{490}}{492}}dy0.572422{ie0.505747{ds0",
    ".262144{412}ig0.902381{487}ig0.904762{487}ek1.67234{482}co7{482}{487}}fa0.5{412}{482}}cb1968{bp20{cc137.5{561}{501}}{566}}{433}",
    "}ad2447{dc4.80535{493}{492}}{494}}da118.317{gc0.998239{fh0.998065{ge0.0048585{495}{494}}{495}}{496}}cm13{hd0.136987{by0.32239{4",
    "98}{583}}{588}}{497}}gh8171.5{gf215.5{cc542{fr0.962094{ec0.954228{ap0.524852{bi1.25396{ab415{550}{549}}{414}}{562}}eu0.001266{a",
    "r0.201269{551}{439}}{582}}cb137{ei0.5{560}{522}}bp6.5{ce234{is0.362042{522}{503}}{503}}{560}}dj1.5{ce1783.5{ir0.500674{503}{504",
    "}}df74.129{504}{505}}ec0.956544{cp9{hy0.053504{560}br7.83331{414}bo0.585915{485}{483}}{561}}{526}}cz576{cb8947.5{cd4664.5{co6.2",
    "1429{iq0.703044{505}{506}}{523}}em0.184644{ew0.80414{507}{506}}{506}}ik292.513{507}{508}}hv4.88698{509}dq65.0158{ce35742{cd3467",
    "2{509}{510}}ia0.0753345{em0.165018{511}{510}}{510}}ai360{510}{511}}cv0.172847{bk0.558979{fz0.396674{ad7745{517}{518}}gz0.042313",
    "5{519}di0.0831585{519}{518}}fz0.662601{gx1.94016{567}{520}}dv0.854592{gb0.787844{435}{434}}{521}}hc91773{ce89288{fz0.303275{512",
    "}bk0.344191{512}{511}}{513}}dq85.0314{ia0.028782{ea0.16854{ir0.851874{515}{516}}{515}}{514}}ce217980{516}{517}}az0.722546{bu1.3",
    "7188{cu0.7695{bq818{ar0.0006785{bi1.36573{an0.475733{440}dy1.27373{446}{480}}gi3584{445}{450}}ie0.442709{gu3{cb1699{ar0.005384{",
    "500}{439}}{565}}{469}}{486}}fy0.724788{bf1.34602{bl0.081434{440}{447}}bj0.363474{447}ap2.8e-05{441}{443}}cn4{480}{443}}bn0.7685",
    "25{at37{gz0.729{bg6.51289{415}bb0.119975{527}{502}}gc1.1e-05{dv0.014706{fn0.002395{479}{440}}{454}}fr0.963659{488}{477}}fh0.700",
    "87{em0.009023{fq0.999999{458}{453}}{457}}ed0.998757{455}{456}}cy508{bq252{460}gt3{481}{459}}bh1.11179{az0.461442{bf1.10769{481}",
    "{464}}{463}}eo0.99997{461}aw0.001005{479}gj3050{479}{462}}gb0.008975{bv1.63999{bf1.23077{fy1.87093{fx1.90953{fo0.0017965{445}dp",
    "1.13741{450}{445}}{450}}ga17.1607{fm0.009539{450}{442}}{442}}ho0.004722{fx2.58824{bn0.756075{ga14.0092{451}{452}}gj6400{444}{45",
    "1}}fs0.999984{hk1.80307{449}{476}}{468}}fo0.002753{448}{442}}fy2.81758{bu2.58069{gg3200{fk0.001419{449}{444}}fe0.00029{cd5400{4",
    "44}ec0.999177{452}{451}}br89.6267{ec0.998514{452}{451}}ft47{451}cc3600{451}{452}}ai411{449}{467}}hb0.49{gt6.5{do6.94689{eb0.001",
    "8315{530}{531}}ir0.879176{538}bn0.775364{531}gh2230{529}{531}}hh5047.71{534}{466}}bi5.75807{564}at26.5{cy195.5{528}{529}}bv5.49",
    "286{589}fx7.32959{528}{589}}hk1.19534{br33.3027{df19.1435{ed0.990645{fb3.01133{470}{439}}dh0.000171{471}{472}}bu2.41363{416}{40",
    "9}}cu0.532093{ec0.996374{473}{465}}gx0.0351945{ed0.898564{543}eo0.897454{542}fe0.272282{543}{542}}fq0.967772{ar0.000167{544}{54",
    "5}}ey0.947917{545}bv1.36923{545}{544}}fp0.027683{dt4{426}{475}}fm0.435623{fp0.106547{ei0.333333{474}{438}}{478}}cy14.5{fb6.7576",
    "9{555}dc6.39789{554}{536}}ce61649{bw51.7307{an4.74595{587}{539}}gi40623{au1.97452{537}{540}}hz0.0034425{533}{535}}{532}}gz0.281",
    "186{hl4.41682{fv11.1618{hz0.112083{dd1.69305{cv0.214958{485}ek0.996548{527}{483}}{484}}io3.11472{ev8{426}{417}}dj5{431}{413}}ew",
    "0.999754{iv2{430}{418}}bb0.503471{az0.787922{il30.1241{424}{425}}{424}}{425}}ho0.112906{cd38365.5{420}{419}}in2.5524{ho0.12727{",
    "422}{423}}{421}}bh3.11039{bf2.01636{gs1.5{bh1.80357{ek1.47717{550}{551}}eh0.517455{em0.35332{ee0.846395{551}{549}}{551}}dk26{55",
    "1}{549}}ex0.615385{bv0.38348{fn0.708292{dj101.5{dm61{ej1.51917{548}bm0.861136{ek1.41146{ex0.366667{546}{548}}{546}}{547}}bo0.59",
    "567{546}{547}}ff0.925156{547}{548}}be1.42981{547}{548}}do2.61853{489}{436}}{563}}im8.14908{ho0.363893{em0.283344{bv0.857228{427",
    "}gw0.043711{427}{429}}je0.49{ea1.21011{588}{578}}bl2.48769{583}{582}}bk0.001094{557}ho0.599971{590}{556}}fh0.792116{hm11.2532{5",
    "92}jc0.81{593}{591}}cu0.478297{524}{525}}er0.069555{db2552{ay0.905695{cw0.49{499}eq0.896378{412}{411}}bc0.179176{gt1.33273{ah10",
    "{577}{575}}ek3.5427{ia0.097712{576}{577}}{577}}hg41{587}{588}}ff0.994388{is0.78821{hp0.49{586}ai5120{ek2.76008{585}{586}}{585}}",
    "eo0.897332{bo0.118291{559}en0.946904{558}{559}}{558}}io0.214301{bf15.5{571}dl743.462{fn4.28002{574}{573}}ib0.001067{572}eu0.040",
    "147{572}{573}}ic0.0055345{fu7{568}{570}}cc1485{hw0.522544{fx0.717601{aj44.1491{569}{570}}{569}}{570}}{570}}fn1.12951{fc4.34565{",
    "ha0.718634{az3.71629{432}{431}}gn672.201{428}{430}}fr0.815729{595}hc112{ek0.253613{595}ak384.5{595}{596}}{596}}ib0.006752{dk549",
    "{by0.5631{584}hi17{584}{583}}{406}}ir0.478708{bt2.9991{ek2.28332{580}{579}}{579}}ay1.25969{578}hr20.5{581}hm1.27062{581}{580}",
};

char *randomforest_crafted_tree_10[34] = {
    "aq0.197912{in0.992676{bv0.905483{ea0.130107{bh1.57853{dw0.005834{ak409{cd5000{ff0.900361{461}ak228{481}{456}}eq0.999948{457}{45",
    "8}}ex0.998757{au1.99712{462}bb0.639984{az0.48592{463}{479}}{453}}fr0.999997{464}gh40000{481}{459}}bp81.5{bq58.5{563}{477}}bh1.2",
    "395{da247.821{460}{479}}br136{454}{455}}il10{iq0.715233{cw0.100001{487}id0.255009{482}cj4.6e-05{482}{487}}du0.261805{ih0.000441",
    "5{415}fe0.202679{552}fp0.29969{553}ew0.314468{552}{553}}ba0.513763{527}cb325{412}{411}}{486}}cv0.5248{bo0.638961{dy0.821595{cc2",
    "8032{441}{447}}ej0.001046{bn0.749063{441}{443}}{443}}bg1.23829{gu3.5{480}{446}}{440}}eq0.499007{fy0.696488{go0.81{gq0.2401{502}",
    "{488}}{557}}bl1.52234{dq66.3495{ej0.42116{595}al6.91985{cb157{ew0.09518{595}{596}}{596}}{595}}{596}}{595}}gs1.5{bm0.82574{fu35{",
    "dz0.999676{bp31.5{549}cz351{551}{549}}fb2.61196{551}{549}}{551}}ew0.672542{549}gc0.0430325{550}cz110{fm1.00277{551}{550}}{551}}",
    "be1.45408{be1.43665{el1.04346{547}fo0.367615{547}fa0.950483{548}{546}}ax0.0130085{548}{546}}fa0.625831{ej1.50283{546}{548}}{546",
    "}}ed0.947756{eb0.338996{bo0.056536{hu0.440648{dn5.08109{411}{572}}hu0.774227{569}et0.0746585{bi8.21407{568}{573}}fl0.366667{569",
    "}{570}}cv0.335872{cu0.480954{485}{483}}ap0.130503{ey0.966666{gv0.612803{575}fb3.45892{575}{576}}{576}}eo0.896374{dc8.64622{576}",
    "{577}}{577}}do2.06809{gv0.176679{cp2.5{543}{542}}fz1.3965{545}dl506.414{544}{545}}bm0.712833{dx0.5{eb0.367019{559}{558}}hk0.660",
    "514{559}dw0.52911{hx1.18807{558}{559}}{558}}{534}}bf1.25463{fd1.17566{bf1.23438{fc1.60286{eo0.999784{aa3328{445}{450}}{445}}{45",
    "0}}cd3200{442}{448}}bk1.41934{442}gd3{fc5.93471{528}hb0.49{531}eb0.0009735{529}{528}}{476}}am2.98245{bw49.8907{bi2.95327{ek0.00",
    "40895{cn4{gi5600{444}da296.614{452}{451}}by1{gh3600{cb3200{dl69.6323{444}{449}}{451}}fe0.00089{452}bl0.0122005{449}{452}}{451}}",
    "de2.46391{dy2.21763{451}fc2.21238{449}{444}}{444}}{449}}fc2.75686{468}ac162.853{475}{467}}cu0.7695{gs8{bf1.2754{530}fr0.99993{5",
    "31}{530}}{466}}de5.97866{564}{589}}dy5.57733{fh0.831444{es0.0064225{ex0.9375{bz0.0215455{ey1{bv1.80133{io1.36339{545}{544}}{472",
    "}}en0.95287{hu3.40362{431}{554}}bg9.08283{432}{431}}hw1.8853{in5.18837{567}{414}}gm0.160964{555}{489}}ce1280{ao4.49709{bo0.6579",
    "66{470}{478}}do3.4888{471}{473}}aj70.4474{465}{474}}by0.142285{bw13.387{cd5865.5{at7.5{dl20.5259{592}gk1.67742{bl0.31574{416}{5",
    "94}}{593}}ik559811{436}{469}}iv1{593}{591}}ft2.5{du0.081169{430}{428}}gi1141.36{429}{427}}hb0.275554{413}cm8{hc101{524}{525}}bz",
    "0.0892535{fk0.132422{525}{524}}id0.004231{fb5.40246{524}cb4017.5{524}{525}}{524}}bf3.14667{hg1.5{dh0.0016625{at4{439}{416}}cn6{",
    "ij21.5042{566}{437}}{408}}gq0.488627{bi1.33996{hx0.186754{eq0.0076055{ds0.271697{552}{553}}{552}}{553}}{590}}di1{556}dp0.278656",
    "{eb0.0498265{500}{501}}{565}}ew0.346048{ix2{484}hj0.464751{er0.0008215{585}fo2.24502{586}{585}}{586}}bx0.12214{aj79.529{eb0.330",
    "345{578}{581}}fo1.20665{hv1.23177{hk1.033{579}{580}}{580}}bt6.04113{580}{581}}ix1{499}{406}}by0.038052{cu0.19777{in2.66514{421}",
    "hm1120.6{420}{419}}bh2.35737{it6{cd45449{an5.89968{dd8.39302{bt6.42634{539}{536}}{541}}aw0.018491{538}{537}}dr0.0024175{dm234.5",
    "{535}{533}}{532}}{422}}{423}}fp0.015889{ay0.365399{en0.965838{425}{426}}{424}}fm0.0039405{418}fr0.968145{dg0.019017{ga3.40636{4",
    "09}ix1{554}{583}}bs12.5{408}{410}}{417}}ij370171{ip1681.25{ai120{iq0.460485{fq0.982057{iu2{dj6.75{hq3.5{hq2{412}{439}}{562}}{43",
    "3}}hy0.633368{hw1.34225{525}{414}}{526}}ba0.778208{gr10.5{fy0.062294{560}{483}}{561}}gf10{522}gh139{522}{503}}ho0.106648{fc2.88",
    "477{434}cd127013{407}{435}}hg51{fu28{522}{503}}go0.661696{gy3.64651{cc625{hn0.337908{504}{503}}{504}}{504}}{503}}hu4.70163{hv3.",
    "94791{hv2.97827{523}{505}}hy0.422658{507}{506}}bi1.9405{bk0.490449{cu0.59049{560}ho0.141802{df151.187{509}{510}}{509}}ej1.78496",
    "{dq56.0826{508}{509}}{508}}{507}}ig0.054575{gv5.71703{ai516{514}{515}}cz1228.5{db17{515}{516}}{517}}fy0.58299{im14.835{hk5.5094",
    "2{hc51308.5{511}{512}}{512}}di0.110698{513}ai476{513}{514}}bj0.740532{511}{510}}do3.35717{db73{fu360{ap0.591251{519}fb1.93886{5",
    "17}{518}}cz1557.5{520}{521}}cd4961{fr0.946334{498}{496}}{497}}an0.017976{ai91{494}{495}}hc114.5{fg0.996572{bo0.059293{bw61.706{",
    "ba0.426092{gu2{572}{573}}{573}}hk0.636017{574}{571}}hy0.307768{fp0.377551{az2.14377{438}ed0.95627{584}ag0.5{588}{583}}am1.13743",
    "{582}ff0.968773{582}{583}}jb0.100499{587}aw2.3113{gv0.811278{438}{490}}{588}}iq0.995065{cd727.5{490}{491}}{492}}{493}",
};

char *randomforest_crafted_tree_11[36] = {
    "bx0.276492{bf2.61218{dv0.0471495{fz0.594912{bu0.181345{az0.700692{bn0.77616{ba0.808974{ec0.998913{477}{415}}bf1.26393{eq0.99908",
    "3{440}{460}}{454}}fv894{dj683{gh2600{gz0.7695{461}{481}}{462}}{463}}ez0.998994{464}bf1.10366{481}ed0.999883{479}{459}}en0.99997",
    "9{eo0.999932{563}{455}}bb0.639949{fa0.996183{456}{457}}gg25000{458}{453}}bq702{ea0.475733{440}{446}}ea0.216058{ao211.639{dp0.92",
    "0326{447}{441}}{447}}ed0.999534{dz0.724945{ak276{443}{441}}{443}}{440}}bk1.58545{bf1.23438{an1.05774{at20{cb3328{445}{450}}{445",
    "}}fb2.35307{450}{442}}hp9.6e-05{bj1.9849{fz1.11737{480}{444}}fd1.471{452}{451}}gg2944{442}{448}}am3.60412{gg5200{ea2.08925{dd2.",
    "97032{gg3600{ab98944{444}{451}}{452}}ew0.999375{gj3000{gi2600{444}{449}}{451}}{444}}{449}}ac73.825{452}{451}}gr2.5{bf1.25712{ex",
    "0.992338{528}{529}}fy5.68928{564}{589}}da269.652{bo0.663162{bg1.15278{530}{531}}{530}}dw0.0054215{529}{531}}dd1.70409{hb0.7{bi0",
    ".783555{bo0.595722{eh0.484822{546}bf1.47971{ex0.348421{548}cb1675{546}{548}}ac51.2696{546}fe0.250866{546}{548}}gd1.25e-05{bh1.4",
    "3717{547}{548}}be1.42105{em0.354693{547}{548}}{546}}ek1.00508{ib0.03125{468}{469}}fy1.54796{ey0.945578{545}gb0.574099{544}{545}",
    "}{545}}bv0.0125315{dw0.455892{551}ee0.850535{bn0.66425{fe0.254348{ex0.333333{549}bs87.5{551}bf1.96191{fg0.849369{551}{549}}{549",
    "}}{549}}fq0.972676{ce132{aj11{549}{550}}{551}}{550}}hn0.0750475{550}dy0.999108{550}{549}}go0.81{cm3{cd875.5{543}{542}}am1.51431",
    "{543}{542}}im1.42487{557}{556}}ac13.6786{ar0.001158{bf2.04{al2.27217{470}fz1.95023{471}{472}}{416}}cc348.5{437}cn4.5{di6.2e-05{",
    "439}{566}}dj5.83333{410}{436}}dt9{cm7.5{gv0.5{hl3.65366{fs0.924299{540}{538}}ay0.003204{533}{532}}ib0.0003205{476}{475}}bh1.203",
    "95{bv3.54119{467}bj7.60233{534}fw109.5{537}{535}}{466}}cd1198.5{dk33{478}{473}}gc0.002474{gx0.5{536}{474}}eb0.114624{465}{427}}",
    "ho0.129139{il381543{ac46.5443{be1.33796{hz0.124516{if0.360325{fw13{498}{583}}{499}}ey1{fx2.94536{429}{430}}il173028{432}{431}}d",
    "b279{en0.97085{578}{411}}au3.87948{fb6.59166{579}ep0.84445{579}et0.000298{579}{580}}is0.640125{dk268{581}{580}}hq10.5{581}{580}",
    "}et0.054059{az2.49403{iq1{427}{527}}bo0.048825{595}ep0.727379{fz1.16626{bm0.428169{fz1.16506{596}{595}}{595}}{595}}ax0.285878{5",
    "96}{595}}{422}}fz1.29186{ff0.902925{420}{421}}{419}}bq1276{dv0.962133{ah4.5{fg0.897016{ht4{ea2.86679{592}dx0.325203{593}{594}}i",
    "x2{428}{591}}ig0.044432{hh2.00459{553}ep0.839874{552}eb0.056051{ff0.96777{552}eb0.0379065{553}{552}}ee0.83702{553}{552}}ep0.838",
    "766{572}gz0.811067{573}{574}}ho0.25104{et0.033222{bu4.3094{hz0.234211{576}{575}}bl2.01112{576}{575}}fk0.395846{dy4.32212{575}{5",
    "77}}hj1.50962{576}{577}}hu0.686697{fc0.451431{412}{569}}gn73.8889{570}{569}}gt8{iu1{dk687.5{gc0.37507{468}{488}}ec0.948526{dp2.",
    "21993{de1.96815{559}{558}}{559}}{558}}cv0.512{588}hp0.49{586}eh0.50222{585}el2.33161{586}{585}}ge0.740119{423}fx4.41916{555}{55",
    "4}}bo0.385368{ab1.43391e+06{417}{418}}ew0.999788{424}ih0.42109{426}{425}}dj5{am0.703387{hy0.153286{dj0.833333{dr0.542266{fu298{",
    "dy1.00791{516}{515}}{517}}{515}}bv0.215539{cn7{bb0.544866{561}bu0.0905735{486}{560}}dc1.5695{561}{483}}bg1.5211{517}{518}}hv5.2",
    "2934{ie0.039921{dk247.333{cz734{510}{511}}ac2.03275{gy17.6778{511}{512}}{511}}gw4.30515{hx23.7957{562}cc23623{508}{509}}is0.771",
    "769{fz0.422092{509}ab50798.5{508}{509}}dk218{509}{510}}bu0.558753{fu238{513}{514}}cd89738.5{ib0.0007305{gm3.99479{511}{512}}{51",
    "3}}{513}}ap0.603688{eq0.40523{bc0.363119{bs8{ba0.714962{590}{407}}fg0.888452{bo0.441509{524}ic0.001642{525}co8{525}{524}}{408}}",
    "hx1.51585{521}cj0.241914{414}{523}}gv2.53279{bf1.70804{526}dj2{bv1.23516{435}{522}}al1.61746{489}it230{bx0.42578{436}{414}}{567",
    "}}dd3.1176{519}{520}}gw3.02834{hg39{aj4.47436{ik12.0072{434}au1.39846{439}{525}}bw5.587{522}hm12.5748{522}{503}}em0.223584{dk80",
    ".6667{504}{505}}gy3.2817{503}fu38{503}{504}}gk4.16888{cc4898{ge0.930197{505}bl0.138412{506}{505}}ce8664{506}{507}}aa15600.5{fd0",
    ".797252{am0.81732{508}{507}}{507}}{508}}it100{hc64{am0.287287{bz0.179333{dr0.288723{cn7{dg0.002739{500}{483}}{485}}{486}}ho0.03",
    "89765{ig0.905875{cc151.5{ib0.0563495{487}ff0.948853{ej1.81128{487}{482}}{487}}{482}}{482}}is0.5101{501}{490}}hq1{bq22.5{484}ao1",
    "1.2467{433}{409}}hr48.5{aq0.171577{fo0.857726{592}bp5{565}{406}}in0.371155{fs0.877207{do10.1595{573}{574}}{572}}bl1.31243{522}c",
    "w0.255535{584}{571}}bc0.377437{ad457{hy0.28372{dq15.261{584}{583}}cp3.5{406}{584}}{588}}it15{582}gi1251.75{583}{438}}ee0.997765",
    "{fg0.998036{fa0.25{491}ah14{413}{406}}{492}}{493}}iq0.997543{iw2.25233{er0.361465{am1.74325{du0.2{588}{565}}hc1.5{587}{588}}{43",
    "8}}{494}}bu0.029816{de2.16752{497}{496}}{495}",
};

char *randomforest_crafted_tree_12[37] = {
    "bs7.5{fr0.959125{gl1.1107{dr0.187123{br0.129317{493}em0.25479{at30.5{dt0.0032905{fb0.240838{491}hd0.109846{jc0.809342{587}{500}",
    "}{490}}{413}}{492}}bf7.275{fy0.18283{565}ge0.296696{590}{489}}er0.0724295{588}el1.76583{ee0.941105{583}hf2.5{ia0.0481435{582}fv",
    "4.60191{582}{583}}{588}}eb0.304664{583}{584}}id0.13848{ee0.848662{ai41{fy0.76339{407}ah5{525}{414}}gz0.127093{433}{567}}he0.008",
    "316{434}{526}}ap0.307885{fg0.914118{486}cn7{483}{485}}ic0.1{cz24{561}{501}}cv0.214958{ez0.505{fr0.934759{482}cc96{482}{487}}{48",
    "7}}{482}}gd0.997385{hq1{494}bq85{hd0.0732285{es0.065594{523}by0.308034{590}{439}}hv3.62729{490}{491}}{492}}in0.029586{cb4391.5{",
    "an0.0097225{498}{496}}{497}}{495}}fu174{br7.07543{df53.6583{ij379.912{je0.171496{522}{435}}eq0.618642{503}ai56{522}{503}}ea0.76",
    "1202{dy2.06957{du0.0620305{506}{505}}hn0.388047{505}{504}}ai120{504}{505}}fx1.17111{im14.0495{hl5.14042{509}ht80{561}fr0.997682",
    "{560}aj4.98563{485}{486}}hc25475{509}{510}}gf896{bu1.19285{gk4.4016{507}dp1.57073{508}{507}}gy8.60644{506}fg0.843956{506}{507}}",
    "dt0.270157{gk4.65587{508}{509}}{508}}hq1{di0.0842375{ay0.792071{ea0.600187{520}{521}}fx1.26636{519}{520}}bv0.250238{gy26.5117{b",
    "m0.85281{516}dk409.333{516}{517}}{517}}dq86.8921{515}{518}}hk5.62122{eb0.114411{ce86624.5{512}fb1.9549{513}{512}}dq65.2087{im14",
    ".4117{510}{511}}{511}}fz0.256279{dg0.336528{514}gj21.5{513}{514}}{513}}eb0.082583{be1.17547{ai219{ex0.977336{ba0.807529{cb480{g",
    "g344{cw0.255535{470}{469}}{471}}ap0.0555615{bu2.51668{465}{473}}gc0.0066285{478}{472}}hg27.5{dg4.2e-05{448}{442}}bl0.0343495{45",
    "1}by0.000517{dr0.01105{440}{480}}{474}}cu0.69255{bi1.92505{fv92.8318{gh3584{445}{450}}{445}}an1.19931{450}{442}}al5.57521{ha0.6",
    "4{460}{564}}cm2.5{fk0.000593{589}{528}}ee0.996809{531}bf1.27202{530}eq0.999267{530}{531}}bh1.19391{ec0.999773{fd1.85417{dd3.276",
    "24{461}{476}}gz0.81{am4.53588{475}dn7.27583{ak170{531}{529}}{530}}bj6.94034{gb1.5e-06{da401.74{dk240.5{529}{528}}{529}}{589}}{5",
    "89}}az0.456435{gu3{481}{459}}bm0.889745{ff0.90016{fp0.005938{479}{463}}{462}}{464}}bg1.25201{bk0.618273{446}dn2.49591{dy2.80944",
    "{480}{468}}iq0.970255{466}hl0.169925{564}{467}}an0.22502{aa25696{441}{447}}dk675{440}da1390.44{443}ba0.809968{441}{443}}bi1.117",
    "06{ed0.962018{gd0.50057{dw0.42381{560}bc0.427503{hh5{br11.2{412}{411}}{412}}{411}}hb0.348961{au2.38968{566}ij13.3647{527}{439}}",
    "hu0.206312{hz0.63786{au2.63791{552}{553}}dt0.121746{fo1.41565{cn274{553}{552}}{552}}{552}}{553}}aw0.0023165{fp0.0081055{fr0.999",
    "997{458}{453}}ec0.999598{456}cy612{479}{457}}ee0.995913{hb0.4165{ac29.5562{477}{454}}{563}}fw147{415}{455}}fp0.15083{cc5100{dv0",
    ".0119825{444}gg2800{444}cu0.534393{bt2.18541{452}{451}}fz2.01947{cc3600{449}{452}}{449}}ez0.993175{452}{451}}by0.076158{fo0.741",
    "9{ek0.227377{595}du0.563542{gb0.835988{596}ej0.415093{596}{595}}dp8.29639{595}{596}}{502}}hz0.137699{484}{406}}hg3134{fp0.30316",
    "9{is0.765428{cv0.247726{ix2{fe0.219726{593}{592}}du0.012153{dv0.772728{591}{438}}jb0.614426{gv1.01194{524}{525}}am4.08429{525}{",
    "524}}dd5.54835{co4.5{hu0.454146{fb6.93849{df4788.91{585}{586}}il56544.6{488}{586}}{586}}il458924{ba0.767196{429}{427}}{429}}fw6",
    "{hj1.77923{409}{428}}{430}}ad49{ia0.372443{du0.0714285{ar0.201747{468}{571}}fy0.461514{hv0.424389{569}fg0.989988{bh9.84921{570}",
    "{569}}{570}}{569}}ep0.843357{bl1.85437{559}ed0.895231{559}{558}}hm0.7603{gw0.5{559}{558}}{558}}fn4.08606{be3.19902{hc32{fm4.469",
    "8{576}gz0.879646{587}{577}}{577}}de3.12762{575}ea3.4392{576}{575}}cv0.4608{ia0.116055{572}bm0.366163{hr9.5{573}{572}}{573}}dq50",
    "6.93{572}dx0.308642{573}{574}}gs2{ge0.483334{cm4.5{hn0.083386{437}fy0.941457{em0.289548{hh11.5{542}{543}}{542}}{543}}by0.052478",
    "5{416}cm5.5{410}{408}}el1.15498{bg1.76905{550}bm0.826014{ek1.41836{bm0.815715{549}dg0.02241{551}{549}}fe0.249556{551}fg0.85525{",
    "549}{551}}bb0.638708{551}{550}}if0.739564{dv0.669735{bj0.0027745{557}{556}}{556}}ii999.821{488}{562}}bo0.539972{bp6{dk56.7{499}",
    "ho0.201809{ig0.160547{584}{583}}eb0.336477{588}{587}}fg0.90119{hl0.775128{ia0.00114{544}{545}}ht22{bt1.56535{544}{545}}{545}}cb",
    "734.5{ip8994.75{579}bh3.28013{578}da658.216{579}{580}}dk283.5{fe0.197653{581}{578}}dl169.062{581}{580}}hk2.04245{bh1.44118{eb0.",
    "458552{gc0.0230805{546}{547}}hs26{547}bf1.43333{by0.003778{547}{548}}{548}}bx0.000387{bn0.718109{fq0.975451{546}{548}}{548}}ex0",
    ".357843{ak41.5{546}em0.353293{548}{546}}{548}}hs37.9369{cn6{bg1.43654{538}bw10.3574{587}{582}}bn0.73967{436}gb0.019972{bj8.3820",
    "6{ab2.00924e+06{536}{532}}{535}}{533}}iq0.425629{fb6.62914{555}{554}}bi7.99842{534}im8.42583{540}{537}}fe0.186682{ar0.0315515{h",
    "p0.05647{419}ih0.466419{421}{420}}gd0.495262{ez0.909455{hh501.415{432}fg0.832779{431}{432}}{422}}{423}}ed0.922381{ed0.919864{dp",
    "6.0723{bw133.758{524}{554}}{426}}ee0.878982{425}{424}}eo0.929541{cc28750{438}{418}}{417}",
};

char *randomforest_crafted_tree_13[34] = {
    "bx0.437744{bb0.572211{cp10{hh5{dy2.65352{bh2.72573{dh9{ez0.737708{ao10.5239{557}io0.716228{557}{556}}{415}}fn1.46557{bp6{498}de",
    "1.79144{566}{439}}{433}}fo1.67541{hx7.6844{ei0.75{cb189{bb0.345847{502}{411}}{488}}{527}}{406}}{484}}bo0.260865{ep0.778261{fk0.",
    "925478{hw1.15025{eh0.908783{596}df2694.2{595}ed0.869533{596}{595}}fh0.880562{hz0.557473{596}{595}}{596}}{595}}hb0.439{ho0.64{58",
    "6}bx0.0446685{ee0.843928{ax0.756896{586}{585}}{585}}{586}}fc2.80386{aj304.663{559}{558}}cp5.5{559}{558}}df19.9512{dv0.944445{43",
    "7}bd3{408}{410}}im9.62652{416}{409}}fe0.163829{ek3.18293{dd5.51167{bu1.43416{412}ah13{ey0.696022{412}{429}}{411}}eh0.407415{ds0",
    ".0085575{430}{428}}es0.001735{431}gi17.6178{431}{432}}ab13260{br40.9949{ax3.57911{eo0.89392{572}dv0.909091{572}{573}}bj7.53715{",
    "571}{574}}hv0.460247{569}eu0.0457685{gl1.5{570}{569}}{568}}bi7.20925{dr0.000435{fp0.261921{575}{576}}{575}}em0.215552{577}{576}",
    "}ad24.5{aq0.062623{bh1.99036{fe0.244848{hy0.209153{545}{544}}fz1.42532{545}{544}}fx0.960005{542}{543}}cw0.082354{524}ge0.900862",
    "{428}{525}}hj1.50811{et0.0181155{ab16013{ib0.029298{bv2.55337{580}aa952{579}{578}}{579}}bn0.278302{fb5.09923{580}{581}}dx0.375{",
    "586}{580}}dc3.01852{586}{578}}gz0.612144{499}hn0.387023{ij2.59993e+07{iv2.5{592}{584}}{587}}{588}}in2.51489{fe0.195932{bs137.5{",
    "in2.44013{417}{423}}{418}}bj3.03966{hc50{eo0.895836{ik12.4615{552}{553}}{552}}{424}}aj211.865{425}{426}}cy177{fd0.572122{420}ad",
    "3175{fe0.215531{jd0.32{593}{591}}gy3.86309{438}{592}}{419}}ih0.453259{422}{421}}de0.618468{ec0.974226{eb0.305019{gb0.6561{gz0.6",
    "9606{489}{411}}ex0.666667{562}{560}}hb0.595{bf1.44596{gh157{fc1.87817{dy0.997772{547}{546}}{548}}fe0.241699{548}{547}}ex0.34693",
    "9{gh563{546}bh1.48395{548}{546}}{546}}bh1.9{be1.815{aw0.093831{550}aw0.149574{551}{550}}bp31.5{549}{551}}fg0.850646{dy1{551}{54",
    "9}}fa0.641072{gi35{551}{549}}{549}}bo0.656192{bq236{gs2.5{563}bh1.26923{ap0.000387{dj146{479}{455}}{454}}fg0.80344{440}{477}}fx",
    "0.503044{ez0.997423{dm266{456}{457}}ff0.900182{453}{458}}bv0.986969{440}{468}}bm0.889563{az0.507655{dk408{461}{462}}en0.999946{",
    "460}{479}}bh1.10878{bh1.0893{481}eq0.999987{464}{459}}{463}}bl0.0584425{bk1.56172{hf12{bv1.09965{fa0.98726{gh3328{445}{450}}{44",
    "5}}ea1.17566{450}cy248{442}{444}}bv1.06464{448}fh0.703775{451}{442}}az0.639889{al4.4148{fx2.78533{dz2.2423{471}db57{473}{465}}d",
    "o3.06977{474}ge1{478}{466}}bl0.035171{gz0.81{bq981.5{bp98{bl0.031162{bt6.44242{530}bq307{531}{530}}{531}}dz6.8757{529}{531}}{53",
    "8}}ee0.997775{528}aj176.23{529}{528}}gh8797.5{fu199.5{564}{589}}{534}}dg1{cb4700{dc3.10981{452}fq0.999937{gh2800{444}bw2.10288{",
    "gh3000{449}au1.96972{ay0.0020455{452}{451}}{451}}{449}}{444}}ft127{452}cd5600{444}{451}}ig0.006542{451}bt3.63293{467}{436}}bn0.",
    "753988{fd0.22502{gi25696{441}{447}}fe0.0467075{fd0.389133{dl564.658{443}{441}}{443}}en0.964579{dx0.31383{gs22{es0.001776{587}{5",
    "82}}{432}}he0.0028805{489}{436}}ho0.022951{427}{429}}eo0.998713{hn0.052642{hb0.112859{ga28.6439{472}du0.001883{537}{541}}fa0.96",
    "2963{bu6.8507{540}{533}}{470}}ho0.0989885{ie0.385417{el1.00527{538}{536}}{469}}bg1.16216{555}{554}}bh1.21902{hr38{hm961.472{589",
    "}{476}}{475}}gs4{480}{446}}ea0.130825{in0.031447{in0.029586{gn223.329{ii12{eh0.486911{496}ig0.904762{487}if0.755501{cm7{482}cw0",
    ".049001{482}{487}}{482}}ar0.013841{ff0.967033{485}cp7{483}{485}}{486}}{497}}{495}}go0.739744{az3.09995{gn74.9513{az0.967788{bp3",
    "{ig0.555086{523}{560}}{590}}en0.956649{er0.487964{490}io7.33721{486}{485}}{561}}ed0.998257{491}{492}}{493}}gx0.306661{500}{494}",
    "}gf1970.5{ai113{aj6.06922{er0.376765{fk0.190989{522}ah1{439}bp2{525}{435}}ib0.003524{504}br6.22692{du0.1125{503}{522}}ib0.00435",
    "2{504}{503}}bo0.605143{ar0.116724{fd1.90067{be1.5{413}em0.394751{501}{561}}iz0.436449{414}{567}}hl2.12488{eu0.0019175{407}id0.0",
    "30693{588}{587}}er0.176051{584}ey0.969224{583}{582}}{526}}gf808{hy0.468865{ce8883{bp2{hj4.08741{hz0.238285{bs5{588}{584}}{587}}",
    "fn1.47845{582}bn0.252744{584}{583}}fd0.759536{hm53.7324{506}{507}}{506}}{507}}gs13.5{ah10{aa2431{572}hl0.600559{573}{588}}{565}",
    "}{505}}bv0.442495{dm4.83333{510}ac2.03847{511}{510}}cc23848{ip966.767{aj5.15491{508}{507}}eb0.12775{gf1192{508}{509}}{508}}{509",
    "}}cz1214{hk2.8363{bi1.18491{516}cm12748.5{515}{434}}ab140792{hv5.08667{cc48288.5{510}{511}}{511}}bi1.30957{514}hc71222{512}{513",
    "}}gm4.06367{bn0.700316{521}{520}}de1.33379{ce224984{is0.85832{516}{517}}{517}}dz0.690998{518}{519}",
};

char *randomforest_crafted_tree_14[35] = {
    "eq0.289972{bh2.59259{hm477.425{dc1.90445{co5{dv0.831551{ho0.64{eh0.25376{415}{561}}in0.696159{557}{556}}bg2.08499{fy1.52721{545",
    "}{544}}ge0.393337{bf2.56{az0.491069{543}an1.40117{543}{542}}{542}}{543}}ai10{ib0.057471{ie0.504233{cv0.167772{482}{487}}cm6.5{4",
    "82}{487}}{482}}dn0.039264{486}{501}}ah4{ec0.951162{aj10.725{ig0.680385{408}{437}}{410}}go0.358709{gs12.5{407}{438}}jb0.739464{5",
    "24}ig0.0090325{490}{525}}ak11{bh2.25{566}{433}}bh2.44444{dq5.28271{439}{416}}hm9.90904{590}{413}}bx0.040111{fv12.9192{cn14.5{42",
    "3}{422}}dx0.278749{421}ho0.105734{419}{420}}fh0.712272{ac60.3481{424}ht10{425}{426}}bm0.746395{417}ir0.275736{524}{418}}ik3.072",
    "54e+10{ie0.000615{ha0.751473{gs7{dz3.69626{at8.5{cw0.5215{406}{502}}{527}}ej0.408892{595}ak520{fz1.17144{bw0.434003{596}{595}}{",
    "595}}{596}}bo0.410859{492}{491}}db120{ad903{an0.070551{fp0.299038{553}dg0.08303{fp0.300335{553}{552}}{552}}{552}}{492}}{493}}bz",
    "0.0254185{in0.689246{ds0.0002475{iq0.428084{488}dl672.238{570}ic0.006135{gi6.76176{570}{568}}co3.5{569}eh0.522953{569}{570}}dv0",
    ".998914{558}fc3.14118{do5.94331{559}{558}}{558}}de3.96465{ac20.5008{ak21{553}df275.12{576}{575}}fd0.838593{585}fn2.5517{585}{58",
    "6}}ew0.588715{he0.002857{ez0.047447{577}fo2.58164{576}{577}}{576}}{428}}ff0.970251{ih0.639335{db106.5{bs7{500}{565}}an2.0177{40",
    "6}{409}}cw0.0876485{485}{483}}ek3.52941{484}gd0.913984{dl763.108{ek4.26597{573}{571}}{572}}ds1.2e-05{574}{573}}cz3002{494}bv0.0",
    "1494{aa565212{496}{497}}{495}}gy3.8248{eh0.192291{bh1.24173{bv1.58483{au1.98788{fd1.07039{hp9.6e-05{bu0.73596{bo0.660314{479}{4",
    "60}}de1.16825{cd3584{445}{450}}{445}}{448}}aa4608{442}ex0.98738{450}{442}}fr0.999988{bm0.88928{aw0.002271{ig0.00317{479}{476}}{",
    "461}}{462}}ba0.809983{bh1.10878{dm783{481}{464}}{463}}az0.547151{gt2.5{481}{459}}{468}}cn6.5{ej0.0505245{co2.5{bf1.28307{fd5.39",
    "231{528}bc0.489872{529}{528}}dp5.44938{564}{589}}bm0.885655{531}bl0.024235{dq26.6769{529}{531}}cc1522.5{530}bo0.665947{531}{530",
    "}}ho0.0019815{478}{470}}hl0.196159{eb0.006976{by0.0003855{467}{465}}bo0.653213{466}{473}}bu2.7548{fy2.67408{471}{474}}ir0.46763",
    "9{472}{475}}bo0.635242{fh0.703553{am0.367497{da858.375{ga211.622{441}{447}}{447}}fv529.889{ax0.000199{441}{443}}ga495.531{443}{",
    "447}}ej0.5612{gi176{ar0.08294{411}{468}}{563}}gb0.469265{dn5.54458{ds0.005903{429}{412}}{427}}{560}}al1.67189{dz0.422478{eo0.99",
    "9958{at21{df40.1992{477}{454}}dl146{440}{455}}dm346{df187.093{456}{457}}ec0.999797{458}{453}}cw0.343{fd0.475733{440}{446}}fz0.7",
    "60812{469}{480}}cc5000{dr1.7e-05{444}ce3000{gj2600{444}{449}}gb0.0002765{449}bn0.756337{do3.01265{ax0.004085{451}el0.002046{452",
    "}{451}}{451}}cc3600{451}{452}}fv146.889{452}{451}}by0.17053{aw1.19093{hb0.595{fy1.7547{bm0.860594{bn0.722456{dz0.993426{546}fm0",
    ".822655{aw0.002887{546}{548}}bm0.855521{546}fa0.797489{548}{546}}ce750{ar3.35e-05{548}{546}}{547}}bf1.40529{547}df41.1906{548}{",
    "547}}cn9{al5.28477{436}gs5{538}hk4.43316{ip3.58807e+07{539}{532}}{536}}et2{cw0.0270975{554}is0.82895{555}{541}}gb0.006518{534}d",
    "a452.493{537}{535}}hp0.084037{bo0.514551{bh1.94444{go0.0337115{551}dg0.002733{551}fa0.96{549}{551}}fk0.249375{el1.00321{551}{54",
    "9}}{549}}ek1.43496{bp23{bo0.545686{549}{550}}bn0.671346{551}{550}}{551}}hq5{412}{562}}gs6.5{eu0.185225{ht20{ff0.954749{429}{588",
    "}}{578}}ff0.979967{br113.651{en0.951988{579}dx0.140394{579}{580}}{580}}ip233468{et0.015473{581}{580}}{581}}by0.0754915{ix3{430}",
    "dw0.430951{db685.5{hx207.817{432}{431}}{431}}{431}}cb1696{592}{499}}fr0.959599{dw0.421736{hw2.49697{dq313.602{az1.46009{439}it1",
    "3.5{ab14219{584}{588}}{588}}jb0.185709{587}{588}}hy0.195947{dw0.144233{582}bv0.688406{583}{582}}bf12.05{hx12.7827{584}{583}}iw4",
    ".52632{582}{588}}fv3.9267{if0.234028{fu41{523}{567}}be1.2{525}{414}}{526}}dk35.5{522}cb464{503}df52.455{bz0.109574{525}cu0.5104",
    "78{524}{503}}{504}}hu2.86255{ac2.89821{bu0.476629{cd221556{516}{517}}go0.0953195{hb0.0012545{435}{518}}gx2.20764{434}gd0.488508",
    "{515}fb1.81103{516}{515}}bj1.2664{bk0.560904{519}{520}}ha0.312601{521}ds0.03319{gq0.103151{au2.63928{593}ar0.0829095{593}{594}}",
    "{591}}{592}}dk193.167{gv4.03147{ia0.157664{cy2.5{fv2.46497{gy8.45106{506}dq44.1832{506}{507}}{505}}dl22.6186{im6.68624{561}{483",
    "}}fe0.086262{ax0.999165{560}{486}}{489}}cc2022.5{aa1874{504}bz0.14338{504}{505}}{505}}df125.368{ab20373.5{bv0.722711{507}{506}}",
    "{507}}hn0.313654{eb0.127249{509}{508}}hw3.56577{io4.53809{507}{508}}{508}}bv0.34855{ab184967{512}bt1.21676{514}bj0.565419{em0.1",
    "54897{514}{513}}{513}}bl0.119098{hi15{510}ew0.751488{im14.4151{510}{511}}bw9.59683{511}{512}}{509}",
};

char *randomforest_crafted_tree_15[37] = {
    "bx0.496779{fr0.998924{fz0.339036{dc2.95065{ez0.529247{dz0.633691{bc0.305007{ds0.132951{bh8.98691{502}{527}}hn0.808312{ew0.31557",
    "8{553}{552}}fe0.203572{552}{553}}hb0.35{439}eo0.978957{ba0.727493{412}ec0.946372{bf2.5{412}{411}}{412}}{411}}bb0.51273{gz0.9{bb",
    "0.512{dk423{416}{585}}{566}}fa0.333333{488}{565}}io0.103997{557}ed0.90025{556}ec0.953728{556}{557}}gz0.855{fq0.975762{az0.90638",
    "8{cc134{ho0.014412{548}{546}}{547}}el0.997679{cc2475{548}bm0.855179{548}{546}}bg1.45161{547}fu72.5{546}fb3.16654{548}{546}}dl35",
    ".5{fb2.47826{548}hr31{548}{547}}{547}}aq0.262144{az1.21947{go0.178703{550}ez0.691523{550}{551}}ey0.983333{bq55{fn0.721959{549}h",
    "h15{549}{551}}fp0.43219{551}bf1.925{551}fb2.82865{549}{551}}be1.95{550}br117.5{551}{549}}ec0.965489{562}{560}}gr0.5{bb0.493895{",
    "bw3.39209{484}bx0.387055{409}{433}}if0.299997{416}ip8.91775{437}cu0.560966{408}{410}}bb0.228588{bb0.207149{az3.19191{bb0.192584",
    "{hy0.782144{dn6.28537{559}gn1.82557{559}{558}}{558}}{558}}et0.0283825{dg1.2e-05{in0.390988{574}{573}}fd0.345226{572}fz0.203826{",
    "573}{572}}cu0.69255{573}{574}}in0.415381{bk5.90056{571}{573}}du0.142857{568}hv0.445093{569}gt4.54762{570}{569}}ej3.72029{ex0.16",
    "6667{bb0.471884{hw1.25318{dp1.72208{580}{498}}{584}}{579}}{590}}gq0.159371{bz0.0020255{575}gc0.8956{575}{576}}db742.5{gz0.82262",
    "3{588}{587}}es0.0282065{577}{576}}ff0.936503{bm0.851391{dv0.581731{iv2{gd0.221106{gy4.84123{594}{593}}{592}}{591}}bf8.2{hh52.35",
    "71{gl0.484275{436}{429}}{427}}ed0.923774{ia0.278636{428}{431}}aj35.6931{432}{430}}fm0.0919365{io0.911648{hg744{cn9{480}{473}}{4",
    "65}}bx0.0379595{478}{471}}bs41.5{ik872002{gb0.152167{472}{469}}be1.05677{ac24.105{538}{539}}{470}}dm212{bu6.69958{dn6.52065{555",
    "}if0.016622{536}{541}}ai969{537}fg0.850217{532}{540}}ir0.749383{hw3.38202{554}{535}}by0.000606{534}{533}}er0.374081{iw1{eu0.239",
    "549{dt0.029912{fk0.288382{489}{578}}{499}}gx0.660964{hc1{bw75.0375{hr20.5{581}{580}}{580}}{581}}{579}}gh352.5{bj3.44103{406}gh2",
    "49.5{gl1{bm0.707281{584}{582}}{583}}gu2.5{cd1218{524}{588}}{587}}fo2.22556{586}be1.30952{585}{586}}dy3.70345{fw4{an1.32064{543}",
    "fd3.8471{542}ez0.493305{543}bs69{542}{543}}fz1.31195{545}am1.54089{544}hk0.994631{hj0.987506{545}bu1.55779{544}{545}}{544}}fb6.",
    "33545{ax1.48091{ex0.1875{428}{430}}bk3.95266{524}gk1.10128{525}{524}}ed0.867888{dz7.78035{bk7.22238{cb195.5{596}{595}}{596}}{59",
    "5}}{595}}cv0.1982{bs136.5{bq1156{ez0.973143{dq49.1456{438}{420}}dn6.37666{474}{419}}fs0.999919{417}gi20905{422}{421}}ev5.5e-06{",
    "fq0.999982{du0.0016235{et0.099606{425}ij4.07655e+06{425}{424}}fh0.702298{466}{475}}hn0.126017{dk706{cq1{468}{476}}{467}}{426}}f",
    "e0.195917{bq1256{423}{418}}fq0.999976{418}{424}}fz0.5{fc0.353519{gb5{bm0.882408{el9.6e-05{fp0.0053765{453}{458}}ep0.999966{bo0.",
    "639013{455}bc0.489928{479}{456}}{457}}ey0.998757{eh0.000162{az0.469397{463}bn0.779954{479}{462}}{461}}cy908{459}az0.459695{481}",
    "{464}}ap0.0020875{br91{bq65{415}{454}}ft109{440}{460}}gz0.7695{477}{563}}bg1.26564{fd0.437832{440}{446}}bj0.502968{ex0.995282{f",
    "x0.659284{447}fk0.0001565{441}{443}}{447}}dm971.5{443}{441}}bu1.87535{hg12{ea1{bk0.654095{443}{480}}an1.05774{cy204{gh3328{445}",
    "{450}}{445}}cu0.69255{450}{444}}ac34.4386{442}{448}}fc4.36121{dl110.288{bw8.1189{gh3000{cd2600{444}{449}}cd3400{451}cn5{dp2.314",
    "2{452}{444}}dn3.20669{452}br139.324{bl0.004753{444}{452}}{444}}ds1{449}{451}}fd1.42691{fd1.19931{450}{442}}fn0.0010075{cd6400{4",
    "44}{451}}{452}}cu0.81{dv0.0163725{bl0.024584{ga33.8454{529}{531}}ap4{530}{531}}{531}}dq22.2558{ea4.26757{564}fe0.0009555{gi1262",
    ".5{528}bk5.92283{529}{528}}{528}}gh2139{589}ai514{ba0.809789{529}{528}}{589}}fx0.497413{fy0.014378{dy0.10706{gq0.194332{az0.7{4",
    "86}ff0.958589{cv0.262144{cb97.5{ib0.0565135{487}{482}}{487}}ib0.057471{ih0.955556{482}{487}}{482}}co6.5{483}{485}}gi29{496}{497",
    "}}fv0.0108465{if0.435611{407}ea0.555114{561}{501}}if0.000181{496}{495}}dw0.006024{494}ih0.0005615{493}ir0.99422{fg0.964973{ep0.",
    "860884{id0.0237135{ag70.5{500}{560}}da68.0215{gr4{501}{483}}{485}}{561}}io0.033416{491}gj2.5{588}{490}}{492}}dq54.5956{gh1437{f",
    "k0.177878{ai76{cd233{hm13.221{522}ds0.270599{503}{522}}{503}}ir0.61012{cz222{504}gt6.24742{504}{505}}bv0.918852{506}{505}}gu10{",
    "gq0.183608{hs16.2678{hy0.558215{cs1{587}{525}}{414}}dt0.000275{582}{588}}ff0.969445{gd0.569843{439}{523}}ba0.658065{584}ix2{584",
    "}{583}}ia0.246352{413}{526}}dk140.167{il0.18651{cz407{506}{507}}bj1.70626{ap0.718376{hl1.97707{414}{505}}{434}}hj1.64274{435}{5",
    "67}}hu4.93057{507}ff0.927107{508}hs15.5983{507}{508}}hl2.0215{bk0.432026{bq372.5{gy24.7434{515}{516}}fx0.827299{517}{518}}bj1.2",
    "5716{gn1499.92{519}{520}}fw1{iq0.923221{587}{588}}{521}}fy0.571874{cd114856{bv0.319416{513}{512}}{514}}fy0.631933{hl4.59147{511",
    "}cc69283{511}{512}}fy0.702496{510}ia0.101934{509}ip1270.55{508}{509}",
};

char *randomforest_crafted_tree_16[35] = {
    "ad711.5{ek1.57272{dy1.00304{ed0.948561{eb0.198214{bm0.801555{fl0.5{aw0.510348{411}fk0.133333{411}bb0.527565{411}{412}}{527}}ac2",
    ".46018{ij596.6{hs70.3082{561}dm38.8333{483}{560}}{560}}ht3{cv0.262144{487}{482}}{523}}bf1.70357{gr2{eo0.905475{550}{551}}bo0.59",
    "9266{bm0.855822{ew0.744672{546}em0.353116{548}dz0.999921{548}{546}}ak51.5{el1.01326{gb0.00707{546}{548}}{546}}{548}}ba0.808276{",
    "dy0.997325{fe0.232892{547}{548}}dl22.5{fr0.948229{548}{546}}{548}}{547}}bo0.52218{dy0.999582{549}ay0.0006015{549}fs0.921433{549",
    "}ex0.3{549}{551}}cz127{bs19.5{549}{551}}{550}}bh1.30264{bn0.756116{br136{aa328{477}gj442{454}{440}}en0.999988{fk0.0002435{456}{",
    "455}}{457}}bn0.779933{cb1000{gs3{481}{460}}aj349{bc0.489921{479}{461}}dm786{ee0.999228{458}{479}}{453}}be1.10878{gh40000{dk908{",
    "481}{464}}{459}}bb0.639968{462}{463}}gh11680{be1.76308{563}{415}}fp0.012506{ex0.995777{bi0.664913{cp4.5{441}{447}}{441}}{447}}{",
    "443}}bh1.22917{io0.0442425{cp4{gt3{bi7.09039{bn0.770087{ea4.48328{564}{589}}ak196{dj93.75{528}ey0.99573{529}{528}}{529}}cb1767{",
    "589}{528}}ez0.995608{cy134{bt6.18307{530}{531}}fs0.999911{530}{531}}{529}}dj62{if0.000834{by3{448}{442}}an1.83252{468}{467}}fc1",
    ".6266{dc2.21803{cc3584{445}{450}}df42.174{ce3328{445}{450}}{445}}bj1.90476{450}{442}}fd2.26374{du0.0181625{dz2.626{476}is0.8085",
    "72{474}{475}}hl0.196159{br36.6154{473}{465}}ek0.0338135{471}{470}}fh0.739115{hz0.000108{da248.911{472}{466}}{478}}dc6.40474{bm0",
    ".886315{554}{555}}hs38.4501{he0.12362{538}ev8.5e-05{532}{541}}ea6.45289{534}{537}}bh1.25583{dz2.42333{gg3200{cd2600{ai88{444}{5",
    "87}}{449}}bm0.876461{fs0.99981{gu4{fs0.999804{449}{451}}{451}}gj5600{cc5100{444}{452}}dn3.47113{451}{452}}aa5900{gi3600{451}{45",
    "2}}{451}}bs189{449}{452}}fy0.993337{bn0.759479{dz0.722737{bk0.399931{441}{440}}{443}}{446}}ee0.888242{dm223{gz0.855{di0.0262775",
    "{432}{522}}{439}}cd227.5{bw0.405187{596}dq68.9871{595}gv1.32096{595}{596}}{595}}hl0.72533{bv0.672887{469}{480}}ik669982{ba0.769",
    "729{gb0.674049{430}{438}}{427}}gy0.297882{468}{429}}at3.5{fr0.957059{dm9.16667{bw0.661369{cw0.100001{dj6{501}ek1.67527{487}ab32",
    "0{482}{487}}ic0.103448{cb139.5{487}{482}}{482}}ed0.902057{dl8.7677{ij115.156{566}{525}}hm43.2173{407}{567}}{434}}im4.88575{486}",
    "bs14{in9.32242{439}{408}}dr0.340703{410}{437}}bq77.5{df52.4738{dq13.2404{522}{503}}bq72.5{504}{505}}bq97.5{505}aa8948.5{506}hk4",
    ".90876{fz0.590172{507}{506}}{508}}ax1.13986{fn1.5709{bl0.0136545{gr1{416}ik4647.13{562}dq0.012679{557}{556}}gs3.5{gn11.8579{fx0",
    ".958611{542}iq1{439}{543}}bk1.32531{545}bu1.53984{544}fz1.38629{545}au2.87894{544}{545}}ir0.372607{ej2.12174{436}ix1{428}{414}}",
    "jc0.803588{582}hz0.104653{582}{583}}hs1{cz186{ah10{433}cp6.5{483}{485}}aw0.658656{bi0.57839{409}{502}}{484}}ek2.19431{cu0.36454",
    "2{fh0.897065{ho0.639045{hu0.213372{ep0.839968{553}ir0.950239{fr0.926252{553}{552}}{552}}{553}}{553}}{552}}es0.494787{406}be2.95",
    "146{500}{488}}ds0.004244{hn0.81{586}gz0.729{586}{585}}am1.59817{565}{590}}gd0.789105{fs0.927{dk144.167{hi53{du0.285714{584}{413",
    "}}{499}}eu0.203618{578}ip8271.51{579}aj90.1592{bw66.4002{580}{581}}cp3.5{ip10809.9{579}{580}}{581}}dv0.65{dg0.0297835{hb0.46866",
    "4{ha0.597148{592}{593}}ed0.94092{594}{591}}{592}}cu0.531441{cm8{fx2.4708{524}{525}}bu4.40081{524}br18.4429{524}{525}}aj35.5455{",
    "428}{430}}by0.0390625{ce2184{ao259.131{hv0.476003{569}ap0.135039{568}{570}}dc5.83372{cu0.531441{558}{559}}{558}}bj6.53563{fd0.6",
    "38792{575}bn0.173232{575}{576}}fp0.258813{577}gm0.518984{576}{577}}ai4296{fn1.55224{cz655{490}{582}}dg0.000129{er0.079902{gi9.2",
    "9412{484}{587}}gp0.581818{583}{584}}eu0.0184135{587}{588}}gk1.86503{cy67.5{gt3.26923{572}{574}}ap0.279253{574}gq0.076698{571}{5",
    "73}}{573}}dl33.8831{fn0.720064{eb0.114564{hi8{gy26.4102{cz1147{515}{516}}ac2.24549{cy2{435}{517}}{518}}bk0.31354{id0.0126675{51",
    "4}{513}}ar0.233567{512}ar0.23367{512}{513}}cc35687{ej1.78153{dg0.349883{ie0.04204{510}{509}}ep0.850322{509}az0.940363{508}{509}",
    "}hv4.52254{aj5.16017{508}jc0.405{507}{591}}{508}}ij38301.2{510}{511}}bk1.27433{fy1.09835{er0.576276{dr0.476528{519}{518}}{520}}",
    "ga6.05463{hk3.69577{ba0.759081{523}{520}}{526}}{521}}it85.5{fc0.0491545{492}{491}}{493}}by0.515698{ar0.0380525{am2.5334{io1.276",
    "6{an1.29068{423}{422}}{421}}cv0.022518{419}{420}}am2.33456{bm0.746435{cn13{hm1512.43{432}{431}}{417}}dk478.083{fg0.938033{489}{",
    "498}}{418}}if0.273023{bf3.97436{438}{426}}ew0.999788{424}{425}}bn0.565179{ez0.0055835{go0.7453{496}{497}}bz0.990246{494}{495}}{",
    "494}",
};

char *randomforest_crafted_tree_17[33] = {
    "bx0.485721{bm0.81{hh387.195{fn1.43765{ew0.617645{ge0.49{in4.25821{gd0.812743{ge0.406315{el1.4287{543}fr0.937102{542}cy66{542}{5",
    "43}}{543}}ei1{498}{527}}{416}}fp0.313334{dd9.86138{hy0.793817{dx0.597479{595}da1682.3{595}fq0.90753{595}{596}}{595}}{595}}bi0.0",
    "55278{io0.490689{ho0.64{412}{557}}{556}}{556}}dp2.09795{ed0.945751{bf8.08145{dc0.819236{412}{411}}{411}}hp0.0721775{415}{468}}d",
    "j1.5{du0.0382945{524}gk1.07804{by0.161308{ao47.1323{524}{525}}{525}}{524}}hy0.609383{dd5.54835{hl2.48543{429}{427}}hk4.89257{42",
    "8}{430}}ic0.0097345{591}{593}}ao33.3553{dk38.6667{gq0.244585{ea0.863765{433}{499}}jd0.32{el1.40364{552}fr0.926107{552}{553}}{59",
    "0}}em0.245553{484}gt0.5{409}bx0.24035{hg6{488}{543}}{584}}ba0.464558{bm0.423231{at17{dg2{ah6{571}{570}}gm0.379223{569}{568}}do1",
    "0.3695{dc10.4026{al4.57878{572}{573}}{573}}{574}}ap0.022157{502}fk0.40246{558}ai2375{559}dx0.566038{dn5.30433{559}{558}}{558}}a",
    "v6{br76.1719{hh11.5438{406}fl0.291666{ab15071{578}{581}}{588}}fp0.353444{ew0.43404{cn3.5{580}{581}}{580}}ep0.845197{579}hl0.535",
    "875{579}{580}}du0.066346{bc0.177307{fk0.393817{585}ez0.112598{id0.074803{586}{585}}{586}}by0.210632{586}{587}}hy0.496762{hn0.50",
    "3865{ad56{575}{576}}{575}}bq341{575}{577}}hc51{au3.09563{es0.0238785{dz6.14329{425}{426}}{424}}ia0.13497{417}{418}}aq0.031195{b",
    "z0.029648{it15{420}{419}}{421}}cc32128.5{gj17707{432}{423}}co12{431}{422}}bm0.876907{dw0.11789{fc1.12136{df216.975{dg1.3e-05{dj",
    "106{be1.26471{440}{454}}bf1.25557{dk306{456}{457}}{455}}bm0.863864{563}cw0.49{440}{477}}bk0.22502{gu4{ay4.65e-05{453}{458}}cb28",
    "032{441}{447}}ea0.389133{ee0.998517{443}{441}}{443}}gj5000{bf1.26471{444}cc2800{444}fy2.19578{aa3200{449}ab119988{451}de2.28324",
    "{452}{451}}ah68{451}cw0.16807{451}do2.94175{fc2.21099{449}{451}}{449}}br185.956{452}{451}}gz0.8266{dd3.54967{is0.512204{aj11.87",
    "31{566}au2.25238{489}{439}}gd0.000814{bh1.432{ia0.0001955{547}az0.831649{547}{548}}fk0.250418{fe0.222691{548}bh1.44048{547}au1.",
    "95481{546}fn0.668123{548}{546}}{548}}fh0.775859{548}{546}}bn0.655604{de4.03965{437}bu4.30936{408}{410}}ip63027.3{dt0.0093115{iw",
    "1{593}{591}}{592}}cp12{ih0.566136{ce247{582}{587}}{436}}{438}}ax0.236232{az1.25165{bc0.48172{ep0.84906{550}{551}}{550}}bh1.9404",
    "8{ew0.757748{fa0.596826{549}{551}}{549}}{549}}er0.415058{hr2.5{560}{562}}ea2.36463{ed0.901906{545}ge0.743521{545}{544}}{544}}ea",
    "1.36848{fy1.24763{be1.10676{gz0.69255{446}gi40000{bi1.36276{481}{480}}{459}}bn0.780627{fm0.006421{bg1.12258{462}bn0.778414{479}",
    "{461}}iq0.5{469}{460}}fo4.15e-05{464}{463}}ex0.971354{gd6{da70.5555{468}{448}}{442}}an1.17878{fz1.05774{fa0.990716{cd3328{445}{",
    "450}}{445}}{450}}{442}}ej0.047152{fy5.32279{ea2.15261{fh0.703028{du0.001698{467}{476}}{474}}io0.0442425{564}eo0.999896{475}{466",
    "}}cw0.49{dn7.11346{530}bp109.5{fw106.5{530}gb2.5e-05{ce1047.5{530}fd5.72561{531}{530}}{531}}{529}}bf1.27955{ah99{528}{529}}{589",
    "}}ah16{hy0.045387{an3.96665{472}an4.81577{539}{534}}aq0.038357{hs37.4158{hj4.80573{ee0.848548{541}{538}}{533}}cu0.478297{537}{5",
    "32}}hk4.00358{555}{554}}bi2.73593{am2.08803{470}{465}}hr72{eo0.998031{471}{473}}{478}}dy0.685863{fu40.5{ax1.12944{by0.4096{az0.",
    "637659{486}bv0.502623{an0.031577{ea0.026467{do0.612123{500}{486}}iq0.293608{560}{485}}{561}}co6.5{483}{485}}eh0.5{ec0.963089{52",
    "3}{522}}ig0.904023{487}co6.5{482}ic0.104105{482}{487}}aj0.461496{493}bz0.984908{ei0.416666{491}{490}}{492}}ez0.0060335{ec0.9994",
    "9{495}gl1.21035{496}{497}}{494}}gs71{gf370.5{fp0.271668{gf173{hm14.8578{fu22{522}ir0.397505{522}{503}}cd575.5{503}gn44.2028{gc0",
    ".619748{503}{504}}{504}}cb3905{505}gy6.95337{505}{506}}hi7.5{aw0.722816{be1.85714{bl0.072496{501}{439}}dv1{561}{407}}iy0.256625",
    "{dg0.06159{565}{414}}au2.73938{588}{413}}ds0.288{go0.354375{ho0.127214{dd5.92172{582}au2.10769{582}{583}}je0.488187{588}{587}}e",
    "k2.75775{dq11.6703{584}{583}}bf12.7{584}bu1.33327{588}{587}}jd0.246586{525}{526}}ai240{fu100{506}{507}}bq172.5{508}hc36701.5{gy",
    "13.9653{509}{510}}dr0.564672{go0.23462{512}{511}}{511}}gh29361{ia0.0303725{ic0.0034985{hc184866{516}gm4.59823{gy26.6767{bw11.11",
    "05{516}{517}}{517}}{517}}{515}}dk327.667{bi1.38327{513}bl0.112197{512}aq0.392674{511}{512}}{514}}eq0.426999{eq0.404973{521}bv0.",
    "566158{519}{520}}dd2.96279{dv0.851744{434}{518}}fe0.21201{435}{519}",
};

char *randomforest_crafted_tree_18[35] = {
    "bo0.492373{an0.669262{fg0.998569{dq1.20073{be2.14852{dt0.0729485{ey0.775{486}gf0.5{415}{501}}aj7.2459{ei0.25{560}fw4{561}{562}}",
    "cv0.235929{cc105{fn1.28885{487}{482}}{487}}if0.758621{ab280{487}{482}}{482}}hy0.405{av3{bw2.95882{fs0.967485{hn0.729{412}dg0.42",
    "4722{411}{412}}{411}}{411}}cp7{cb88{527}{483}}{485}}ig0.443416{fu1.5{500}ez0.313146{aa76525{hm0.0984245{553}fh0.896827{553}hm0.",
    "127233{552}{553}}{552}}fm1.80583{552}fk0.354068{fo1.4076{552}{553}}{552}}in0.976866{ib0.049567{557}{488}}{556}}ax1.26583{cp11{c",
    "e2002.5{cm2.5{do1.2911{586}{502}}hy0.27538{582}hv0.646096{585}{588}}{433}}{493}}go0.733062{ea0.0352895{dw0.008307{492}{491}}aj3",
    ".45578{490}{588}}gs14{584}{492}}by0.9917{fx0.050666{id2{527}{498}}{494}}ic1.4e-05{gf67{496}{497}}{495}}gi8853.5{ad32{gu0.5{bb0.",
    "512{fo1.73155{ej1.98459{416}{409}}{484}}ib0.0194445{dy5.2191{407}cd1427{410}{408}}dd3.12742{bp20{439}{566}}{437}}hs4.4712{fn1.7",
    "3581{fp0.265311{595}fp0.290641{ew0.0806905{596}fz1.17357{gh169.5{dw0.627072{596}ew0.0831375{596}fc7.23665{596}{595}}{596}}{595}",
    "}{595}}eq0.008502{dl669.112{el2.50481{558}dw0.4931{558}{559}}hk0.673574{559}{558}}{590}}ee0.878113{hk1.44532{co2.5{bk1.41363{54",
    "3}ar0.0012495{543}{542}}{542}}cw0.070001{fb5.50197{524}{525}}im9.22092{524}{525}}bm0.726911{eq0.260035{428}{430}}hf14{429}{427}",
    "}hy0.472282{iv2{fs0.885368{499}eb0.379317{eu0.178877{578}et0.01392{581}bf11.675{580}{581}}eh0.486218{hf12.5{580}{579}}{579}}hl1",
    ".06578{bx0.45027{406}{413}}fp0.343205{am3.71267{587}{588}}hl3.60881{584}{583}}cb1991{ir0.873098{it112{hu0.792707{ds6{570}{569}}",
    "dq537.135{568}{570}}bh9.375{ab54152{585}{586}}fx1.02666{586}{585}}es0.017277{av10{571}{572}}cw0.343{fo2.77794{572}{573}}ew0.140",
    "882{574}fh0.990469{571}{573}}br34.3115{cv0.32768{ip217.363{gw0.130961{594}{593}}{591}}{565}}hs13.8708{bz0.0021005{ax2.46704{576",
    "}{575}}du0.071795{577}{576}}ej2.09574{431}{432}}ar0.040067{cd37386{fg0.807023{ad3172.5{422}{421}}{423}}bx0.027098{419}{420}}am2",
    ".33441{bl0.885362{417}gz0.163734{431}{418}}bg2.79772{426}bj3.03075{424}{425}}by0.15047{fy1.02633{bm0.875498{gt3{gr1.5{bm0.8233{",
    "fd0.980446{549}eh0.498775{fb2.78814{551}{549}}{549}}ho0.062694{550}{551}}dw0.240664{563}be1.44505{bx0.0154525{547}bf1.39118{dv0",
    ".948412{548}{547}}az0.84937{547}dy0.999669{548}{546}}fe0.25241{eh0.499681{br53{546}ep0.844298{gb0.000432{546}fp0.432623{546}{54",
    "8}}{548}}be1.48101{548}fn0.690638{548}{546}}{546}}ea0.216058{dq145.598{bn0.754115{bs234{477}{441}}{454}}{447}}ax0.0001975{cb478",
    "88{441}{443}}{443}}bg1.23905{cu0.700245{446}bh1.11218{gj10000{ha0.576{463}{481}}gh25000{464}{459}}de0.000778{bn0.779698{ft461{a",
    "t40{gh1024{481}{479}}{461}}{479}}{462}}{460}}bn0.75606{cd5000{bm0.876198{455}{456}}dy1.00609{457}{440}}bp986{at100{469}{458}}{4",
    "53}}bn0.761415{fh0.74885{fm0.0075255{ap4{ab419364{444}{451}}aa3798{gg2898{480}{444}}{452}}gh3200{cb2800{gj2400{480}{444}}{449}}",
    "dd3.25847{dd3.00411{cc3400{451}{452}}{451}}{449}}hj2.20617{do0.960722{fn1.27656{545}an1.42157{fl0.25{545}cy51{545}{544}}{544}}b",
    "u1.51179{545}{544}}bq30{436}gc0.341709{593}{592}}bu2.40009{hf12{an1.15739{be1.16042{bn0.764095{480}{450}}dv0.015625{445}cc3584{",
    "445}{450}}{442}}hk0.162301{dr0.0014005{448}{442}}cy14{468}{470}}ep0.998009{do3.60638{ff0.903571{ib0.0141635{465}{473}}dk31.5{47",
    "2}gh4244{471}{555}}gd9.9e-05{ac101.929{fm0.847302{hq9{dk968{538}{532}}{533}}ex0.181818{ds0.0001235{540}{541}}au1.9732{539}{537}",
    "}{534}}dv0.527778{478}bh1.08152{554}{536}}an3.73557{gv0.5{aj294.398{ew0.999543{564}{466}}{467}}em0.017738{476}hi351{474}{475}}g",
    "z0.7695{ah106.5{fg0.801604{bp61{fb6.51272{530}{531}}{530}}{531}}dy6.90793{529}{531}}be1.08756{589}bv5.3594{589}ep0.999858{529}{",
    "528}}cz580{hc1057{cc580.5{ik44.0636{ff0.915277{ib0.0097265{503}{522}}br3{525}{522}}ik78.859{gb0.780715{id0.0246785{503}{522}}du",
    "0.083333{504}{503}}hy0.529451{em0.339409{582}cb274{583}{587}}hx1.40609{439}{414}}hu3.28717{ee0.858529{dm5.5{435}dd3.35768{414}{",
    "523}}{526}}ai116{hb0.158463{438}dz1.68869{504}ez0.70767{503}{504}}{505}}am0.963051{df126.632{go0.164744{ds0.316159{bf1.94018{bk",
    "0.038362{560}{483}}el1.01037{486}{485}}{561}}cz411{506}ad827.5{507}ce15923{507}{508}}bu0.909372{509}dy1.71647{508}di0.106774{50",
    "7}{508}}gu3{gz0.80675{523}{434}}il0.085589{506}{505}}hv2.65314{dm7.33333{bt1.10324{ce220032{fg0.850179{516}dw0.497989{515}{516}",
    "}{517}}dg0.332691{ik1431.32{515}{516}}{515}}an0.508799{dp1.62994{518}{519}}bo0.566172{521}{520}}fz0.306425{ai480{ds0.370562{513",
    "}gf2547.5{ac2.03282{511}{512}}{512}}{514}}eb0.12232{dt0.261771{511}{510}}is0.557288{de1.36115{489}{438}}{509}",
};

char *randomforest_crafted_tree_19[38] = {
    "bo0.542828{am0.562497{ay0.865023{fc0.926437{cd4961{ed0.908754{fr0.978565{ha0.8{im3.18117{527}{561}}be4.5087{eq0.625{412}en0.969",
    "231{411}{412}}{412}}{411}}hi5{fz0.0008935{415}do3.10614{498}{496}}ii999.821{582}{560}}{497}}du0.5{bh2.15267{ez0.603937{in0.5432",
    "32{562}{501}}bh1.78214{550}bf1.95833{au1.97086{bf1.81786{551}gp0.022012{bn0.655315{dx0.035{551}hq30{549}{551}}{551}}{549}}ea0.9",
    "94305{550}{551}}{549}}ew0.406761{il430.398{in1.21886{dt0.124919{hl0.0208705{is0.943895{553}hn0.809626{552}{553}}{553}}{553}}{55",
    "2}}{488}}dq0.0320515{dp0.00182{557}{556}}{556}}ap0.430467{ar0.008582{cu0.454382{485}ia0.245{ab560{cn7{483}{485}}{483}}{500}}{48",
    "6}}cw0.117649{487}ig0.908046{ig0.902381{487}{482}}{482}}ce3159.5{gf42.5{bx0.992923{fb0.181815{492}aq0.977009{490}{491}}{493}}{4",
    "94}}aj0.346724{ig0.000267{496}{495}}{495}}af192{fm1.72735{hf1.5{ge0.450476{dv0.922689{dp2.5912{bv0.923995{566}je0.241256{439}{4",
    "13}}{437}}bo0.487413{416}bz0.066047{410}{408}}cu0.665234{fy2.06961{fr0.963472{489}{524}}du0.04097{524}gx0.572704{gm0.561084{525",
    "}cx20{525}{524}}{524}}dp8.96788{hy0.756892{596}fz1.16958{gz0.857053{em0.266188{595}cy351.5{595}{596}}ay0.143631{595}{596}}{595}",
    "}{595}}et0.015263{bf2.21429{cv0.512{jd0.319654{fs0.904389{523}{489}}{438}}do0.755157{545}hj0.996317{ay0.480021{545}{544}}{544}}",
    "iw1.5{bn0.616963{fg0.897659{fx0.967016{542}{543}}{543}}{543}}jd0.5824{gl0.500936{hi52{431}ab99258.5{eq0.663507{431}{432}}{432}}",
    "{582}}dn4.80968{414}ab11550{583}{587}}cu0.531441{iw1{bx0.244871{eh0.265738{593}{594}}{592}}{591}}ak24{fw5{428}ij1.0341e+06{430}",
    "{428}}bc0.327495{406}gt3.82{429}gb0.157714{427}{430}}hz0.128951{gs3{df29.2701{in10.5354{409}{433}}ew0.161424{502}{484}}ap0.2256",
    "57{fa0.258173{ab16339{578}am3.55091{580}{581}}ik19980.7{579}{580}}cp6{hm10.5764{584}bx0.735855{583}{582}}{499}}dl491.11{fo1.971",
    "12{gp0.548352{gv1.08496{jc0.808777{588}{587}}{590}}dh4{584}{565}}bz0.0020725{hj1.473{fd0.581789{576}{575}}{576}}he0.0027935{577",
    "}hs6.99226{577}{576}}fb3.83319{ad93{hw0.265082{ez0.0402675{570}{569}}bn0.130558{568}fz0.20831{571}{570}}eu0.0429815{ag1{572}dy5",
    ".31053{587}{588}}ds2.8e-05{aw3.69689{573}{574}}{573}}br79.1385{ed0.897763{bj5.97767{559}fa0.0161575{by0.0148535{559}{558}}{558}",
    "}ai1830.5{da5836.44{559}{558}}{558}}ai4864{586}fv6.12849{586}{585}}ag335{fh0.712265{ia0.117121{br212.337{425}{426}}fg0.808157{d",
    "y7.39702{425}{424}}{424}}ev7.5e-06{ez0.857545{468}{418}}{417}}bz0.0304115{it13.5{421}ho0.105738{419}{420}}io1.25784{423}iw2{407",
    "}{422}}hc2155.5{eh0.191761{fy1.46688{bi0.35067{bo0.656808{bo0.639013{gr2.5{563}bb0.639143{ec0.998214{477}{454}}ft147{440}{455}}",
    "bm0.876342{fm0.0016525{457}{456}}eo0.999997{bc0.489975{479}{458}}{453}}dk460{db331{br1118{460}az0.453174{481}{459}}fa0.996774{a",
    "x0.0006585{479}{481}}{461}}gh4392{bb0.639973{462}{481}}da1817.96{az0.48592{463}{479}}dv0.001099{479}{464}}bv0.422588{bf1.36047{",
    "bh1.30865{440}{447}}fz0.22502{de0.924659{447}{441}}eh6.9e-05{441}{443}}bi1.36311{gr3.5{fk0.0119245{480}{469}}{446}}fd1{443}am1.",
    "39364{gi3328{445}gu5{445}{450}}{445}}az0.615934{bu2.625{es8{fe0.0033825{bu1.89833{ft83{450}{445}}ga17.0818{450}{442}}ek0.005464",
    "{448}{442}}ar0.000195{dn3.72659{465}fp0.0542115{476}{473}}gb0.093877{471}{470}}gs2.5{bi7.28617{dy5.74953{564}ex0.986904{cy142{5",
    "89}{528}}ap5{au1.98873{529}{528}}{528}}{589}}az0.563354{ek0.0176235{bu6.40921{bl0.029361{530}dp6.36648{531}cz3833{531}{530}}fy6",
    ".63163{529}{531}}{478}}gh5074{cm6{474}{472}}{475}}is1{ap0.0007195{468}ee0.998782{466}{467}}ac53.8244{fd1.9779{gj3200{449}dp2.41",
    "343{452}{451}}gh2600{444}dc3.16416{gg3000{449}em0.037567{452}{451}}bw2.08756{ax0.004092{451}{449}}{449}}bw2.08415{ay0.000676{cc",
    "5600{444}{451}}cc4500{444}{452}}ec0.999051{cz3334{444}{451}}ee0.997563{452}{451}}fp0.334867{is0.364189{522}df73.7408{fu40{ck0.1",
    "21709{503}{523}}{504}}iq0.648416{bq72.5{504}{505}}{505}}bc0.477753{bm0.862084{hc1{ex0.125{hd0.023256{al2.39443{439}{583}}{582}}",
    "go0.0607885{436}{414}}az0.844841{523}{435}}cc580.5{525}{526}}al3.60433{bf1.43077{ej1.54739{547}ek1.44929{546}ff0.925271{547}{54",
    "8}}gu2{550}fa0.775617{bp37{546}df62.5332{548}ew0.744701{el0.994962{548}{546}}{548}}fg0.843014{548}dw0.486783{hr26.5{546}{548}}{",
    "546}}du0.0004645{gz0.255599{554}if0.24053{536}{555}}gs7.5{ib0.0004105{de8.22263{540}{532}}hg1259{538}{533}}bg1.07276{534}dr0.00",
    "5328{bt7.8023{537}{535}}{541}}ia0.0484665{ay0.880198{ej1.8553{519}ao13.2139{bn0.714518{el1.37622{519}{520}}{434}}{521}}cb189152",
    "{ga2.90976{cu0.413488{561}fk0.01384{gl0.0240945{486}{483}}{560}}ih0.0511545{eb0.102309{516}{515}}{515}}bc0.416301{518}cz1229{51",
    "6}{517}}bu0.907635{hv5.22288{ig0.0727455{aa51044.5{510}{511}}gf1498{509}ib0.000831{510}ce34114{509}{510}}ds0.370429{bl0.107138{",
    "514}ej1.70833{hj6.46993{513}{514}}{513}}aa69406.5{511}{512}}hk4.74865{cw0.16807{567}ac2.07019{506}df93.573{505}{506}}ce15352.5{",
    "eq0.547576{gy10.5565{507}{508}}{507}}eq0.540512{509}{508}",
};

char *randomforest_crafted_tree_20[36] = {
    "bo0.438568{dz0.422411{fu45.5{it99.5{fb0.151643{al0.0676725{gu1{527}bb0.579728{is0.5{411}dd0.352403{411}{412}}{411}}{493}}gy0.44",
    "8763{cz62{fx0.0291615{cm6.5{483}{485}}eh0.499899{552}hx0.131921{fs0.886427{552}in0.608476{553}{552}}{553}}bo0.379115{gg1{502}{5",
    "00}}{433}}bz0.985091{bu0.946859{bj2.86531{491}{490}}{590}}{492}}{494}}bi2.8978{by0.992807{ie4.9e-05{498}{496}}{497}}{495}}co13{",
    "hh5.6857{hb0.4165{du0.21875{hf1{409}hw0.315567{gu3.5{aq0.00382{er3.8e-05{585}{586}}{585}}hw0.006695{586}{585}}{586}}{484}}aw0.6",
    "8121{eo0.856663{fr0.814636{595}gd0.809194{hz0.557511{596}ax0.276344{595}aw0.542855{596}{595}}{596}}ib0.0496605{556}{488}}hz0.42",
    "2501{ge0.307656{bs18.5{574}{571}}{406}}bg4.60487{565}em0.174477{559}hk0.852774{fb5.76732{ba0.446748{en0.946156{559}{558}}{559}}",
    "{558}}{558}}hg22{da3851.9{id0.041785{bx0.118838{ah8{ar0.084964{576}{468}}ff0.994927{576}{575}}{577}}dr0.000491{ac20.674{em0.281",
    "336{ha0.7472{580}{581}}{581}}eh0.50111{ej2.59946{hz0.012212{579}{580}}{579}}{580}}{578}}df6087.11{bt5.52619{hq3.5{gx0.13307{ds3",
    ".7e-05{573}{572}}gi9.33333{574}{573}}{572}}{574}}im1.74728{bu4.1681{571}{570}}an2.51384{ds5.5e-06{am3.17302{570}{569}}{569}}ij4",
    ".12586e+07{568}{569}}fr0.948493{at36{ad355.5{gi19.7375{584}{583}}dl528.45{dt2.5e-06{587}{588}}{587}}{499}}fc2.62605{gc0.617398{",
    "hh427.317{432}fu120.5{432}{431}}{413}}aq0.036803{de2.99115{429}{427}}co7.5{fy2.70125{428}{430}}{524}}ge0.493559{gd0.516247{br21",
    "5.544{fh0.712214{425}{424}}{426}}ev7.5e-06{418}{417}}bk1.66582{hm983.292{ig0.404203{423}{422}}{421}}ad3174.5{420}{419}}by0.1365",
    "78{fa0.982187{am1.27245{hb0.595{fs0.996906{ih0.802083{fg0.843764{546}bh1.45543{ak27.5{az0.811306{547}ej1.58926{546}{548}}be1.44",
    "194{547}{548}}fa0.622299{bm0.85526{546}{548}}{546}}bx0.099356{469}{566}}bg1.38462{477}{563}}is0.52{df19.7146{ee0.887904{562}{56",
    "0}}dn0.0571575{557}{556}}az1.23642{el1.00946{550}ho0.04398{550}{551}}gj30{ez0.669964{551}{549}}bo0.499416{549}da112.882{551}{55",
    "0}}eb0.250564{ft9{fg0.877191{es0.056292{fw21{591}{427}}gd0.223939{bw8.84512{593}{594}}{592}}ac3.62281{437}dq2.09049{439}{410}}b",
    "u2.59358{ij3.52721e+06{au1.9043{470}{471}}{465}}ez0.964{hi330.5{478}{472}}{473}}cm3.5{bo0.486868{fx0.959696{542}aq0.037707{543}",
    "bc0.356027{542}{543}}an1.40701{ir0.40131{544}{545}}{544}}bg1.17037{hi31{eb0.470131{555}ab1.59959e+06{cc20903.5{538}{536}}hn0.05",
    "0268{540}{532}}bu6.46066{em0.352988{541}{539}}{534}}bp15{he0.042721{436}{554}}{416}}ea0.594912{dc1.4035{bh1.25192{bf1.11071{dk9",
    "08{bf1.10676{gi20841{481}{459}}{463}}{464}}dd0.000328{bf1.1825{ep0.999981{462}{479}}{453}}ax0.001556{fw266.5{dd0.0010925{481}{4",
    "79}}{461}}{460}}gi5200{bb0.639485{da351.428{fp0.038576{440}{454}}{415}}bm0.876198{455}{456}}en0.999995{457}eh5.2e-05{440}{458}}",
    "bj0.487499{bx5{gi28032{441}{447}}{441}}bf1.30324{446}em0.0072975{dj274{441}{443}}{443}}bo0.646701{cv0.576{ab112648{ab98700{cd26",
    "00{gr5{480}{444}}{449}}fx2.22184{451}{449}}bi2.64134{bl0.0059775{gh5100{444}ej0.005834{451}{452}}fy2.15932{aa3600{be1.24324{480",
    "}{451}}{452}}ha0.268697{az0.678725{452}{451}}{451}}bq167{449}{452}}bf1.45587{ec0.974457{547}{564}}{546}}bu2.28043{fe0.002867{fd",
    "1.17566{fe0.0014715{dw0.005909{480}{445}}bm0.881708{gh3328{445}{450}}{450}}{442}}an1.07039{448}fb2.36904{442}{468}}cu0.620233{c",
    "s0.5{dz3.11495{aj482.724{442}{467}}{466}}iq0.878108{cp9{474}{475}}{476}}cu0.7695{fd5.76805{am6.34673{dy6.38922{530}{531}}ep0.99",
    "9902{ew0.99962{530}{531}}{530}}da473.251{529}{531}}be1.08798{589}bk4.34091{564}bx2.5e-06{dd6.97647{gi1262.5{528}{529}}{528}}fq0",
    ".999936{528}{589}}df155.751{fs0.942561{gt1.21602{dm8{dp0.234742{cv0.262144{487}{482}}bt1.95145{561}{439}}dw0.5{im12.3181{cc968.",
    "5{501}{408}}{407}}{486}}hy0.508602{iw1.50005{fn0.846441{434}{489}}at7.5{bb0.611759{435}{525}}iz0.132709{gy0.75{dx0.068966{588}{",
    "587}}{583}}cw0.343{583}{582}}fv3.9267{db22{414}ge0.986512{523}{567}}{526}}hu4.37709{hv3.22061{ij336.118{522}ai51.5{cu0.59049{59",
    "2}{522}}cu0.59049{hw1.50818{525}{524}}hz0.356009{el1.29794{504}{503}}ee0.849482{fq0.98547{503}{504}}{503}}ai116{504}{505}}hy0.3",
    "88139{ij21035.1{dn2.84934{di0.118985{is0.034677{co6.5{560}{485}}{483}}{561}}aj5.16194{is0.750061{508}gt13.8166{508}{509}}ai236{",
    "507}{508}}db13.5{fz0.378671{510}{509}}dh0.0948525{438}{510}}ia0.134548{bq130{gd0.480908{506}{507}}{507}}ht7{505}{506}}ia0.03394",
    "9{di0.101601{aj6.43696{dt0.190543{519}{518}}er0.596511{520}{521}}db16.5{ax0.996719{515}ao11.8435{516}{515}}dt0.247569{ce221018{",
    "516}bi1.22794{517}{518}}{516}}ej1.73165{dq77.3711{bv0.320869{513}bt1.36987{512}ib0.000711{512}{511}}fq0.988255{514}im15.0004{51",
    "3}{514}}ai356{ir0.609923{489}{510}}hv4.03005{hk3.67765{524}{525}}{511}",
};

char *randomforest_crafted_tree_21[35] = {
    "ix1{er0.195403{am1.33365{gu2.5{bc0.479021{cu0.81{co6.5{ex0.666667{bg2.5{562}{483}}{560}}gg1{485}hp0.486019{552}hj0.118295{iq0.9",
    "59287{552}fk0.354098{ec0.948684{552}{553}}{552}}{553}}fn0.917271{bm0.384464{411}hn0.659745{dd0.379153{411}{412}}{411}}fk0.46736",
    "5{gs0.5{502}{488}}{527}}gu1.5{bo0.510305{bp57{549}be1.9425{fd1.05685{551}{549}}dx0.017143{ej1.50634{551}{549}}{549}}bm0.8293{dz",
    "0.99576{549}ep0.84416{551}{549}}el1.00546{550}gg25{551}{550}}ee0.917466{az0.864962{ap0.110942{547}{548}}ex0.310069{ek1.42093{54",
    "6}ht23{548}{546}}em0.351359{548}bh1.45805{dv0.974351{546}{547}}dx0.988569{fe0.247121{eo0.90239{548}{546}}{546}}{548}}dx0.011326",
    "{481}{563}}fd0.0949125{fv467{dx0.006169{bn0.76723{bh1.25291{458}fv307{456}{457}}dc0.002271{479}{461}}az0.696838{ex0.990909{477}",
    "ff0.900862{479}{460}}ee0.997593{ec0.998615{454}{440}}{455}}ex0.998746{db1416{462}bb0.639992{463}{453}}de2.65e-05{ak1495{479}{45",
    "9}}{464}}dk684{gr3.5{bl0.09159{469}ed0.94526{bq158{dp1.40069{579}{580}}{579}}{480}}eh0.000986{fd0.475733{440}{446}}hv2.09641{45",
    "0}{489}}fx0.819283{at96{ab3.21707e+06{441}{447}}{447}}fx1.30619{dl694.264{443}{441}}bg1.26293{480}{443}}fm0.0519905{dd2.70675{a",
    "r1{bj1.66067{de1.16204{ce3328{445}{450}}{445}}bw18.1888{451}{450}}ft23{ic0.004378{468}{474}}aq0.000107{448}{442}}du0.006128{de4",
    ".17346{aw0.00549{fb3.33867{476}{467}}eq0.999586{442}{466}}ha0.64{dp6.28762{dx0.008548{531}{530}}bg1.13657{529}bl0.021931{529}{5",
    "31}}bw23.868{fz3.87824{564}{528}}de6.12163{bg1.20225{589}{564}}dd7.25511{dy6.79919{589}{528}}{589}}cy128{dg2{bx2{450}{442}}{451",
    "}}da216.735{gg3000{al2.25976{gh2600{444}{449}}ay0.002049{fs0.999575{449}{444}}{444}}gh3400{451}gh3800{452}{449}}gj5100{cy212{52",
    "8}{444}}bf1.25801{451}{452}}bc0.220111{dl366.52{es0.297978{am3.31887{gq0.132269{576}dd5.26552{575}{576}}fs0.87283{hs6.63556{577",
    "}{576}}{577}}{484}}az3.2351{fq0.959027{gi4.3254{hr9{dx0.576525{559}{558}}{558}}{559}}{558}}at16.5{du0.142857{571}cy80{569}er0.0",
    "377565{570}{568}}az4.37202{574}fe0.0803125{er0.0141905{572}{573}}ba0.422897{572}{573}}bo0.475975{ho0.055992{db328{gf4.5{409}{57",
    "8}}be1.52239{fh0.886128{580}{579}}dd5.59528{580}{581}}gu5.5{hv2.94171{429}{584}}{499}}fb3.11939{ao4.71099{ek0.834387{cc848{470}",
    "{465}}{439}}ek0.029758{473}{471}}bi5.63689{fb5.16652{472}bk2.73332{555}{554}}he0.210283{cb48976.5{gg19025.5{538}ej1.52653{537}{",
    "540}}bc0.489316{532}{535}}hj4.86964{534}{536}}gw1.89861{by0.154775{fy0.541817{aw0.070732{ai27{db27{566}dc3.54692{439}{437}}fd1.",
    "42768{415}{410}}im5.27002{io0.0782315{557}dp0.00364{557}{556}}{416}}hz0.374109{dy3.25129{gh31{cm2.5{fy0.923063{am1.55755{542}{5",
    "43}}{543}}bc0.348411{543}{542}}di3.3e-05{hm5.73721{eb0.479062{em0.294539{545}{544}}{545}}{545}}{544}}et0.0529055{cy56.5{427}{57",
    "8}}de3.87718{429}au2.88248{430}{428}}cv0.8{fv5.97729{592}fo0.313773{593}{594}}df2976.71{dq54.0799{gd0.564163{596}{595}}fz1.1755",
    "1{596}{595}}{595}}an0.292482{bs5{cw0.100001{487}{482}}ac3.00419{dn1.55683{gs166.5{561}io4.18767{486}{560}}bx0.530527{ga0.549392",
    "{485}{483}}{560}}{486}}ab4473{gs7.5{522}ge0.83906{522}{503}}at3.5{aw0.459145{ec0.950467{408}{407}}{434}}di0.000449{433}{489}}fx",
    "1.01942{hq1{ai560{515}eb0.099993{ai600{516}{517}}{516}}cz906{fu200{511}{512}}bl0.107216{514}{513}}bl0.131682{dk190.167{ik302.27",
    "{be1.25{bt1.81716{508}{507}}{507}}{508}}fu160{509}ab101726{510}{511}}dk85.8333{iq0.535125{503}cz239{504}{505}}iq0.702632{hr682{",
    "505}aw0.984802{505}{506}}bu1.22664{fe0.285712{507}{506}}{506}}eb0.0728095{ad2991{ad2435{fg0.94403{ib0.0038975{fm1.04979{ci2103.",
    "13{hd0.0015765{440}{523}}{475}}du0.225263{406}bp4{567}{565}}hy0.540284{jc0.615723{478}{413}}bc0.352737{fz0.100067{500}{590}}{41",
    "4}}fb0.149819{493}bj2.50684{492}{491}}{494}}ej2.3445{at56{hu1.24947{iu3{496}{435}}{526}}gt1.50685{498}{497}}dc4.62055{496}{495}",
    "}ag187.5{gx2.29493{gs7{er0.097819{hr24{co3.5{be1.30074{fu25{585}{586}}{586}}db8634{573}{572}}fy3.25933{je0.487657{588}dz4.22235",
    "{587}{588}}{436}}em0.311363{bu0.953964{dg0.040632{gu2{583}{427}}{501}}{584}}cv0.512{hp0.0442515{ey0.916667{584}{582}}{583}}hz0.",
    "106019{582}{583}}cx7.5{hl2.94391{cp15{gh13018{gl0.753485{432}{428}}{431}}{591}}aw1.36783{438}ai510{490}{430}}bn0.681099{dy4.906",
    "64{524}df330.491{cm8{525}hh55.2834{524}at25{525}{524}}{525}}{525}}bi1.89079{aa321729{cw0.006782{518}{517}}{519}}bm0.844996{521}",
    "{520}}bz0.036337{bv1.68073{an1.30684{cm14.5{423}{422}}{421}}cd38365.5{420}{419}}fm0.002845{hw3.76548{425}{426}}eo0.929083{424}f",
    "e0.195864{417}{418}",
};

char *randomforest_crafted_tree_22[36] = {
    "bz0.0801135{az0.742718{bg1.22924{dz2.04289{fd0.813868{fg0.800442{bm0.889846{fm0.0007885{ay5.1e-05{479}{463}}{462}}bf1.10769{gu3",
    "{481}{459}}{464}}cp4{bn0.774864{ea0.380406{460}{480}}{461}}{446}}bp78{ee0.994664{ib0.0166665{442}{470}}{448}}dz1.61385{aa3584{4",
    "45}bo0.653092{450}{445}}bk1.17566{450}{442}}fd2.61806{gt8.75{ea1.85632{bk1.80736{442}{471}}cm5.5{474}fr0.998652{472}{475}}az0.6",
    "19493{dz2.41211{iq0.596337{473}{465}}{476}}ey0.997671{466}fg0.800611{468}{467}}ek0.0171145{gs3{fs0.999841{fd4.28147{564}ec0.999",
    "073{589}{528}}at33.5{az0.522604{ek0.00142{eb0.000788{529}{528}}{529}}{589}}{589}}ap8.5e-06{bi7.17012{bt6.64573{531}{529}}{531}}",
    "ex0.983765{531}bm0.885683{531}{530}}ha0.184759{ih0.265277{iq0.686336{dt2{535}{537}}{534}}cw0.0210445{554}{555}}gb0.062403{ha0.4",
    "096{fw67{533}{540}}{538}}{478}}fh0.708435{bh1.27521{an1.0988{ax0.0002865{cb25000{be1.25325{458}{457}}{453}}br236{dc0.016143{fa0",
    ".993243{440}{455}}ej0.0204395{454}{477}}{456}}fp0.0251295{gg5000{444}el0.000504{451}{452}}gi3000{ce2800{444}{449}}ap0.000293{44",
    "9}bk2.05889{du0.013514{451}{452}}dw0.0139915{451}cc3600{451}{452}}bk0.260214{ba0.769331{415}dl713.329{dy0.657087{447}do1.42934{",
    "447}{441}}{447}}ai798.5{ff0.901391{440}{480}}fn7.6e-05{440}dq327.94{443}ba0.809968{441}{443}}ia4.7e-05{cy36.5{ds0.111337{bn0.75",
    "8533{dk18.6667{439}{410}}{469}}dv0.701299{566}{437}}bm0.768249{cu0.745245{409}bs106.5{527}{502}}{416}}hu2.88279{gw0.0554305{bc0",
    ".300604{488}fz0.733563{fz0.688399{542}{543}}{543}}bk1.38306{ek2.1763{545}{544}}bk1.41472{hs20.3875{545}{544}}{544}}eh0.330689{4",
    "26}{425}}fp0.1119{cn14{bl0.893068{fr0.999941{fr0.999734{563}{417}}{418}}bl0.896246{424}iu2{468}{425}}ep0.888606{en0.965525{419}",
    "hc53.5{421}{420}}am2.43172{423}{422}}hu0.419092{fh0.83715{gr1.5{de0.132252{bg1.86571{bn0.669228{ia0.0077345{551}{549}}aq0.05368",
    "7{550}hn0.348678{550}{551}}bc0.487887{549}be1.96071{ed0.896617{549}{551}}{549}}fs0.95{562}{560}}bn0.726634{dm116.5{gh218{546}fs",
    "0.923612{bf1.4807{ah78.5{bn0.723653{546}{548}}{548}}{546}}eo0.901257{548}{546}}fp0.433063{ea0.992007{548}{546}}{547}}gi195{az0.",
    "845218{el1.04537{547}{548}}cc116{546}{548}}{547}}cu0.700245{as4{ez0.157747{hn0.375521{498}{558}}ap0.435255{fo1.41565{553}ik121.",
    "121{552}{553}}hz0.635733{553}{552}}{484}}eq0.535976{in1.05708{gp0.4553{fl0.714286{572}{527}}{557}}ek2.40809{556}eu0.003857{585}",
    "{586}}fs0.963525{el0.535195{412}id0.258333{412}{411}}{411}}fm1.76032{dv0.74141{dj3.75{br50.4404{591}if0.330417{ez0.852391{431}{",
    "432}}{432}}gd0.215889{593}hi6.5{406}{592}}dy6.20761{eh0.382344{dc6.06652{fh0.717409{427}{429}}fg0.847939{427}{430}}io6.41546{eo",
    "0.901827{489}{428}}{436}}am7.2236{dk601{fd6.21917{cc169{596}{595}}{595}}go0.771249{ec0.934567{595}{596}}{595}}{595}}bn0.188172{",
    "dk1281.03{iq0.867917{hy0.498955{az3.13191{575}{576}}{575}}gy1.5731{577}hz0.224958{576}{577}}et0.0766405{fn4.3222{bg10.207{568}{",
    "588}}hz0.257579{574}{573}}eq0.141565{570}fm4.86344{fm4.84106{570}{569}}{569}}ht11{hy0.685265{586}ik23.2358{fc2.61043{ia0.422241",
    "{559}{558}}{559}}fh0.971221{558}dx0.533019{559}{558}}dl86.5091{aj26.1905{499}{578}}de2.25998{ek2.271{580}{579}}en0.948451{580}f",
    "z0.55655{dk257.75{581}{580}}{581}}bp2{ih0.0005065{io0.0158755{de2.1842{go0.7453{496}{497}}{495}}ip1.82952e+12{493}{494}}cu0.216",
    "262{cc339249{bm0.848676{ap0.492723{438}{519}}{518}}am1.08944{520}{521}}hn0.159263{dy0.181312{bm0.765207{493}{492}}de3.46244{bh2",
    ".59259{gn230.194{490}{517}}{491}}fe0.199274{408}if0.121756{583}{407}}hn0.377497{dr0.013632{cz799{584}eu0.042504{583}iv5{583}{58",
    "4}}hy0.21678{582}df28.9975{dj10.25{hc25{592}{525}}{582}}fb3.55333{588}{583}}fp0.287442{fm3.01713{bi3.54089{523}ed0.905578{gk1.0",
    "7248{eq0.206739{524}hi5.5{au2.6564{525}{524}}{525}}{524}}{524}}dk2259.12{fe0.0803125{ij1.58908e+08{572}fp0.25258{573}{572}}ap0.",
    "226411{574}{573}}{571}}ib0.0119045{je0.487826{id0.03876{588}{587}}{587}}bx0.353334{ab1397.5{556}{557}}{439}}im11.7111{aj6.26327",
    "{bq50{ir0.413527{im7.36992{522}{503}}hg24{fb2.47697{434}{435}}{503}}br6.77756{504}bw11.633{iq0.702492{aa2382.5{fq0.987143{504}{",
    "505}}{505}}{506}}bq207{561}fn0.039929{486}{560}}bt0.713893{ii10{io0.495534{cp7{ig0.908046{ew0.511309{487}{482}}{482}}cc151.5{ej",
    "1.81128{487}ce96{482}{487}}{482}}ap0.237086{500}bg2{501}{561}}{486}}ap0.346753{je0.245{cn6.5{483}dj14{489}{485}}dp1.72918{565}c",
    "v0.147807{413}{590}}dd3.03958{gi5146{414}{567}}{526}}im14.6093{ip1244.47{ij9131.43{ez0.575245{433}ba0.773827{hm54.7521{506}{507",
    "}}{506}}bl0.126654{508}gh3273{507}ie0.051257{508}{507}}ce33992.5{509}cc48559{510}{511}}hq2{id0.0112475{im15.4601{dq88.2121{516}",
    "ab463242{516}{517}}{517}}{515}}aa117106{hv5.36796{bw9.5055{gy17.5869{511}{512}}{512}}if0.047947{513}di0.11031{512}{513}}{514}",
};

char *randomforest_crafted_tree_23[35] = {
    "ec0.959018{bl0.115057{bi0.719612{dy0.903761{bg2.49753{ij10.2336{ig0.904233{ah7{561}{487}}cv0.262144{aa96{482}{487}}{482}}im2.31",
    "55{486}iq0.302517{fu4{439}ff0.900045{486}{560}}ip25.1941{561}{483}}fb1.21069{dc0.559515{ha0.8{527}{411}}ed0.877487{411}{412}}bx",
    "0.411977{hw0.058894{ez0.312163{552}ep0.840005{553}fm1.80673{552}{553}}{553}}ih0.95{500}co7{483}{485}}ba0.751208{cn4.5{fv0.4875{",
    "dy3.11124{ip0.988804{566}{439}}{437}}fw1.5{bl5.75e-05{557}{556}}{488}}ig0.493253{ak27{407}{409}}bt4.52932{ce1366.5{501}{408}}{4",
    "10}}hb0.595{bm0.858047{fg0.851561{fr0.948422{546}ea0.989438{cd1600{ax0.006443{548}{546}}ew0.745281{546}{548}}dw0.498441{546}fw6",
    "2.5{546}{548}}{548}}fd0.953445{bm0.862398{548}ff0.924902{547}{548}}bf1.4134{547}at29{546}{547}}bg1.79375{bq25.5{bg1.75{550}{551",
    "}}{550}}ic0.0535715{em0.349714{549}fq0.97586{ap0.0052625{br107.5{549}{551}}{551}}{549}}{562}}hd0.0033445{gw2.78493{dz1.97746{cd",
    "6603{cp4{502}{433}}ha0.483835{489}{434}}io6.9376{fm1.07073{538}an1.38968{bs25{544}{545}}ex0.090909{545}ei0.5{545}{544}}ff0.9443",
    "74{436}{416}}ab367326{515}gh21348.5{516}if0.0363385{517}ar0.234476{516}{517}}gk5.37618{bk0.52471{gv5.24025{bl0.113026{gh9338.5{",
    "511}{512}}{511}}ib0.0007065{512}ad2837{512}{513}}ax0.834255{gj22916{am6.44238{gj2142{jd0.64{538}{406}}am5.64248{436}{539}}ar2.8",
    "5e-05{534}{541}}ie0.0036245{532}fr0.950276{hx135.85{535}{540}}co10{533}{537}}{526}}bu0.553297{514}{513}}dh0.142464{dt0.003455{b",
    "c0.217472{bp9{gr0.5{484}av9.5{fk0.405883{558}fo3.02161{dx0.555747{559}ds0.00055{559}{558}}{558}}co3.5{dp6.75351{572}{574}}{573}",
    "}hi6.5{gb0.810532{hn0.81{586}en0.949129{fe0.14271{586}ic0.029528{586}{585}}{585}}er0.035462{ek4.35816{hk0.864631{569}{570}}{570",
    "}}{568}}bj6.46979{er0.009196{576}bw67.3889{is0.860025{576}{575}}bk4.927{575}{576}}hs6.85068{577}{576}}if0.12676{bv0.727639{fz1.",
    "16464{da1682.3{595}fz1.15338{595}{596}}an5.54984{da2329.11{595}{596}}{595}}bp16.5{406}fg0.899583{dx0.952222{fx0.955233{542}dn0.",
    "927524{543}{542}}{543}}{543}}eu0.157387{fv33.0684{hg20{565}{578}}cu0.348678{554}{555}}cc711.5{az2.31188{id0.162683{ep0.845008{i",
    "o2.54429{579}{580}}{580}}{579}}{580}}gn134.2{dd5.74002{fe0.191494{581}{580}}{581}}{580}}hf0.5{gv4.79269{521}dg0.232516{br6.9331",
    "5{it1442.5{520}{521}}{520}}{519}}fv3.35374{ec0.951446{ge0.45163{dw0.494839{413}{590}}hh13.5918{fu23.5{414}{523}}{567}}az0.94345",
    "9{db47.5{522}{503}}co7.5{da127.673{524}{525}}iq0.285631{524}dd7.15324{525}{524}}ao30.3801{499}dl219.254{gv0.364868{432}{489}}{4",
    "31}}aa14497{gy7.00783{dk80.3333{cd543.5{bq35{dm13.125{dz1.95613{525}{439}}{522}}{503}}hb0.421485{504}fo0.390304{504}{503}}{505}",
    "}ai196{506}{507}}gy14.223{cc23693.5{fz0.495105{508}fu118{507}{508}}ih0.0869745{cb35048.5{509}{510}}{509}}hf2{bh1.5{435}{518}}ip",
    "2039.61{510}hi14.5{510}{511}}fp0.169529{ap0.023532{bg1.23771{gz0.659745{cv0.191328{fn0.000572{bn0.763881{467}gj91168{476}{468}}",
    "fr0.999896{ec0.998374{474}{475}}{466}}fx1.79876{fd1{446}bu1.38979{ce3328{445}{450}}{445}}dc2.98922{ek0.0054655{448}{442}}fx2.35",
    "467{450}{442}}bw15.8038{bm0.890224{bo0.672638{ap4.5e-06{bg1.11815{462}{461}}{460}}ed0.999721{463}{464}}bh1.08909{481}{459}}gz0.",
    "7695{bk2.84341{480}fe0.000802{bl0.021718{529}{531}}bx6.4e-05{bo0.663354{530}dc7.27041{530}{531}}{531}}al5.9206{564}bl0.0292355{",
    "528}{589}}fy1.27772{bn0.752676{fd0.189825{gd0.5{563}{415}}ea0.251253{fh0.700861{447}de0.934194{447}{441}}el7.75e-05{ec0.999722{",
    "441}{443}}{443}}bp176{aw0.024736{du0.014706{440}{454}}{477}}bh1.25382{fh0.70048{453}ah348{457}{458}}gi2600{455}{456}}bx9.3e-05{",
    "be1.21737{gi5400{449}{452}}gh3200{aa2600{444}{449}}cc5900{cb3400{451}hb0.343{de2.49096{452}{444}}ce5100{444}{452}}{451}}es0.006",
    "4225{451}ft5{429}{427}}hn0.234669{cc34287.5{ix1{df15.7735{fo0.0184975{470}ey0.959375{469}{472}}fw27.5{hi720{471}{473}}{465}}bc0",
    ".364799{422}bg1.51996{478}{438}}fd0.572122{fe0.16579{420}{421}}{419}}fy2.10453{en0.965825{ev6{425}{424}}df765.833{418}{417}}dp6",
    ".20488{423}fe0.195983{425}{426}}hc154.5{gd0.996462{ff0.964268{dz2.40373{bh1.66667{db51{522}{503}}{560}}at20.5{hx1.05912{fu13{bn",
    "0.689098{592}{439}}cc3758{592}{593}}jb0.094912{591}{587}}ak44{er0.549051{430}{428}}gc0.0252505{427}{429}}bf9.175{eb0.0628905{49",
    "2}de2.56465{491}{490}}ad357{bg7.77823{el1.55925{al2.4602{582}ia0.0589885{582}{583}}hr84{fu20.5{584}{583}}{583}}dm883.556{dy4.37",
    "147{571}{573}}{572}}ai4196{ga7.30451{588}{587}}{587}}gf45{493}{494}}ic1.4e-05{gq0.388664{496}ce4961{498}{497}}hz0.205525{495}hr",
    "2584{432}{431}",
};


char **randomforest_crafted_forest[23] = {
    randomforest_crafted_tree_1, 
    randomforest_crafted_tree_2, 
    randomforest_crafted_tree_3, 
    randomforest_crafted_tree_4, 
    randomforest_crafted_tree_5, 
    randomforest_crafted_tree_6, 
    randomforest_crafted_tree_7, 
    randomforest_crafted_tree_8, 
    randomforest_crafted_tree_9, 
    randomforest_crafted_tree_10, 
    randomforest_crafted_tree_11, 
    randomforest_crafted_tree_12, 
    randomforest_crafted_tree_13, 
    randomforest_crafted_tree_14, 
    randomforest_crafted_tree_15, 
    randomforest_crafted_tree_16, 
    randomforest_crafted_tree_17, 
    randomforest_crafted_tree_18, 
    randomforest_crafted_tree_19, 
    randomforest_crafted_tree_20, 
    randomforest_crafted_tree_21, 
    randomforest_crafted_tree_22, 
    randomforest_crafted_tree_23
};

uint32_t randomforest_crafted_treeSizes[23] = {34, 36, 34, 34, 36, 38, 36, 35, 36, 34, 36, 37, 34, 35, 37, 35, 33, 35, 38, 36, 35, 36, 35};


uint32_t randomforest_crafted_getResult(char *strPtr){
    int theResult;
    uint32_t success = sscanf(strPtr, "%d", &theResult);
    if (!success){
        printf("c ERROR. RANDOMFOREST result extraction from linearized tree failed.\n");
        randomforest_returnCode = RANDOMFOREST_ERROR;
        theResult = CNFCLASSES_RES_SPE_UNRECOGNIZED;
    }
    theResult+=CNFCLASSES_CLASS_MINNUM;
    return theResult;
}

char* randomforest_crafted_skipBlock(char *strPtr){
    uint32_t numOpening = 1;
    uint32_t numClosing = 0;
    if (*strPtr == '{') ++strPtr;
    while (numClosing < numOpening){
        if (*strPtr == '\0'){
            printf("c ERROR. RANDOMFOREST skip-Block reached end of string. This cannot be.\n");
            randomforest_returnCode = RANDOMFOREST_ERROR;
            return strPtr;
        }
        if (*strPtr == '}'){
            ++numClosing;
            ++strPtr;
        } else if (*strPtr == '{'){
            ++numOpening;
            ++strPtr;
        } else {
            ++strPtr;
        }
    }
    --strPtr;
    return strPtr;
}

char* randomforest_crafted_checkIf(char *strPtr, uint32_t *answer){
    float checkVal;
    uint32_t i, baseDist = 0, offsetDist = 0;

    for (i=0; i < RANDOMFOREST_CRAFTED_NUMCHARS; ++i){
        if (*strPtr == randomforest_crafted_characters[i]){break;}
    }
    baseDist = i;
    ++strPtr;
    for (i=0; i < RANDOMFOREST_CRAFTED_NUMCHARS; ++i){
        if (*strPtr == randomforest_crafted_characters[i]){break;}
    }
    offsetDist = i;
    ++strPtr;

    if (baseDist == RANDOMFOREST_CRAFTED_NUMCHARS || offsetDist == RANDOMFOREST_CRAFTED_NUMCHARS){
        printf("c ERROR. RANDOMFOREST found an unknown symbol while checking an if-statement.\n");
        randomforest_returnCode = RANDOMFOREST_ERROR;
        return strPtr;
    }

    uint32_t attID = baseDist*RANDOMFOREST_CRAFTED_NUMCHARS + offsetDist;

    uint32_t success = sscanf(strPtr, "%f{", &checkVal);

    if (!success){
        printf("c ERROR. RANDOMFOREST if statement extraction from linearized tree failed.\n");
        randomforest_returnCode = RANDOMFOREST_ERROR;
        return strPtr;
    }

    float_ty attVal = randomforest_crafted_getFattValueFromID(attID);
    if (attVal == -1.0){
        printf("c ERROR. RANDOMFOREST extracting the attribute value for attribute %d failed.\n", attID);
        randomforest_returnCode = RANDOMFOREST_ERROR;
        return strPtr;
    }

    while (*strPtr != '{'){
        if (*strPtr == '\0'){
            printf("c ERROR. RANDOMFOREST read NULL-byte while checking an IF. This cannot be.\n");
            randomforest_returnCode = RANDOMFOREST_ERROR;
            return strPtr;
        }
        ++strPtr;
    }

    if (attVal < checkVal){
        *answer = 1;
    } else {
        *answer = 0;
    }
    return strPtr;
}

uint32_t randomforest_crafted_askTree(uint32_t treeID){
    uint32_t result = CNFCLASSES_RES_SPE_UNRECOGNIZED;
    uint32_t answer, strNum;
    char *strPtr = randomforest_crafted_treestring, *copyPtr;

    for (strNum = 0; strNum < randomforest_crafted_treeSizes[treeID]; ++strNum){
        copyPtr = randomforest_crafted_forest[treeID][strNum];
        while (*copyPtr != '\0'){
            *strPtr = *copyPtr;
        	  ++strPtr;
        	  ++copyPtr;
        }
    }
    *strPtr = '\0';

    strPtr = randomforest_crafted_treestring;

    while (1){
        if (*strPtr == '\0'){
            printf("c ERROR. RANDOMFOREST reached NULL-byte while traversing the tree. This cannot be.\n");
            randomforest_returnCode = RANDOMFOREST_ERROR;
            return result;
        } else if (*strPtr > 96 && *strPtr < 123){
            strPtr = randomforest_crafted_checkIf(strPtr, &answer);
            if (randomforest_returnCode != RANDOMFOREST_UNKNOWN){return CNFCLASSES_RES_SPE_UNRECOGNIZED;}
            if (!answer){
                strPtr = randomforest_crafted_skipBlock(strPtr);
                if (randomforest_returnCode != RANDOMFOREST_UNKNOWN){return CNFCLASSES_RES_SPE_UNRECOGNIZED;}
            }
        } else if (*strPtr > 47 && *strPtr < 58){
            result = randomforest_crafted_getResult(strPtr);
            if (randomforest_returnCode != RANDOMFOREST_UNKNOWN){return CNFCLASSES_RES_SPE_UNRECOGNIZED;}
            break;
        }
        ++strPtr;
    }
    #ifdef VERBOSE_RANDOMFOREST
    printf("c     RANDOMFOREST:     Tree %d votes for class %d.\n", treeID, result);
    #endif
    return result;
}

void randomforest_intern_crafted_voteAll(){
    #ifdef VERBOSE_RANDOMFOREST
    printf("c     RANDOMFOREST: Classifying (domain CRAFTED)...\n");
    #endif

    if (MAIN_GET_FATT_ISSET() == 0){
        printf("c ERROR. RANDOMFOREST cannot classify a formula if the attributes are not computed.\n");
        randomforest_returnCode = RANDOMFOREST_ERROR;
        MAIN_SET_FATT_CLASS(CNFCLASSES_RES_SPE_UNKNOWN);
        return;
    }

    #ifdef VERBOSE_RANDOMFOREST
    printf("c     RANDOMFOREST:   Asking trees for their votes...\n");
    #endif
    uint32_t i, numTrees = 23, maxTreeStrings = 0;

    for (i = 0; i < numTrees; ++i){
        if (randomforest_crafted_treeSizes[i] > maxTreeStrings){
            maxTreeStrings = randomforest_crafted_treeSizes[i];
        }
    }

    randomforest_crafted_treestring = NULL;
    randomforest_crafted_treestring = malloc(sizeof(char) * 4096 * maxTreeStrings);
    if (randomforest_crafted_treestring == NULL){
        printf("c ERROR. RANDOMFOREST was unable to allocate the character array for the tree string. Out of memory?\n");
        randomforest_returnCode = RANDOMFOREST_ERROR;
        return;
    }

    for (i=0; i < numTrees; ++i){
        classify_intern_voteForClass(randomforest_crafted_askTree(i));
        if (randomforest_returnCode != RANDOMFOREST_UNKNOWN){
            if (randomforest_crafted_treestring != NULL) {free(randomforest_crafted_treestring); randomforest_crafted_treestring = NULL;}
            return;
        }
    }
    if (randomforest_crafted_treestring != NULL) {free(randomforest_crafted_treestring); randomforest_crafted_treestring = NULL;}
}
