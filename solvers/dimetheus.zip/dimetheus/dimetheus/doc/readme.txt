DIMETHEUS SAT SOLVER README

The Dimetheus SAT solver has been implemented by Oliver Gableske
(oliver@gableske.net), who is the sole copyright owner for this sofware.

The information on how to get started is found here:
   https://www.gableske.net/dimetheus/gettingstarted
Please read this document.

You should work with the latest sources, which can be downloaded here:
   https://www.gableske.net/downloads/dimetheus_latest.tar.gz

For licensing information please read the license.txt file. Contact the
author if this file is missing.