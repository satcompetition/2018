/***************************************************************************************[Solver.cc]
smallsat -- Copyright (c) 2003-2006, Niklas Een, Niklas Sorensson
           Copyright (c) 2007-2010, Niklas Sorensson
 
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/

#include <math.h>
#include <signal.h>
#include <unistd.h>

#include "mtl/Sort.h"
#include "core/Solver.h"
#include "utils/System.h"

using namespace abcdsat;

int traceflag=0;
int outVars=0;
int  dumpmode=0;
bool h_probe=false;
int   cancelTreeSolve=0;
uint32_t hardnum=0;
uint32_t unsatCnt=0;
uint32_t unsat9Cnt=0;

int   * ite2ext=0;
extern FILE*   certifiedOutput;
extern bool    certifiedUNSAT;  
int    treeDepth=0;
int    treeExtLit[30];
int    treeAuxLit[30]; //auxiliary  z=x^y
int    auxVar;

inline int GetextLit (int ilit) 
{
  if(ilit < 0) return -ite2ext[-ilit];
  return ite2ext[ilit];
}

inline void  printreeExtLit()
{
   if(treeDepth<=0) return;
   int k=treeDepth-1;
   if(treeAuxLit[k]==0){
        if(k==0) treeAuxLit[k]=treeExtLit[k];
        else{ //auxiliary var replace z=x^y^.....
             auxVar++;
             fprintf(certifiedOutput, "%i ", auxVar);
             for (int i = 0; i < treeDepth; i++){// z V -x V -y.....
                  fprintf(certifiedOutput, "%i ", treeExtLit[i]);
             }
             fprintf(certifiedOutput, "0\n");
             for (int i = 0; i < treeDepth; i++){// -z V x
                  fprintf(certifiedOutput, "%i %i 0\n", -auxVar, -treeExtLit[i]);
             }
             treeAuxLit[k]=-auxVar;
        }
   }
   fprintf(certifiedOutput, "%i ", treeAuxLit[k]);
}

inline void  printDrupUnitl(int lit, int needExtV)
{
      printreeExtLit();
      if(needExtV){
              if(lit < 0) lit = -ite2ext[-lit];
              else        lit =  ite2ext[lit];
      } 
      fprintf(certifiedOutput, "%i 0\n", lit);
}

inline void  printDrupUnit(Lit p, int needExtV)
{  
      int lit=toIntLit(p);
      printDrupUnitl(lit, needExtV);
}

void  printDrupLits(const vec<Lit>& ps, int deleteflag, int needExtV)
{     int i;

      if(deleteflag){
           fprintf(certifiedOutput, "d ");
      }
      printreeExtLit();
      int changext=0;
      if(ite2ext && needExtV) changext=1;
      for (i = 0; i < ps.size(); i++){
           int lit=toIntLit(ps[i]);
           if(changext) lit=GetextLit(lit);
           fprintf(certifiedOutput, "%i ", lit);
      }
      fprintf(certifiedOutput, "0\n");
}

void  printDrupClause(Clause & c, int deleteflag, int needExtV)
{     int i;
      if(deleteflag){
           fprintf(certifiedOutput, "d ");
      }
      printreeExtLit();
      int changext=0;
      if(ite2ext && needExtV) changext=1;
      for (i = 0; i < c.size(); i++){
           int lit=toIntLit(c[i]);
           if(changext) lit=GetextLit(lit);
           fprintf(certifiedOutput, "%i ", lit);
      }
      fprintf(certifiedOutput, "0\n");
}

//=================================================================================================
// Options:

static const char* _cat = "CORE";

static DoubleOption  opt_alpha         (_cat, "step-size",   "Initial step size",                             0.40,     DoubleRange(0, false, 1, false));

static DoubleOption  opt_alpha_dec     (_cat, "step-size-dec","Step size decrement",                          0.000001, DoubleRange(0, false, 1, false));
static DoubleOption  opt_min_alpha     (_cat, "min-step-size","Minimal step size",                            0.06,     DoubleRange(0, false, 1, false));
static DoubleOption  opt_var_decay         (_cat, "var-decay",   "The variable activity decay factor",            0.80,     DoubleRange(0, false, 1, false));
static DoubleOption  opt_clause_decay      (_cat, "cla-decay",   "The clause activity decay factor",              0.999,    DoubleRange(0, false, 1, false));
static DoubleOption  opt_random_var_freq   (_cat, "rnd-freq",    "The frequency with which the decision heuristic tries to choose a random variable", 0, DoubleRange(0, true, 1, true));
static DoubleOption  opt_random_seed       (_cat, "rnd-seed",    "Used by the random variable selection",         91648253, DoubleRange(0, false, HUGE_VAL, false));
static IntOption     opt_ccmin_mode        (_cat, "ccmin-mode",  "Controls conflict clause minimization (0=none, 1=basic, 2=deep)", 2, IntRange(0, 2));
static IntOption     opt_phase_saving      (_cat, "phase-saving", "Controls the level of phase saving (0=none, 1=limited, 2=full)", 2, IntRange(0, 2));
static BoolOption    opt_rnd_init_act      (_cat, "rnd-init",    "Randomize the initial activity", false);
static IntOption     opt_restart_first     (_cat, "rfirst",      "The base restart interval", 100, IntRange(1, INT32_MAX));
static DoubleOption  opt_restart_inc       (_cat, "rinc",        "Restart interval increase factor", 2, DoubleRange(1, false, HUGE_VAL, false));
static DoubleOption  opt_garbage_frac      (_cat, "gc-frac",     "The fraction of wasted memory allowed before a garbage collection is triggered",  0.20, DoubleRange(0, false, HUGE_VAL, false));

//=================================================================================================
// Constructor/Destructor:

Solver::Solver() :

    // Parameters (user settable):
    //
    verbosity        (0)
  , alpha            (opt_alpha)
  , alpha_dec        (opt_alpha_dec)
  , min_alpha        (opt_min_alpha)
  , timer            (5000)
  , var_decay        (opt_var_decay)
  , clause_decay     (opt_clause_decay)
  , random_var_freq  (opt_random_var_freq)
  , random_seed      (opt_random_seed)
  , VSIDS            (false)
  , ccmin_mode       (opt_ccmin_mode)
  , phase_saving     (opt_phase_saving)
  , rnd_pol          (false)
  , rnd_init_act     (opt_rnd_init_act)
  , garbage_frac     (opt_garbage_frac)
  , restart_first    (opt_restart_first)
  , restart_inc      (opt_restart_inc)
  // Statistics: (formerly in 'SolverStats')
  //
  , solves(0), starts(0), decisions(0), rnd_decisions(0), propagations(0), conflicts(0)
  , dec_vars(0), clauses_literals(0), learnts_literals(0), max_literals(0), tot_literals(0)

  , ok                 (true)
  , cla_inc            (1)
  , var_inc            (1)
  , watchesBin        (WatcherDeleted(ca))
  , watches            (WatcherDeleted(ca))
  , qhead              (0)
  , simpDB_assigns     (-1)
  , simpDB_props       (0)
  , order_heap         (VarOrderLt(activity))
  , progress_estimate  (0)
  , remove_satisfied   (true)

  , small_lbd_lim      (3)
  , sumLBD             (0)
  , lbdQueue          (50)
  , next_LONG_reduce   (15000)
  
  , MYFLAG             (0)

  // Resource constraints:
  //
  , conflict_budget    (-1)
  , propagation_budget (-1)
  , asynch_interrupt   (false)
{
   next_simplify_small=1;
   beta= 1 - alpha;
   learnt_small=0;
   subformuleClause = recursiveDepth = needExtVar=0;

   equhead=equlink=0;
   hbrsum=equsum=unitsum=probeSum=0;
   touchMark=0;
   next_probe=0;
   dummyVar=0;
   bitVecNo=-1;
}

Solver::~Solver()
{
   if(dummyVar) free(dummyVar);
   dummyVar=0;

   ClearClause(clauses, 0);
   ClearClause(learnts, 0);
  
   if(equhead) free(equhead);
   if(equlink) free(equlink);
   equhead = equlink=0;

}

void Solver:: ClearUnit()
{
     if(treeDepth<2) return;
     for(int i=trail.size()-1; i>=init_trailsize; i--){
            vec<Lit> ps;
            ps.clear();
            ps.push(trail[i]);
            printDrupLits(ps, 1, needExtVar);
     }
     trail.clear();
}         

CRef Solver::simplePropagate()
{
    CRef    confl = CRef_Undef;
    watches.cleanAll();
    watchesBin.cleanAll();
    while (qhead < trail.size())
    {
        Lit            p = trail[qhead++]; 
        vec<Watcher>&  ws = watches[p];
        Watcher        *i, *j, *end;
  
        vec<Watcher>&  wbin = watchesBin[p];
        for (int k = 0; k<wbin.size(); k++)
        {
            Lit imp = wbin[k].blocker;
            if (value(imp) == l_False) return wbin[k].cref;
            if (assigns[var(imp)] == l_Undef) UncheckEnqueueNoLevel(imp, wbin[k].cref);
        }
        for (i = j = (Watcher*)ws, end = i + ws.size(); i != end;)
        {
            Lit blocker = i->blocker;
            if (value(blocker) == l_True)
            {
                *j++ = *i++; continue;
            }

            // Make sure the false literal is data[1]:
            CRef     cr = i->cref;
            Clause & c = ca[cr];
            Lit      false_lit = ~p;
            if (c[0] == false_lit) c[0] = c[1], c[1] = false_lit;
            Lit     first = c[0];
            if (first != blocker && value(first) == l_True) {
                i->blocker = first;
                *j++ = *i++; continue;
            }
            else {
                for (int k = 2; k < c.size(); k++) {
                    if (value(c[k]) != l_False) {
                        Watcher w = Watcher(cr, first); i++;
                        c[1] = c[k]; c[k] = false_lit;
                        watches[~c[1]].push(w);
                        goto NextClause;
                    }
                }
            }
            i->blocker = first;
            *j++ = *i++;
            if (value(first) == l_False) {
                confl = cr;
                qhead = trail.size();
                while (i < end) *j++ = *i++;
            }
            else UncheckEnqueueNoLevel(first, cr);
NextClause:;
        }
        ws.shrink(i - j);
    }
    return confl;
}

void Solver::UncheckEnqueueNoLevel(Lit p, CRef from){
    assert(value(p) == l_Undef);
    assigns[var(p)] = lbool(!sign(p)); // this makes a lbool object whose value is sign(p)
    vardata[var(p)].reason = from;
    trail.push_(p);
}

void Solver::cancelUntil_fixedunits()
{
    for (int c = trail.size() - 1; c >= fixedUnits; c--) assigns[var(trail[c])] = l_Undef;

    qhead = fixedUnits;
    trail.shrink(trail.size() - fixedUnits);

}

void Solver::simpleAnalyze(CRef confl, vec<Lit> & out_learnt)
{
    int pathC = 0;
    Lit p = (out_learnt.size()==1) ? out_learnt.last(): lit_Undef;
    int index = trail.size() - 1;
    do{
        if (confl != CRef_Undef){
            Clause& c = ca[confl];
            // Special case for binary clauses
            // The first one has to be SAT
            if (p != lit_Undef && c.size() == 2 && value(c[0]) == l_False) {

                assert(value(c[1]) == l_True);
                Lit tmp = c[0];
                c[0] = c[1], c[1] = tmp;
            }
            // if True_confl==true, then choose p begin with the 1th index of c;
            for (int j = (p == lit_Undef) ? 0 : 1; j < c.size(); j++){
                Lit q = c[j];
                if (!seen[var(q)]){
                    seen[var(q)] = 1;
                    pathC++;
                }
            }
        }
        else if (confl == CRef_Undef){
            out_learnt.push(~p);
        }
        // if not break, while() will come to the index of trail blow 0, and fatal error occur;
        if (pathC == 0) break;
        // Select next clause to look at:
        while (!seen[var(trail[index--])]);
        // if the reason cr from the 0-level assigned var, we must break avoid move forth further;
        // but attention that maybe seen[x]=1 and never be clear. However makes no matter;
        if (fixedUnits > index + 1) break;
        p = trail[index + 1];
        confl = reason(var(p));
        seen[var(p)] = 0;
        pathC--;

    } while (pathC >= 0);
}

void Solver::simplifyLearnt( Clause & c )
{
    fixedUnits = trail.size();
    int i, j;
    CRef confl;
    new_learntcls.clear();
    for (i = 0, j = 0; i < c.size(); i++){
          Lit lit=c[i];
          if (value(lit) == l_True){
                c[j++] = lit;
                confl = reason(var(lit));
                new_learntcls.push(lit);
                break;
          }
          if (assigns[var(lit)] == l_Undef){
               UncheckEnqueueNoLevel(~lit);
               c[j++] = lit;
               confl = simplePropagate();
               if (confl != CRef_Undef) break;
          }
    }
    c.shrink(c.size() - j);
    if (confl != CRef_Undef){
        simpleAnalyze(confl, new_learntcls);
        if (new_learntcls.size() < c.size()){
            for (j = 0; j < new_learntcls.size(); j++) c[j] = new_learntcls[j];
            c.shrink(c.size() - j);
        }
    }
    cancelUntil_fixedunits();
}

bool Solver::simplifysmallclause()
{
    if(conflicts<260000 || recursiveDepth) return true;
    if(dumpmode==0 && conflicts>20000 || clauses.size()>4e6) return true;
 
    int old_size, ci, cj;
    cancelUntil(0);
    for (ci = 0, cj = 0; ci < learnts.size(); ci++){
        CRef cr = learnts[ci];
        Clause & c = ca[cr];
        if( c.mark() == 1 ) continue;//removed
        if (c.done() || c.mark() == LONG) learnts[cj++] = learnts[ci];
        else {
            for (int i = 0; i < c.size(); i++) 
                 if (value(c[i]) == l_True){
                     removeClauseOut(cr);
                     goto nextc;
                 }
            old_size=c.size();
            detachClause(cr, true);
            simplifyLearnt(c);
                              
            if (c.size() == 1){
                 if(unitPropagation(c[0]) != CRef_Undef){ ok = false; learnts.clear(); return false;}
                 c.mark(1);
                 ca.free(cr);  // delete
            }
            else{
                 if (old_size != c.size() && certifiedUNSAT) printDrupClause(c, 0, needExtVar); //add
                 c.done(true);
                 attachClause(cr);
                 learnts[cj++] = learnts[ci];
                 unsigned int nblevels = computeLBD(c);
                 if (nblevels < (unsigned)c.lbd()) c.set_lbd(nblevels);
                 if(c.mark() == MIDSZ){
                        if (c.lbd() <= small_lbd_lim){//3 or 5
                             learnt_small++;
                             c.mark(SMALL);
                         }
                 }
            }
nextc:       ;
        }
    }
    learnts.shrink(ci - cj);
    checkGarbage();
    return true;
}

//=================================================================================================
// Minor methods:


// Creates a new SAT variable in the solver. If 'decision' is cleared, variable will not be
// used as a decision variable (NOTE! This has effects on the meaning of a SATISFIABLE result).
//
Var Solver::newVar(bool sign, bool dvar)
{
    int v = nVars();
    watchesBin.init(mkLit(v, false));
    watchesBin.init(mkLit(v, true ));
    watches  .init(mkLit(v, false));
    watches  .init(mkLit(v, true ));
    assigns  .push(l_Undef);
    vardata  .push(mkVarData(CRef_Undef, 256));//0
    activity.push(rnd_init_act ? drand(random_seed) * 0.00001 : 0);

    decisionTime.push(0);
    varBumpCnt.push(0);
    canceled.push(0);

    seen     .push(0);
    permDiff    .push(0);
    polarity .push(sign);
    decision .push();
    trail    .capacity(v+1);
    setDecisionVar(v, dvar);
    return v;
}

bool Solver::addClause_(vec<Lit>& ps)
{
    if (!ok) return false;
    sort(ps);
    Lit p; int i, j;

    if(subformuleClause==0){
         if (certifiedUNSAT) ps.copyTo(old_clause);

         for (i = j = 0, p = lit_Undef; i < ps.size(); i++)
            if (value(ps[i]) == l_True || ps[i] == ~p) return true;
            else if (value(ps[i]) != l_False && ps[i] != p)
               ps[j++] = p = ps[i];
              ps.shrink(i - j);

         if (certifiedUNSAT && i != j){
              printDrupLits(ps, 0, needExtVar);//add
              printDrupLits(old_clause, 1, needExtVar);//delete
         }
    }

    if (ps.size() == 0) return ok = false;
    else if (ps.size() == 1){
        uncheckedEnqueue(ps[0]);
        return ok = (propagate() == CRef_Undef);
    }else{
        CRef cr = ca.alloc(ps, false);
        clauses.push(cr);
        attachClause(cr);
    }
    return true;
}


void Solver::attachClause(CRef cr) {
    const Clause& c = ca[cr];
    assert(c.size() > 1);
    OccLists<Lit, vec<Watcher>, WatcherDeleted>& ws = c.size() == 2 ? watchesBin : watches;
    ws[~c[0]].push(Watcher(cr, c[1]));
    ws[~c[1]].push(Watcher(cr, c[0]));
    if (c.learnt()) learnts_literals += c.size();
    else            clauses_literals += c.size(); }


void Solver::detachClause(CRef cr, bool strict) {
    const Clause& c = ca[cr];
    assert(c.size() > 1);
    OccLists<Lit, vec<Watcher>, WatcherDeleted>& ws = c.size() == 2 ? watchesBin : watches;
    
    if (strict){
        remove(ws[~c[0]], Watcher(cr, c[1]));
        remove(ws[~c[1]], Watcher(cr, c[0]));
    }else{
        // Lazy detaching: (NOTE! Must clean all watcher lists before garbage collecting this clause)
        ws.smudge(~c[0]);
        ws.smudge(~c[1]);
    }

    if (c.learnt()) learnts_literals -= c.size();
    else            clauses_literals -= c.size(); 
}

inline void Solver::removeClause(CRef cr) 
{
    Clause & c = ca[cr];
    detachClause(cr);
    // Don't leave pointers to free'd memory!
    if (locked(c)){
        Lit implied = c.size() != 2 ? c[0] : (value(c[0]) == l_True ? c[0] : c[1]);
        vardata[var(implied)].reason = CRef_Undef; }
    c.mark(1);
    ca.free(cr);
}

void Solver::removeClauseOut(CRef cr) 
{
    if (certifiedUNSAT){
        Clause & c = ca[cr];
        if (c.mark() != 1) printDrupClause(c, 1, needExtVar);//delete
    }
    removeClause(cr);
}

bool Solver::satisfied(const Clause& c) const {
    for (int i = 0; i < c.size(); i++)
        if (value(c[i]) == l_True)
            return true;
    return false; }


// Revert to the state at given level (keeping all assignment at 'level' but not beyond).
//
void Solver::cancelUntil(int clevel) {
    if (decisionLevel() > clevel){
        for (int c = trail.size()-1; c >= trail_lim[clevel]; c--){
            Var      x  = var(trail[c]);

            if (!VSIDS){ //CHB:conflict history based
                uint32_t age = conflicts - decisionTime[x];
                if (age >0){
                    double adjusted_reward =  varBumpCnt[x]/(double) age;
                    double old_activity = activity[x];
                    activity[x] = alpha * adjusted_reward + ( beta * old_activity);
                    if (order_heap.inHeap(x)){
                        if (activity[x] > old_activity) order_heap.decrease(x);
                        else order_heap.increase(x);
                    }
                }
                canceled[x] = conflicts;
            }

            assigns [x] = l_Undef;
            if (phase_saving > 1 || (phase_saving == 1) && c > trail_lim.last())
                polarity[x] = sign(trail[c]);
            insertVarOrder(x); }
        qhead = trail_lim[clevel];
        trail.shrink(trail.size() - trail_lim[clevel]);
        trail_lim.shrink(trail_lim.size() - clevel);
    } 
}

void Solver::cancelUntil0(int nlevel)
{
    if (decisionLevel() > nlevel){
        qhead = trail_lim[nlevel];
        for (int c = trail.size()-1; c >= qhead; c--) assigns [var(trail[c])] = l_Undef;
        trail.shrink(trail.size()-qhead);
        trail_lim.shrink(trail_lim.size() - nlevel);
    } 
}


//=================================================================================================
// Major methods:

Lit Solver::pickBranchLit()
{
    Var next = var_Undef;
    while (next == var_Undef || value(next) != l_Undef || !decision[next])
        if (order_heap.empty()) return lit_Undef;
        else{
            if (!VSIDS){//CHB order_heap_CHB
                Var v = order_heap[0];
                uint32_t age = conflicts - canceled[v];
                while (age > 0){
                    double decay = pow(0.95, age);
                    activity[v] *= decay;
                    if (order_heap.inHeap(v)) order_heap.increase(v);
                    canceled[v] = conflicts;
                    v = order_heap[0];
                    age = conflicts - canceled[v];
                }
            }
            next = order_heap.removeMin();
        }

    if (!VSIDS){
        decisionTime[next] = conflicts;
        varBumpCnt[next] = 0;
        uint32_t age = conflicts - canceled[next];
        if (age > 0){//CHB
            double decay = pow(0.95, age);
            activity[next] *= decay;
            if (order_heap.inHeap(next)) order_heap.increase(next);
        }
    }
   
    if(bitVecNo>=0){
           int clevel=decisionLevel();
           if(clevel<16) return mkLit(next,(bitVecNo>>(clevel% 4)) & 1);
     }
  
    return mkLit(next, polarity[next]);
}

/*_________________________________________________________________________________________________
|
|  analyze : (confl : Clause*) (out_learnt : vec<Lit>&) (out_btlevel : int&)  ->  [void]
|  
|  Description:
|    Analyze conflict and produce a reason clause.
|  
|    Pre-conditions:
|      * 'out_learnt' is assumed to be cleared.
|      * Current decision level must be greater than root level.
|  
|    Post-conditions:
|      * 'out_learnt[0]' is the asserting literal at level 'out_btlevel'.
|      * If out_learnt.size() > 1 then 'out_learnt[1]' has the greatest decision level of the 
|        rest of literals. There may be others from the same level though.
|  
|________________________________________________________________________________________________@*/
void Solver::analyze(CRef confl, vec<Lit>& out_learnt, int& out_btlevel, int& out_lbd)
{
    int pathC = 0;
    Lit p     = lit_Undef;

    // Generate conflict clause:
    //
    out_learnt.push();      // (leave room for the asserting literal)
    int index   = trail.size() - 1;

    do{
        assert(confl != CRef_Undef); // (otherwise should be UIP)
        Clause & c = ca[confl];

        // For binary clauses, we don't rearrange literals in propagate(), so check and make sure the first is an implied lit.
        if (p != lit_Undef && c.size() == 2 && value(c[0]) == l_False){
            assert(value(c[1]) == l_True);
            Lit tmp = c[0];
            c[0] = c[1], c[1] = tmp; }

        // Update LBD if improved.
        if (c.learnt() && c.mark() != SMALL){
            int lbd = computeLBD(c);
            if (lbd < c.lbd()){
                if (c.lbd() <= 30) c.removable(false); // Protect once from reduction.
                c.set_lbd(lbd);
                if (lbd <= small_lbd_lim){
                    learnt_small++;
                    c.mark(SMALL);
                }else if (lbd <= 6 && c.mark() == LONG) c.mark(MIDSZ); 
            }

            if (c.mark() == MIDSZ) c.touched() = conflicts;
            else if (c.mark() == LONG) claBumpActivity(c);
        }

        for (int j = (p == lit_Undef) ? 0 : 1; j < c.size(); j++){
            Lit q = c[j];
            int v=var(q);
            if (!seen[v] && level(v) > 0){
                if (VSIDS){
                    varBumpVSIDSactivity(v,var_inc);
                }
                else varBumpCnt[v]++;
                seen[v] = 1;
                if (level(v) >= decisionLevel()) pathC++;
                else out_learnt.push(q);
            }
        }
        
        // Select next clause to look at:
        while (!seen[var(trail[index--])]);
        p     = trail[index+1];
        confl = reason(var(p));
        seen[var(p)] = 0;
        pathC--;

    }while (pathC > 0);
    out_learnt[0] = ~p;

    // Simplify conflict clause:
    //
    int i, j;
    analyze_toclear.clear();
    if (ccmin_mode == 2){
        uint32_t abstract_level = 0;
        for (i = 1; i < out_learnt.size(); i++)
            abstract_level |= abstractLevel(var(out_learnt[i])); // (maintain an abstraction of levels involved in conflict)

        out_learnt.copyTo(analyze_toclear);
        for (i = j = 1; i < out_learnt.size(); i++)
            if (reason(var(out_learnt[i])) == CRef_Undef || !litRedundant(out_learnt[i], abstract_level))
                out_learnt[j++] = out_learnt[i];
        
    }else if (ccmin_mode == 1){
        for (i = j = 1; i < out_learnt.size(); i++){
            Var x = var(out_learnt[i]);

            if (reason(x) == CRef_Undef)
                out_learnt[j++] = out_learnt[i];
            else{
                Clause& c = ca[reason(var(out_learnt[i]))];
                for (int k = c.size() == 2 ? 0 : 1; k < c.size(); k++)
                    if (!seen[var(c[k])] && level(var(c[k])) > 0){
                        out_learnt[j++] = out_learnt[i];
                        break; }
            }
        }
    }else
        i = j = out_learnt.size();

    max_literals += out_learnt.size();
    out_learnt.shrink(i - j);
    tot_literals += out_learnt.size();

    out_lbd = computeLBD(out_learnt);
    if (out_lbd <= 6 && out_learnt.size() <= 30) // Try further minimization?
        if (binResMinimize(out_learnt))
            out_lbd = computeLBD(out_learnt); // Recompute LBD if minimized.

    // Find correct backtrack level:
    //
    if (out_learnt.size() == 1) out_btlevel = 0;
    else{
        int max_i = 1;
        // Find the first literal assigned at the next-highest level:
        for (int i = 2; i < out_learnt.size(); i++)
            if (level(var(out_learnt[i])) > level(var(out_learnt[max_i]))) max_i = i;
        // Swap-in this literal at index 1:
        Lit p             = out_learnt[max_i];
        out_learnt[max_i] = out_learnt[1];
        out_learnt[1]     = p;
        out_btlevel       = level(var(p));
    }
//
    for(int k = out_learnt.size() - 1; k >= 0; k--){
          Var v = var(out_learnt[k]);
          CRef rs = reason(v);
          if (rs == CRef_Undef) continue;
          Clause & rC = ca[rs];
          if (!VSIDS){
               int delta=1;//clauses.size()<200000 && rC.size()< 4 ? 2 :1;
               for (int i = 0; i < rC.size(); i++) varBumpCnt[var(rC[i])] += delta; //varBumpCnt[var(rC[i])]++;
          }
          else for (int i = 0; i < rC.size(); i++){
                     int v=var(rC[i]);
                     varBumpVSIDSactivity(v,var_inc);
               }
     }
     for (int j = 0; j < analyze_toclear.size(); j++) seen[var(analyze_toclear[j])] = 0;
}


// Try further learnt clause minimization by means of binary clause resolution.
bool Solver::binResMinimize(vec<Lit>& out_learnt)
{
    // Preparation: remember which false variables we have in 'out_learnt'.
    MYFLAG++;
    for (int i = 1; i < out_learnt.size(); i++)
        permDiff[var(out_learnt[i])] = MYFLAG;

    // Get the list of binary clauses containing 'out_learnt[0]'.
    const vec<Watcher>& ws = watchesBin[~out_learnt[0]];

    int to_remove = 0;
    for (int i = 0; i < ws.size(); i++){
        Lit the_other = ws[i].blocker;
        // Does 'the_other' appear negatively in 'out_learnt'?
        if (permDiff[var(the_other)] == MYFLAG && value(the_other) == l_True){
            to_remove++;
            permDiff[var(the_other)] = MYFLAG - 1; // Remember to remove this variable.
        }
    }

    // Shrink.
    if (to_remove > 0){
        int last = out_learnt.size() - 1;
        for (int i = 1; i < out_learnt.size() - to_remove; i++)
            if (permDiff[var(out_learnt[i])] != MYFLAG)
                out_learnt[i--] = out_learnt[last--];
        out_learnt.shrink(to_remove);
    }
    return to_remove != 0;
}


// Check if 'p' can be removed. 'abstract_levels' is used to abort early if the algorithm is
// visiting literals at levels that cannot be removed later.
bool Solver::litRedundant(Lit p, uint32_t abstract_levels)
{
    analyze_stack.clear(); analyze_stack.push(p);
    int top = analyze_toclear.size();
    while (analyze_stack.size() > 0){
        assert(reason(var(analyze_stack.last())) != CRef_Undef);
        Clause& c = ca[reason(var(analyze_stack.last()))]; analyze_stack.pop();

        // Special handling for binary clauses like in 'analyze()'.
        if (c.size() == 2 && value(c[0]) == l_False){
            assert(value(c[1]) == l_True);
            Lit tmp = c[0];
            c[0] = c[1], c[1] = tmp; }

        for (int i = 1; i < c.size(); i++){
            Lit p  = c[i];
            if (!seen[var(p)] && level(var(p)) > 0){
                if (reason(var(p)) != CRef_Undef && (abstractLevel(var(p)) & abstract_levels) != 0){
                    seen[var(p)] = 1;
                    analyze_stack.push(p);
                    analyze_toclear.push(p);
                }else{
                    for (int j = top; j < analyze_toclear.size(); j++)
                        seen[var(analyze_toclear[j])] = 0;
                    analyze_toclear.shrink(analyze_toclear.size() - top);
                    return false;
                }
            }
        }
    }

    return true;
}


/*_________________________________________________________________________________________________
|
|  analyzeFinal : (p : Lit)  ->  [void]
|  
|  Description:
|    Specialized analysis procedure to express the final conflict in terms of assumptions.
|    Calculates the (possibly empty) set of assumptions that led to the assignment of 'p', and
|    stores the result in 'out_conflict'.
|________________________________________________________________________________________________@*/
void Solver::analyzeFinal(Lit p, vec<Lit>& out_conflict)
{
    out_conflict.clear();
    out_conflict.push(p);

    if (decisionLevel() == 0) return;

    seen[var(p)] = 1;
    for (int i = trail.size()-1; i >= trail_lim[0]; i--){
        Var x = var(trail[i]);
        if (seen[x]){
            if (reason(x) == CRef_Undef){
                assert(level(x) > 0);
                out_conflict.push(~trail[i]);
            }else{
                Clause& c = ca[reason(x)];
                for (int j = c.size() == 2 ? 0 : 1; j < c.size(); j++)
                    if (level(var(c[j])) > 0)
                        seen[var(c[j])] = 1;
            }
            seen[x] = 0;
        }
    }
    seen[var(p)] = 0;
}


void Solver::uncheckedEnqueue(Lit p, CRef from)
{
    assert(value(p) == l_Undef);
    Var x = var(p);
    assigns[x] = lbool(!sign(p));
    vardata[x] = mkVarData(from, decisionLevel());
    trail.push_(p);
}

/*_________________________________________________________________________________________________
|
|  propagate : [void]  ->  [Clause*]
|  
|  Description:
|    Propagates all enqueued facts. If a conflict arises, the conflicting clause is returned,
|    otherwise CRef_Undef.
|  
|    Post-conditions:
|      * the propagation queue is empty, even if there was a conflict.
|________________________________________________________________________________________________@*/
CRef Solver::propagate()
{
    CRef    confl     = CRef_Undef;
    int     num_props = 0;
    watches.cleanAll();
    watchesBin.cleanAll();

    while (qhead < trail.size()){
        Lit            p   = trail[qhead++];     // 'p' is enqueued fact to propagate.
        vec<Watcher>&  ws  = watches[p];
        Watcher        *i, *j, *end;
        num_props++;

        vec<Watcher>& ws_bin = watchesBin[p];  // Propagate binary clauses first.
        for (int k = 0; k < ws_bin.size(); k++){
            Lit the_other = ws_bin[k].blocker;
            if (value(the_other) == l_False){
                confl = ws_bin[k].cref;
                return confl;
            }else if(value(var(the_other)) == l_Undef)
                uncheckedEnqueue(the_other, ws_bin[k].cref);
        }

        for (i = j = (Watcher*)ws, end = i + ws.size();  i != end;){
            // Try to avoid inspecting the clause:
            Lit blocker = i->blocker;
            if (value(blocker) == l_True){
                *j++ = *i++; continue; }

            // Make sure the false literal is data[1]:
            CRef     cr        = i->cref;
            Clause&  c         = ca[cr];
            Lit      false_lit = ~p;
            if (c[0] == false_lit)
                c[0] = c[1], c[1] = false_lit;
            assert(c[1] == false_lit);
            i++;

            // If 0th watch is true, then clause is already satisfied.
            Lit     first = c[0];
            Watcher w     = Watcher(cr, first);
            if (first != blocker && value(first) == l_True){
                *j++ = w; continue; }

            // Look for new watch:
            for (int k = 2; k < c.size(); k++)
                if (value(c[k]) != l_False){
                    c[1] = c[k]; c[k] = false_lit;
                    watches[~c[1]].push(w);
                    goto NextClause; }

            // Did not find watch -- clause is unit under assignment:
            *j++ = w;
            if (value(first) == l_False){
                confl = cr;
                qhead = trail.size();
                // Copy the remaining watches:
                while (i < end)
                    *j++ = *i++;
            }else
                uncheckedEnqueue(first, cr);

NextClause:;
        }
        ws.shrink(i - j);
    }

//ExitProp:;
    propagations += num_props;
    simpDB_props -= num_props;

    return confl;
}

struct reduceDB_lt_act{ 
    ClauseAllocator & ca;
    vec<CRef> & learnt;
    reduceDB_lt_act(ClauseAllocator & ca_, vec<CRef> & learnt_) : ca(ca_), learnt(learnt_){}
    bool operator () (int m, int n) {
         CRef x=learnt[m], y=learnt[n]; 
         return ca[x].activity() < ca[y].activity();
    }    
};

/*_________________________________________________________________________________________________
|
|  reduceDB : ()  ->  [void]
|  
|  Description:
|    Remove half of the learnt clauses, minus the clauses locked by the current assignment. Locked
|    clauses are clauses that are reason to some assignment. Binary clauses are never removed.
|________________________________________________________________________________________________@*/
void Solver::reduceDB()
{
    int     i, j;
  
    vec <int> learntNo;
    for (i =j=0; i < learnts.size(); i++)
           if(ca[learnts[i]].mark() == LONG) learntNo.push(i);

    sort(learntNo, reduceDB_lt_act(ca,learnts));

    int limit = learntNo.size() / 2;
    for (i =0; i < learntNo.size(); i++){
        int no=learntNo[i];
        Clause & c = ca[learnts[no]];
        if (c.removable() && !locked(c) && i < limit){
             removeClauseOut(learnts[no]);
             learnts[no]=CRef_Undef;
        }
        else{
                if (!c.removable()) limit++;
                c.removable(true);
        }
    }

    reduceDB_midsz(); 
       
    checkGarbage();
}

void Solver::reduceDB_midsz()
{   int i,j;
    for (i = j = 0; i < learnts.size(); i++){
        CRef cr = learnts[i];
        if(cr == CRef_Undef) continue;
        learnts[j++] = cr;
        Clause & c = ca[cr];
        if (c.mark() == MIDSZ)
            if (!locked(c) && c.touched() + 25000 < conflicts){
                c.mark(LONG);
                c.activity() = 0;
                claBumpActivity(c);
            }
    }
    learnts.shrink(i-j);
}

void Solver::removeSatisfied(vec<CRef>& cs,int delFlag)
{
   if(certifiedUNSAT && delFlag) delFlag=1;
   else delFlag=0;

   int i, j;
   for (i = j = 0; i < cs.size(); i++){
        Clause & c = ca[cs[i]];
        if (satisfied(c)){
            if(c.learnt() && c.mark() == SMALL) learnt_small--;
            if(delFlag)  printDrupClause(c, 1, needExtVar);
            removeClause(cs[i]);
        }
        else cs[j++] = cs[i];
    }
    cs.shrink(i - j);
}

void Solver::rebuildOrderHeap()
{
  //  if(equhead){//bug
 //        for (Var v = 0; v < nVars(); v++)
 //            if(decision[v] && equhead[v] &&  equhead[v] !=v) setDecisionVar(v, false);
 //   }
    vec<Var> vs;
    for (Var v = 0; v < nVars(); v++)
        if (decision[v] && value(v) == l_Undef) vs.push(v);

    order_heap.build(vs);
}

/*_________________________________________________________________________________________________
|
|  simplify : [void]  ->  [bool]
|  
|  Description:
|    Simplify the clause database according to the current top-level assigment. Currently, the only
|    thing done here is the removal of satisfied clauses, but more things can be put here.
|________________________________________________________________________________________________@*/
bool Solver::simplify()
{
    assert(decisionLevel() == 0);

    if (!ok || propagate() != CRef_Undef) return ok = false;

    if (nAssigns() == simpDB_assigns || (simpDB_props > 0)) return true;

    // Remove satisfied clauses:
    removeSatisfied(learnts,1);
    if (remove_satisfied){        // Can be turned off.
        int delflag = (subformuleClause==0);
        removeSatisfied(clauses,delflag);
        lbool ret=hbr_probe();
        if(ret == l_False) return ok = false;
    }
    checkGarbage();
    rebuildOrderHeap();

    simpDB_assigns = nAssigns();
    simpDB_props   = clauses_literals + learnts_literals;   // (shouldn't depend on stats really, but it will do for now)
    return true;
}

/*_________________________________________________________________________________________________
|
|  search : (nof_conflicts : int) (params : const SearchParams&)  ->  [lbool]
|  
|  Description:
|    Search for a model the specified number of conflicts. 
|  
|  Output:
|    'l_True' if a partial assigment that is consistent with respect to the clauseset is found. If
|    all variables are decision variables, this means that the clause set is satisfiable. 'l_False'
|    if the clause set is unsatisfiable. 'l_Undef' if the bound on number of conflicts is reached.
|________________________________________________________________________________________________@*/
lbool Solver::search(int& nof_conflicts)
{
    int         backtrack_level,lbd;
    vec<Lit>    learnt_clause;
    starts++;
    for (;;){
        CRef confl = propagate();
nexta:
        if (confl != CRef_Undef){ // CONFLICT
            if (VSIDS){
                if (--timer == 0 && var_decay < 0.95) timer = 5000, var_decay += 0.01;
            }
            else if (alpha > min_alpha){
                    alpha -= alpha_dec;
                    beta = 1-alpha;
                 }

            conflicts++; nof_conflicts--;
            if (conflicts == 100000 && learnt_small < 100) small_lbd_lim = 5;
            if (decisionLevel() == 0) return l_False;

            learnt_clause.clear();
            analyze(confl, learnt_clause, backtrack_level, lbd);
            cancelUntil(backtrack_level);

            lbd--;
            if (VSIDS) lbdQueue.push(lbd);
            sumLBD += lbd;

            if (verbosity > 0 && conflicts%10000==0 && (recursiveDepth==0 || conflicts%40000==0)){ 
                  printf("c | %g LBD=%d ", cpuTime(), int(sumLBD /conflicts));
                  printf("%8d  %5d  %7d | %7d %8d %8d | %8d  %6.3f %% |\n", 
		   (int)starts,(int)(conflicts/starts), (int)conflicts, nFreeVars(), nClauses(), 
                   (int)clauses_literals, nLearnts(), progressEstimate()*100);
	     }

         
            if (learnt_clause.size() == 1){
                confl = unitPropagation(learnt_clause[0]);
                if (confl != CRef_Undef) return l_False;
            }
            else{
                CRef cr = ca.alloc(learnt_clause, true);
                learnts.push(cr);
                Clause & c = ca[cr];
                c.set_lbd(lbd);
                if (lbd <= small_lbd_lim){
                    learnt_small++;
                    c.mark(SMALL);
                }else if (lbd <= 6){
                    c.mark(MIDSZ);
                    c.touched() = conflicts;
                }else claBumpActivity(c); 
                attachClause(cr);
                uncheckedEnqueue(learnt_clause[0], cr);
               if (certifiedUNSAT) printDrupLits(learnt_clause, 0, needExtVar);//add
           }
   
            if (VSIDS) varDecayActivity();
            claDecayActivity();

       // NO CONFLICT
            bool restart;
            if (!VSIDS) restart = nof_conflicts <= 0;
            else restart = lbdQueue.full() && (lbdQueue.avg()*0.8>((float)sumLBD)/conflicts);
            if (restart){
                lbdQueue.clear();
                progress_estimate = progressEstimate();
                cancelUntil(0);
                return l_Undef; 
            }
            if (learnt_clause.size() == 1) goto nexta;
        }
        else{
            if (decisionLevel() == 0 && !simplify()) return l_False;

            if (nVars()>100000 && conflicts <200000 && conflicts > next_simplify_small){
                       if (!simplifysmallclause()) return l_False;
                       next_simplify_small=conflicts+5000;
            }
           
            if (conflicts >= next_LONG_reduce){
                next_LONG_reduce = conflicts + 15000;
                reduceDB();

                if(conflicts<500000) {
                      if(re_learn() == l_False) return l_False;
                      if(VSIDS) varDecayActivity();
                }
      
                if (conflicts <700000 || conflicts > next_simplify_small){
                       if (!simplifysmallclause()) return l_False;
                       next_simplify_small=conflicts+50000;
                }
            }

            decisions++;
            Lit next = pickBranchLit();
            if (next == lit_Undef)  return l_True;
          
            // Increase decision level and enqueue 'next'
            newDecisionLevel();
            uncheckedEnqueue(next);
        }
    }
}


double Solver::progressEstimate() const
{
    double  progress = 0;
    double  F = 1.0 / nVars();

    for (int i = 0; i <= decisionLevel(); i++){
        int beg = i == 0 ? 0 : trail_lim[i - 1];
        int end = i == decisionLevel() ? trail.size() : trail_lim[i];
        progress += pow(F, i) * (end - beg);
    }

    return progress / nVars();
}

static double luby(double y, int x){
    int size, seq;
    for (size = 1, seq = 0; size < x+1; seq++, size = 2*size+1);
    while (size-1 != x){
        size = (size-1)>>1;
        seq--;
        x = x % size;
    }
    return pow(y, seq);
}

lbool Solver::solve_()
{
    outVars=auxVar=nVars();
    model.clear();
    if (!ok) return l_False;
    solves++;

    add_tmp.clear();
    lbool   status            = l_Undef;

    unsigned int switch_lim= nVars()<200000 ? 3e7 : 8e6; 
    VSIDS = true;
    int curr_restarts = 0;
    int nof_conflicts;
    while (status == l_Undef){
        if((conflicts>100000  || clauses.size()>4e6) && conflicts<switch_lim) VSIDS = false;
        if (VSIDS) nof_conflicts = INT32_MAX;
        else{
            nof_conflicts = luby(restart_inc, curr_restarts) * restart_first;
            curr_restarts++;
            if(conflicts > switch_lim) VSIDS = true;
        }
       
        int prev_conf=conflicts;
        status = search(nof_conflicts);
        if(conflicts-prev_conf>80000) h_probe=true;
        if(sumLBD/conflicts>14) dumpmode=1;
        if(conflicts>200000 && nVars()<100000){
             if(sumLBD/conflicts>20) cancelTreeSolve=1;
             if( status != l_Undef) break;
             printf("c mid solve SAT \n");
             status=simp_solve();
             break;
        }
    }

    if (status == l_True){
        // Extend & copy model:
        model.growTo(nVars());
        for (int i = 0; i < nVars(); i++) model[i] = value(i);
        solveEqu(equhead, nVars(), model);

        for (int i = 0; i < nVars(); i++) if(model[i] == l_Undef) model[i]=l_True;
 
     }else if (status == l_False) ok = false;

    cancelUntil(0);
    return status;
}

unsigned int conf_lim[20];

lbool Solver::solve2_()
{
    if(ite2ext == 0) needExtVar=0;
    model.clear();
    if (!ok) return l_False;
    bitVecNo=-1;

    if(verbosity > 0 || recursiveDepth<3) printf("c D=%d hard#=%d unsat#=%d unsat9#=%d non-Tree=%d \n",recursiveDepth,hardnum,unsatCnt, unsat9Cnt,cancelTreeSolve);
  
    lbool   status = l_Undef;
    unsigned int switch_lim= nVars()<100000 ? 3e7 : 1e7; 
    if(recursiveDepth==0){
         for(int i=1; i<9; i++) conf_lim[i]=i*500;
         conf_lim[0]=2e5;
         conf_lim[9]=conf_lim[10]=3e5;
         conf_lim[11]=1e7;
    }
    else  if(hardnum> unsatCnt+800) cancelTreeSolve=1;
        
    VSIDS = true;
    int curr_restarts = 0;
    int nof_conflicts;
    unsigned int blm=outVars>6000? 3e5:1e5;
    while (status == l_Undef){
        if(conflicts>blm && conflicts < switch_lim) VSIDS = false;
        if (VSIDS) nof_conflicts = INT32_MAX;
        else{
            nof_conflicts = luby(restart_inc, curr_restarts) * restart_first;
            curr_restarts++;
            if(conflicts > switch_lim) VSIDS = true;
        }
        bitVecNo = (recursiveDepth==0 && nVars()>2500 && VSIDS && conflicts>10000 && conflicts < 40000) ? bitVecNo+1:-1;
        status = search(nof_conflicts);
        if(recursiveDepth){
              if(conflicts>5e6) cancelTreeSolve=1;
              if(cancelTreeSolve) break;
        }
        else{
            if(conflicts>2000000) continue;
            if(nVars()>4000 || (outVars>6000 && conflicts<1800000)) continue;
        }
        if(cancelTreeSolve) continue;
        if(conflicts >= conf_lim[recursiveDepth] && (recursiveDepth || sumLBD/conflicts<17)){
              if(status == l_Undef){
                  status=subsolve();
              }
              if(recursiveDepth) break;
        }    
    }
 
    if(conflicts > 1800000) hardnum += 80;
    else {
         int m=conflicts/250000; 
         hardnum += (m*m);
    }

    if (status == l_Undef) return l_Undef;
    if (status == l_True){
        // Extend & copy model:
        if(verbosity > 0) printf("c solution found depth=%d \n",recursiveDepth);

        solveEqu(equhead, nVars(), assigns);
        if(recursiveDepth) return status;
        model.growTo(nVars());
        for (int i = 0; i < nVars(); i++) model[i] = value(i);
    }
    unsatCnt++;
    if(recursiveDepth <= 9) unsat9Cnt++;
    return status;
}

void Solver:: solveEqu(int *equRepr, int equVars, vec<lbool> & Amodel)
{   
   if(equRepr==0) return;
   for (int i=1; i <= equVars; i++){
         if(equRepr[i]==0 || equRepr[i]==i) continue;
         int v=equRepr[i];
         v=ABS(v)-1;
         Amodel[i-1] = l_False;
         if (Amodel[v] == l_Undef) Amodel[v] = l_True;
         if (Amodel[v] == l_True){
                   if(equRepr[i] > 0) Amodel[i-1] = l_True;
         }
         else      if(equRepr[i] < 0) Amodel[i-1] = l_True;
    }
}

//=================================================================================================
// Writing CNF to DIMACS:
// 
// FIXME: this needs to be rewritten completely.

static Var mapVar(Var x, vec<Var>& map, Var& max)
{
    if (map.size() <= x || map[x] == -1){
        map.growTo(x+1, -1);
        map[x] = max++;
    }
    return map[x];
}


void Solver::toDimacs(FILE* f, Clause& c, vec<Var>& map, Var& max)
{
    if (satisfied(c)) return;

    for (int i = 0; i < c.size(); i++)
        if (value(c[i]) != l_False)
            fprintf(f, "%s%d ", sign(c[i]) ? "-" : "", mapVar(var(c[i]), map, max)+1);
    fprintf(f, "0\n");
}


void Solver::toDimacs(const char *file, const vec<Lit>& assumps)
{
    FILE* f = fopen(file, "wr");
    if (f == NULL)
        fprintf(stderr, "could not open file %s\n", file), exit(1);
    toDimacs(f, assumps);
    fclose(f);
}


void Solver::toDimacs(FILE* f, const vec<Lit>& assumps)
{
    // Handle case when solver is in contradictory state:
    if (!ok){
        fprintf(f, "p cnf 1 2\n1 0\n-1 0\n");
        return; }

    vec<Var> map; Var max = 0;

    // Cannot use removeClauses here because it is not safe
    // to deallocate them at this point. Could be improved.
    int cnt = 0;
    for (int i = 0; i < clauses.size(); i++)
        if (!satisfied(ca[clauses[i]]))
            cnt++;

    for (int i = 0; i < clauses.size(); i++)
        if (!satisfied(ca[clauses[i]])){
            Clause& c = ca[clauses[i]];
            for (int j = 0; j < c.size(); j++)
                if (value(c[j]) != l_False)
                    mapVar(var(c[j]), map, max);
        }

    // Assumptions are added as unit clauses:
    cnt += assumptions.size();

    fprintf(f, "p cnf %d %d\n", max, cnt);

    for (int i = 0; i < assumptions.size(); i++){
        assert(value(assumptions[i]) != l_False);
        fprintf(f, "%s%d 0\n", sign(assumptions[i]) ? "-" : "", mapVar(var(assumptions[i]), map, max)+1);
    }

    for (int i = 0; i < clauses.size(); i++)
        toDimacs(f, ca[clauses[i]], map, max);

    if (verbosity > 0)
        printf("c Wrote %d clauses with %d variables.\n", cnt, max);
}


//=================================================================================================
// Garbage Collection methods:

void Solver::relocAll(ClauseAllocator& to)
{
    // All watchers:
    //
    watches.cleanAll();
    watchesBin.cleanAll();
    for (int v = 0; v < nVars(); v++)
        for (int s = 0; s < 2; s++){
            Lit p = mkLit(v, s);
            vec<Watcher>& ws = watches[p];
            for (int j = 0; j < ws.size(); j++)
                ca.reloc(ws[j].cref, to);
            vec<Watcher>& ws_bin = watchesBin[p];
            for (int j = 0; j < ws_bin.size(); j++)
                ca.reloc(ws_bin[j].cref, to);
        }

    // All learnt:
    //
    for (int i = 0; i < learnts.size(); i++) ca.reloc(learnts[i], to);
  
    // All original:
    //
    int i, j;
    for (i = j = 0; i < clauses.size(); i++)
        if (ca[clauses[i]].mark() != 1){
            ca.reloc(clauses[i], to);
            clauses[j++] = clauses[i];
        }
    clauses.shrink(i - j);

 // All reasons:
    //
    for (int i = 0; i < trail.size(); i++){
        Var v = var(trail[i]);
        if (reason(v) != CRef_Undef && (ca[reason(v)].reloced() || locked(ca[reason(v)])))
            ca.reloc(vardata[v].reason, to);
    }

}

void Solver::garbageCollect()
{
    // Initialize the next region to a size corresponding to the estimated utilization degree. This
    // is not precise but should avoid some unnecessary reallocations for the new region:
    ClauseAllocator to(ca.size() - ca.wasted());

    relocAll(to);
    if (verbosity >= 2)
        printf("c |  Garbage collection:   %12d bytes => %12d bytes             |\n",
               ca.size()*ClauseAllocator::Unit_Size, to.size()*ClauseAllocator::Unit_Size);
    to.moveTo(ca);
}

//--------------------------------------------------------------------
lbool Solver :: simp_solve()
{    int i,j;

     cancelUntil(0);
     int *ext2ite=(int *) calloc (nVars()+1, sizeof (int));
     Solver * s_solver=new Solver();
     s_solver->subformuleClause=1;
     s_solver->verbosity = verbosity;
     vec<Lit> lits;
     for (i =0; i < clauses.size(); i++){
           Clause & c = ca[clauses[i]];
 	   int sz=c.size();
	   lits.clear();
           for (j = 0; j < sz; j++) {
		Lit p=c[j];
          	if (value(p) == l_True) goto nextc;
		if (value(p) == l_False) continue;
	        int v=var(p)+1;
                if(ext2ite[v]==0){
                       s_solver->newVar();
                       ext2ite[v]=s_solver->nVars();
                }
                int ivar=ext2ite[v]-1;
                Lit ilit= sign(p) ? ~mkLit(ivar)  : mkLit(ivar);
                lits.push(ilit);
	   }
           s_solver->addClause_(lits);
        nextc:  ;
     }
/*
    for (i =0; i < learnts.size(); i++){
           Clause & c = ca[learnts[i]];
 	   int sz=c.size();
           if(sz>2) continue;
	   lits.clear();
           for (j = 0; j < sz; j++) {
		Lit p=c[j];
          	if (value(p) == l_True) goto nextd;
		if (value(p) == l_False) continue;
	        int v=var(p)+1;
                if(ext2ite[v]==0){
                       s_solver->newVar();
                       ext2ite[v]=s_solver->nVars();
                }
                int ivar=ext2ite[v]-1;
                Lit ilit= sign(p) ? ~mkLit(ivar)  : mkLit(ivar);
                lits.push(ilit);
	   }
           s_solver->addClause_(lits);
        nextd:  ;
     }
*/
     ite2ext=(int *) malloc(sizeof(int)*(s_solver->nVars()+1));
     for(int i=1; i<=nVars(); i++) ite2ext[ext2ite[i]]=i;
     free(ext2ite);

     for (int i=1; i <= s_solver->nVars(); i++){
              int ev = ite2ext[i];
              s_solver->activity[i-1]=activity[ev-1];
     }

     vec<Lit> dummy;
     s_solver->needExtVar=1;
     lbool rc = s_solver->solve2_();
     if(rc==l_True || rc==l_Undef) {
           for (i=1; i <= s_solver->nVars(); i++){
                  int ev = ite2ext[i];
                  if(assigns[ev-1] != l_Undef) continue;
                  if(rc==l_True) assigns[ev-1]= s_solver->assigns[i-1];
                  else{
                       Lit p = (s_solver->assigns[i-1]==l_True) ? mkLit(ev-1)  : ~mkLit(ev-1);
                       uncheckedEnqueue(p);
                  }
            }
    }
    free(ite2ext);
    delete s_solver;
    return rc;
}

lbool Solver :: subsolve()
{    
       cancelUntil(0);
       Lit pivot = lit_Undef;
       unsigned int maxw=0;
       for(int i=0; i<1; i++){
           Lit lit = pickBranchLit();
           if( lit == lit_Undef)  break;
           unsigned int w=watchesBin[lit].size()+watches[lit].size();
           w= w*(watchesBin[~lit].size()+watches[~lit].size());
           if(maxw<w || pivot == lit_Undef){                 
                 pivot=lit;
                 maxw=w;
           }
       }
       if (pivot == lit_Undef)  return l_True;
      
       Solver* subsolver2;
       lbool ret2=runSubsolver(subsolver2, ~pivot);
       if(ret2 == l_True){
               copyAssign(subsolver2);
               delete subsolver2;
               return l_True;
        }
        delete subsolver2;
        if(ret2==l_Undef) return l_Undef;
     
        Solver* subsolver1;
        lbool ret1=runSubsolver(subsolver1, pivot);
        if(ret1 == l_True) {
                copyAssign(subsolver1);
                delete subsolver1;
                return l_True;
        }
        delete subsolver1;
        return ret1;
}

lbool Solver :: runSubsolver(Solver* & newsolver, Lit plit)
{
        int nV=nVars();
        newsolver=new Solver();

        newsolver->subformuleClause=1;
        newsolver->needExtVar = needExtVar;
        newsolver->verbosity = verbosity;
   
        while (nV > newsolver->nVars()) newsolver->newVar();
        newsolver->recursiveDepth=recursiveDepth+1;
        double maxVact=activity[var(plit)];
        if(maxVact<1) maxVact=1;
        for(int i=0; i<nV; i++){
	      if(assigns[i] != l_Undef){
		       Lit lt = (assigns[i] == l_True) ? mkLit(i) : ~mkLit(i);
                       newsolver->uncheckedEnqueue(lt);
               }
               newsolver->activity[i]=activity[i]/maxVact;
        }
 
        if(certifiedUNSAT){
            int lit=toIntLit(plit);
            if(needExtVar) lit=GetextLit (lit);
            treeAuxLit[treeDepth]=0;
            treeExtLit[treeDepth]=-lit;
            treeDepth++;
        } 

        if(value(var(plit)) == l_Undef) newsolver->uncheckedEnqueue(plit);
    
        lbool ret=dumpClause(clauses, this, newsolver, 10000000);
        if(ret == l_False) goto run_end;
        ret=dumpClause(learnts, this, newsolver, 2);
        if(ret == l_False) goto run_end;
        
        if(newsolver->propagate() != CRef_Undef ){
              ret=l_False;
run_end:
              newsolver->init_trailsize=newsolver->trail.size();
              goto run_end2;
        }     
        newsolver->init_trailsize=newsolver->trail.size();

        ret=newsolver->solve2_();
run_end2: ;
        if(certifiedUNSAT){
              if(ret == l_False && treeDepth){
                     vec<Lit> ps;
                     ps.clear();
                     printDrupLits(ps, 0, needExtVar);
                     if( treeDepth>3 ){
                            newsolver->ClearClause(newsolver->learnts, 1);
                            newsolver->ClearUnit();
                     }
              }
              treeDepth--;
        }
        return ret;
}

void Solver :: ClearClause(vec<CRef>& cs,int deleteflag)
{
    if(certifiedUNSAT && deleteflag && subformuleClause) deleteflag=1;
    else deleteflag=0;
    for (int i = 0; i < cs.size(); i++){
            removeClause(cs[i]);
            if(deleteflag)  printDrupClause(ca[cs[i]], 1, needExtVar);
    }
    cs.clear();
}
      

lbool Solver::dumpClause(vec<CRef>& cs,Solver* fromSolver,Solver* toSolver,int sizelimit) 
{    int i,j;
     vec<Lit> lits;
     for (i =0; i < cs.size(); i++){
           Clause & c = fromSolver->ca[cs[i]];
 	   int sz=c.size();
           lits.clear();
	   for (j = 0; j < sz; j++) {
                  Lit lit=c[j];
		  if (toSolver->value(lit) == l_True) break;
   		  if (toSolver->value(lit) == l_False) continue;
                  lits.push(lit);
	   }
           if(j<sz) continue;
           if(sizelimit==2 && lits.size() > 7) continue;
         //  if(sizelimit==2 && (lits.size() > 2 || c.mark() != SMALL) ) continue;
           if(lits.size()==0) return l_False;
           if(lits.size() == 1){
                 toSolver->uncheckedEnqueue(lits[0]);
                 if(toSolver->propagate() != CRef_Undef ) return l_False;
                //  if(toSolver->unitPropagation(lits[0]);
           }
           else{  bool learnflag=false;
                  if(sizelimit==2){
                     if(lits.size()==2){
                        if(level(var(lits[0]))>6 || level(var(lits[1]))>6) learnflag=true;
                     }
                     else{
                          if(lits.size()>3) learnflag=true;
                          else  for(int j=0; j<3; j++)
                                      if(level(var(lits[0]))>3) {learnflag=true; break;}
                      }
                  }
                  if(dumpmode && learnflag){
                        CRef cr = toSolver->ca.alloc(lits, true);
                        if(certifiedUNSAT) printDrupLits(lits, 0, needExtVar);//add
                        toSolver->learnts.push(cr);
                        toSolver->ca[cr].mark(LONG);
                        for(int j=0; j<lits.size(); j++){
                           int x=var(lits[j]);
                           toSolver->vardata[x].level=vardata[x].level;
                        }
                        toSolver->ca[cr].set_lbd(c.lbd());
                        toSolver->attachClause(cr);
                  }
                  else{
                     if(!learnflag){
                          CRef cr = toSolver->ca.alloc(lits, false);
                          toSolver->clauses.push(cr);
                          toSolver->attachClause(cr);
                      }
                 }
          }
     }
     return l_Undef;
}

void Solver::copyAssign(Solver* fromSolver)
{
    for(int i=0; i<nVars(); i++){
	    if(assigns[i] != l_Undef) continue;
	    assigns[i]=fromSolver->assigns[i];
    }    
}
//=====================
// a bin clasue exists?
bool Solver::hasBin(Lit p, Lit q)
{
    vec<Watcher>&  wbin  = watchesBin[~p];
    for(int k = 0;k<wbin.size();k++) {
	  Lit imp = wbin[k].blocker;
	  if( imp == q) return true;
    }
    return false;
}	  

inline void Solver::setmark(vec<int> & liftlit)
{   liftlit.clear();
    for (int c = trail.size()-1; c >= trail_lim[0]; c--) {
            int lit=toInt(trail[c]);
            mark[lit]=1;
            liftlit.push(lit);
    }
    cancelUntil0(0);
}

inline void Solver::clearmark(vec<int> & liftlit)
{
     for (int i =0; i < liftlit.size(); i++) mark[liftlit[i]]=0;
}

lbool Solver:: addequ(Lit p, Lit q)
{ 
    int pul=toInt(p);
    int qul=toInt(q);
 
    if(pul == qul)  return l_Undef;
    if(pul == (qul^1)) return l_False;
    int pv=var(p);
    touchVar.push(pv);
    int qv=var(q);
    touchVar.push(qv);
    if( add_equ_link(pul,qul) == l_False) return l_False;
 
   for(int i=0; i<2; i++){
         int v= (i==0) ? qv : pv;
         int h=equhead[v+1];
         if(v+1 != h && h>0){
             h--;
             activity[h]   += activity[v];
             varActivityRescale(h);
             varBumpCnt[h] += varBumpCnt[v];
             if(decisionTime[h] < decisionTime[v]) decisionTime[h] = decisionTime[v];
         }
    }

    return l_Undef;
}

inline void Solver :: simpAddClause(const vec<Lit>& lits)
{
     if(certifiedUNSAT) printDrupLits(lits, 0, needExtVar);
     CRef cr = ca.alloc(lits, false);
     clauses.push(cr);
     attachClause(cr);
}

lbool Solver:: add_equ_link(int pul, int qul)
{
    if(equhead == 0) equhead = (int * ) calloc (nVars()+1, sizeof(int));
    if(equlink == 0) equlink = (int * ) calloc (nVars()+1, sizeof(int));
    if( pul < qul){
       int t=pul;  pul=qul;  qul=t;
    }
    int pl=toIntLit(toLit(pul));
    int ql=toIntLit(toLit(qul));

    if(pl<0){ pl=-pl; ql=-ql; }
    int qv=ABS(ql);
    if(equhead[pl] == equhead[qv]){
        if(equhead[pl] == 0){
           equhead[pl]=ql; equhead[qv]=qv;
           equlink[qv]=pl;
           equsum++;
           return l_Undef;
        }
        if(ql < 0) return l_False;
        return l_Undef;
    }
    if(equhead[pl] == -equhead[qv]){
        if(ql < 0) return l_Undef;
        return l_False;
    }
    equsum++;
    if(equhead[pl] == 0 && equhead[qv]){
        if(ql < 0) equhead[pl]=-equhead[qv];
        else equhead[pl]=equhead[qv];
        int h=ABS(equhead[pl]);
        int t = equlink[h];
        equlink[h]=pl;
        equlink[pl]=t;
        return l_Undef;
    }
    if(equhead[pl] && equhead[qv]==0){
        if(ql < 0) equhead[qv]=-equhead[pl];
        else equhead[qv]=equhead[pl];
        int h=ABS(equhead[qv]);
        int t = equlink[h];
        equlink[h]=qv;
        equlink[qv]=t;
        return l_Undef;
    }
//merge
    int x=equhead[pl];
    int y=equhead[qv];
    if(ql < 0) y=-y;
    int next=ABS(y);
    while(1){
         if(equhead[next]==y) equhead[next]=x;
         else  equhead[next]=-x;
         if(equlink[next]==0) break;
         next=equlink[next];
    }    
    int xh=ABS(x);
    int t=equlink[xh];
    equlink[xh]=ABS(y);
    equlink[next]=t;
    return l_Undef;
}

lbool Solver:: hbr_probe()
{ 
   if(recursiveDepth && !h_probe) return l_Undef;
   if(conflicts>10 || recursiveDepth){
        if(conflicts < next_probe) return l_Undef;
        if(conflicts>8000000) return l_Undef;
        if(recursiveDepth && conflicts<200000) return l_Undef;
     }
     next_probe = conflicts + 200000;
     cancelUntil0(0);

     count = (int* ) calloc (2*nVars()+1, sizeof(int));
     litsum = (int* ) calloc (2*nVars()+1, sizeof(int));
     mark = (char * ) calloc (2*nVars()+1, sizeof(char));
     touchMark = (char *) malloc(sizeof(char) * (nVars()+1));

     for (int i =0; i < nVars(); i++)  touchMark[i]=1;
     int nC=nClauses();
     nC += (nC/2);
     if(nC>1e6) nC=1e6;
     int m=0;
     lbool ret=l_Undef;
     bool old_VSIDS=VSIDS;
     VSIDS=true;
     while(hbrsum<nC){
          m++;
          touchVar.clear();
          int oldhbr=hbrsum, oldequ=equsum, olduni=unitsum;
          ret=probeaux();
          if(ret == l_False) break;
          if(recursiveDepth || probeSum>3 || conflicts>100000 && m>25000) break;        
          if(oldhbr==hbrsum && oldequ==equsum && olduni==unitsum) break;
     }

     if(verbosity>0) printf("c hyper bin res#=%d equ#=%d uni#=%d \n",  hbrsum,equsum,unitsum);
     
     touchVar.clear();
     free(count);
     free(litsum);
     free(mark);
     free(touchMark);
     touchMark=0;
     probeSum++;
     VSIDS=old_VSIDS;
     return ret;
}

lbool Solver::probeaux()
{    
     int old_equsum = equsum;
     for (int i = 0; i<clauses.size() && i<400000; i++){
           Clause & c = ca[clauses[i]];
 	   int sz=c.size();
           if(sz!=3) continue;
	   int tcnt=0;
           for (int j = 0; j < sz; j++) {
                tcnt += touchMark[var(c[j])];
                if(value(c[j]) != l_Undef) goto next;
           }
           if(tcnt < 2) continue;
           if(simpleprobehbr (c) == l_False) return l_False;
next:      ;
     }

//lift
    vec<int> liftlit,unit;
    int liftcnt;
    if(probeSum){
         liftcnt = nVars()/2;
         if(liftcnt>10000) liftcnt=10000;
    }
    else liftcnt=10000;
    for(int vv=0; vv<nVars() && liftcnt > 0; vv++){
	    if(touchMark[vv]==0) continue;
            if(assigns[vv] != l_Undef) continue;
            if(equhead)
                if(equhead[vv+1] && ABS(equhead[vv+1]) <= vv) continue;

            Lit p = mkLit(vv);
            int pos=watchesBin[p].size();
            int neg=watchesBin[~p].size();

            if(pos==0 || neg==0) continue;
            liftcnt--;
            if(pos < neg) p=~p;
            CRef confl=trypropagate(p);
            if (confl != CRef_Undef){
                    cancelUntil0(0);
                    if(value(p) != l_Undef) continue; 
                    confl=unitPropagation(~p);
                    if (confl != CRef_Undef) return l_False;
                    unitsum++;
                    continue;
            }
            setmark(liftlit);
            confl=trypropagate(~p);
            if (confl != CRef_Undef){
                    cancelUntil0(0);
                    clearmark(liftlit);
                    if(value(p) != l_Undef) continue;
                    unitPropagation(p);
                    unitsum++;
                    continue;
            }
            unit.clear();
            vec<Lit> eqLit;
            eqLit.clear();
            for (int c = trail.size()-1; c > trail_lim[0]; c--) {//not contain p
                 int lit=toInt(trail[c]);
                 if(mark[lit]) unit.push(lit);
                 else{
                      if(mark[lit^1]) {//equ p=~lit
                          Lit q = ~trail[c];//~toLit(lit); 
                          eqLit.push(q);
                          unit.push(lit);
                       }
                 }
             }
            clearmark(liftlit);
            cancelUntil0(0);
//p=q
             for (int i =0; i< eqLit.size(); i++) {
                     Lit q=eqLit[i];
                     
                     if(certifiedUNSAT){
                             if(!out_binclause(p,  ~q)) continue;
                             if(!out_binclause(~p, q) )  continue;
                     }
                     
                     lbool ret=addequ(p,q);
                      if(ret == l_False){
                            if(certifiedUNSAT) printDrupUnit(p,needExtVar);
                            return l_False;
                      }
            }
//unit  
            for (int i =0; i < unit.size(); i++){
                  int lit=unit[i];
              	  Lit uLit=toLit(lit);
	          if(value(uLit) != l_Undef) continue;
                  if(!addbinclause(p,  uLit)) continue;
                  if(!addbinclause(~p, uLit)) continue;
                  confl=unitPropagation(uLit);
                  if (confl != CRef_Undef) return l_False;
                  unitsum++;
            }
   }
 //  if(equhead){//bug
 //        for (Var v = 0; v < nVars(); v++)
 //            if(decision[v] && equhead[v] &&  equhead[v] !=v) setDecisionVar(v, false);
 //  }
   for (int i =0; i < nVars(); i++) touchMark[i]=0;
  
   for (int i =0; i < touchVar.size(); i++) touchMark[touchVar[i]]=1;
  
   if(certifiedUNSAT && treeDepth>3) return l_Undef;

   if(old_equsum != equsum) return replaceEqVar();
   return l_Undef;
}

lbool Solver:: simpleprobehbr (Clause & c)
{   vec<int> ostack;
    vec<Lit> lits;
    ostack.clear();
    CRef confl= CRef_Undef;
    int sum=0,cnt=0,maxcount=0;
    lbool ret=l_Undef;
    for (int i =0; i < 3; i++){
        Lit lit=c[i];
        vec<Watcher>&  bin  = watchesBin[lit];
        if(bin.size()) cnt++;
    }
    if(cnt <= 1) goto done;
    for (int i =0; i < 3; i++){
        Lit lit=c[i];
        int litint=toInt(lit);
        sum += litint;
        vec<Watcher>&  bin  = watchesBin[lit];
        for(int k = 0;k<bin.size();k++) {
	      Lit other = bin[k].blocker;
              int oint = toInt(other);
              if(mark[oint]) continue;
              int nother = oint^1;
              if(mark[nother]) {//unit
                    if(value(lit) != l_Undef) goto done;
                    confl = unitPropagation(~lit);
                    goto done;
              }
              count[oint]++;
              if(maxcount < count[oint]) maxcount = count[oint];
              litsum[oint] += litint;
              mark[oint] =1;
              ostack.push(oint);
       }
       for(int k = 0;k<bin.size();k++) {
 	    Lit other = bin[k].blocker;
            mark[toInt(other)]= 0;
       }
   }
   if(maxcount < 2 ) goto done;
   for (int i =0; i < ostack.size(); i++){
           int oint=ostack[i];
           if(count[oint]<=1) continue;
           Lit other = toLit(oint);
           if(count[oint]==3){//unit
                  if(value(other) != l_Undef) continue;
                  confl = unitPropagation(other);
                  if (confl != CRef_Undef) goto done;
                  continue;
           }
           int litint = sum - litsum[oint];
           Lit lit = toLit(litint);
           if(other == lit) {//unit
                  if(value(other) != l_Undef) continue; 
                  confl = unitPropagation(other);
                  if (confl != CRef_Undef) goto done;
                  continue;
           }
           if(other == (~lit)) continue;
           if(hasBin(other, lit)) continue;

           hbrsum++;
           lits.clear();
           lits.push(other);
           lits.push(lit);

           simpAddClause(lits); //add <other, lit>
         
           if(hasBin(~other, ~lit)){//other=~lit
                   ret=addequ(other, ~lit);
                   if(ret == l_False){
                         if(certifiedUNSAT) printDrupUnit(other,needExtVar);
                         goto done;
                   }
           }
           else{
                   touchVar.push(var(other));
                   touchVar.push(var(lit));
           }               
  }
done:
  for (int i =0; i < ostack.size(); i++){
        int oint=ostack[i];
        count[oint]=litsum[oint]=0;
        mark[oint]=0;
  }     
  if (confl != CRef_Undef) return l_False;
  return ret;
}

void Solver:: buildEquClause()
{   vec<Lit> lits;
    if(equhead==0) return;
 
    if(dummyVar == 0)  dummyVar = (char * ) calloc (nVars()+1, sizeof(char));
    
    for (int i=1; i <= nVars(); i++){
         if(equhead[i]==0 || equhead[i]==i || dummyVar[i]) continue;
         Lit p=mkLit(i-1);
         int lit=equhead[i];
         dummyVar[i]=1;
         Lit q = (lit>0) ? mkLit(lit-1) : ~mkLit(-lit-1);
         if( !hasBin(p, ~q) ) {
                lits.clear();
                lits.push(p);
                lits.push(~q);
                if(certifiedUNSAT) printDrupLits(lits, 0, needExtVar);
                else   simpAddClause(lits);
         }
         if(!hasBin(~p, q) ) {
                lits.clear();
                lits.push(~p);
                lits.push(q);
                if(certifiedUNSAT) printDrupLits(lits, 0, needExtVar);
                else   simpAddClause(lits);
         }
    }
}

CRef Solver::unitPropagation(Lit p)
{
    int oldts=trail.size();
     uncheckedEnqueue(p);
     CRef confl = propagate();
     if(decisionLevel()==0){
         if (certifiedUNSAT){
              if(confl != CRef_Undef){
                  printDrupUnit(trail[oldts], needExtVar);
                  trail.shrink(trail.size() - oldts);
                  return confl;
              }
              for(int i=oldts; i<trail.size(); i++) printDrupUnit(trail[i], needExtVar);
         }
   }
   return confl;
}

bool Solver :: is_conflict(vec<Lit> & lits)
{  
   cancelUntil0(0);
   newDecisionLevel();
   int i;
   for (i=0; i<lits.size(); i++){
        Lit p = ~lits[i];
        if ( value(p) == l_True) continue;
        if ( value(p) == l_False) break;
        UncheckEnqueueNoLevel(p);
        CRef confl = simplePropagate();
        if (confl != CRef_Undef) break;
   }
   cancelUntil0(0);
   if(i<lits.size()) return true;
   return false;
}

bool Solver:: addbinclause(Lit p, Lit q)
{
      if(hasBin(p,q)) return true;
      vec<Lit> ps;
      ps.clear();
      ps.push(p);
      ps.push(q);
      if(is_conflict(ps)){
           if(certifiedUNSAT) printDrupLits(ps, 0, needExtVar);
           CRef cr = ca.alloc(ps, false);
           clauses.push(cr);
           attachClause(cr);
           return true;
      }
      return false;
}

bool Solver:: out_binclause(Lit p, Lit q)
{
      if(hasBin(p,q)) return true;
      vec<Lit> ps;
      ps.clear();
      ps.push(p);
      ps.push(q);
      if(is_conflict(ps)){
           if(certifiedUNSAT) printDrupLits(ps, 0, needExtVar);
           return true;
      }
      return false;
}

lbool Solver::replaceEqVar()
{  
     watches.cleanAll();
     watchesBin.cleanAll();
     if(equhead==0) return l_Undef;
     if(certifiedUNSAT) buildEquClause();

     lbool ret=removeEqVar(clauses, false);
     if(ret == l_False) return l_False;
     ret=removeEqVar(learnts, true);
     watches.cleanAll();
     watchesBin.cleanAll();
     return ret;
}

lbool Solver::removeEqVar(vec<CRef>& cls, bool learntflag)
{
    vec<Lit> newCls;
    int i, j,k,n;

    lbool ret=l_Undef;
  
    for (i = j = 0; i < cls.size(); i++){
        if(cls[i]==CRef_Undef) continue;
        Clause& c = ca[cls[i]];
        if(c.mark()==1) continue;//bug
        if(ret!=l_Undef){
            cls[j++] = cls[i];
            continue;
        }
        newCls.clear();
        int T=0;
        int del=0;
        for (k = 0; k < c.size(); k++){
             Lit p=c[k];
             if (value(p) == l_True) {
                    del=T=1; 
                    break;
             }
             if (value(p) == l_False){
                     del=1; 
                     continue;
             }
             int v = var(p)+1;
             Lit q;
             if(equhead[v]==0 || equhead[v]==v) q=p;
             else{ int lit;
                 if(sign(p)) lit = -equhead[v];
                 else        lit = equhead[v];
                 q = (lit>0) ? mkLit(lit-1) : ~mkLit(-lit-1);
                 del=1;
            }
             if(del){
                for(n=newCls.size()-1; n>=0; n--){
                   if( q  == newCls[n]) break;
                   if( ~q == newCls[n]) {T=1; break;}
                }
             }
             else n=-1;
             if(T) break;
             if(n<0) newCls.push(q);
        }
        if(del==0){
            cls[j++] = cls[i];
            continue;
        }
        if(T){
           removeClause(cls[i]);
           continue;
        }
        if(touchMark && newCls.size()<3){
            for (k = 0; k < newCls.size(); k++) touchMark[var(newCls[k])]=1;
        }
        if(newCls.size()==0){
              cls[j++] = cls[i];
              ret=l_False;
              continue;
       }
       if(newCls.size()==1){
              removeClause(cls[i]);
              if( unitPropagation(newCls[0]) != CRef_Undef ) ret=l_False;
              unitsum++;
              continue;
       }
       if(certifiedUNSAT) printDrupLits(newCls, 0, needExtVar);
       removeClause(cls[i]);
       if(certifiedUNSAT && learntflag) printDrupClause(c, 1, needExtVar);
       CRef cr = ca.alloc(newCls, learntflag);
       attachClause(cr);
       cls[j++] = cr;
    }
    cls.shrink(i - j);
    checkGarbage();
    return ret; 
}

// ===============================
inline void Solver:: swapEqTofront(Lit * lits, int sz, int eqVal)
{     int j=0,k;
      for(int i=0; i<sz; i++){
           Lit lt=lits[i];
           if(mark[toInt(lt)]!=eqVal) continue;
           lits[i]=lits[j]; lits[j++]=lt;
      }
      if(j>11){
          sort(lits, j);
          return;
      }
      for(int i=1; i<j; i++){
           Lit lt=lits[i];
           int m=toInt(lt);
           for(k=i-1; k>=0; k--){
               if(m>toInt(lits[k])) break;
               lits[k+1]=lits[k];
           }
           lits[k+1]=lt;
     }
}

inline int Solver:: moveEqTofront(vec <Lit> & preLit,vec <Lit> & curLit,vec <Lit> & nxtLit)
{      
      for(int i=preLit.size()-1; i>=0; i--) mark[toInt(preLit[i])]  =1;
      for(int i=nxtLit.size()-1; i>=0; i--) mark[toInt(nxtLit[i])] +=2;
      int en1=0,en2=0,en3=0;
      for(int i=curLit.size()-1; i>=0; i--){
             int lit=toInt(curLit[i]);
             if(mark[lit]==1) en1++;
             else if(mark[lit]==2) en2++;
                  else if(mark[lit]==3) en3++;
      }
      swapEqTofront((Lit *)curLit, curLit.size(),3);
      swapEqTofront((Lit *)curLit+en3, curLit.size()-en3,1);
      swapEqTofront((Lit *)curLit+en1+en3, curLit.size()-en1-en3,2);
      for(int i=preLit.size()-1; i>=0; i--) mark[toInt(preLit[i])]=0;
      for(int i=nxtLit.size()-1; i>=0; i--) mark[toInt(nxtLit[i])]=0;
      return en1+en2+en3;
}

lbool Solver::re_learn()
{ 
    if(recursiveDepth && conflicts<260000) return l_Undef;
    if(dumpmode==0 && conflicts>20000 || clauses.size()>4e6) return l_Undef;
    cancelUntil(0);
    lbool ret=l_Undef;

    mark = (char * ) calloc (2*nVars()+1, sizeof(char));
    vec <Lit> lits[3],best_learnt,tmplits,decLits;
    CRef confl;
    int elev, nx=2, cu_i=-1, truePos=1000000,Tflag;
    int newLBD;
    Lit pivot;
    int limit=learnts.size()-2000;
    for (int i = 0; i <= limit; i++){
          int cu=(nx+2)%3;
          int pr=(nx+1)%3;
          vec <Lit> & prLits=lits[pr];
          vec <Lit> & cuLits=lits[cu];
          vec <Lit> & nxLits=lits[nx];
//  
          nxLits.clear();
          while (i < limit){
              Clause & c =ca[learnts[i]];
              if(c.size()<5 || c.done()) {i++; continue;}
              for(int j=0; j<c.size(); j++){
                  nxLits.push(c[j]);
              }
              c.done(1);
              break;
          }
  
          if(cuLits.size()){
               moveEqTofront(prLits,cuLits,nxLits);
               if(1){
                     tmplits.clear();
                     for(int j=0; j<cuLits.size(); j++) mark[toInt(cuLits[j])]=2;
                     int eqvn=-1;
                     for(int j=0; j<prLits.size(); j++){
                           Lit lt=prLits[j];
                           if(mark[toInt(lt)]==2){
                               tmplits.push(lt);
                               mark[toInt(lt)]=0;
                           }
                           else if(eqvn ==-1 ) eqvn=j;
                     }
                     for(int j=0; j<cuLits.size(); j++){
                           Lit lt=cuLits[j];
                           if(mark[toInt(lt)]){
                               tmplits.push(lt);
                               mark[toInt(lt)]=0;
                           }
                           cuLits[j]=tmplits[j];
                     }
                 
                     if(eqvn <= 0 ) eqvn=0;
                     CRef cu_cr=learnts[cu_i];
                     Clause & c =ca[cu_cr];
                     detachClause(cu_cr, true);
                     if(truePos <= eqvn){//subsume  (A V B V C V D)(A V B V C) 
                              truePos=100000;
                              decLits.clear();      
                              goto Del;
                     }
                     if(eqvn >  decLits.size() ) eqvn = decLits.size();  
                     elev=0;
                     for(int k=0; k < eqvn; k++){
                         Lit lit=prLits[k];
                         if(level(var(lit))>elev) elev=level(var(lit));
                     }

                     if (decLits.size() < elev) elev=eqvn=0;
                     if (eqvn < elev) elev=eqvn;
                     decLits.shrink(decLits.size()-elev);
                     cancelUntil0(elev);
                     confl = CRef_Undef;
                     pivot = lit_Undef;
                     Tflag=0;
                     truePos=cuLits.size()+1;
           
                     for(int k = 0; k <cuLits.size(); k++){
                          Lit lit=cuLits[k];
                          if(k<eqvn){
                               if(assigns[var(lit)] == l_Undef){
                                  uncheckedEnqueue(~lit);
                               }
                               continue;
                          }
                          if(value(lit) == l_True){
                                if(level(var(lit))==0) goto Del;
                                confl = reason(var(lit));
                                pivot=lit;
                                Tflag=1;
                                truePos=k+1;
                                break;
                          }
                          if(value(lit) == l_False){
                               continue;
                          }
                          decLits.push(lit);
                          newDecisionLevel();
                          uncheckedEnqueue(~lit);
                          confl = propagate();
                          if (confl != CRef_Undef) {truePos=k+1; break;}
                     }
        
                     best_learnt.clear();
                     if (confl == CRef_Undef){
                            if(Tflag) best_learnt.push(pivot);
                            for(int k=decLits.size()-1; k>=0; k--) best_learnt.push(decLits[k]);
                            if(best_learnt.size()==0){ 
                                   ret=l_False; 
                                   goto Del;
                            } 
                     }   
                     else {
                          simpAnalyze(confl, best_learnt, pivot);
                          if (best_learnt.size() >= decLits.size()+Tflag){
                               best_learnt.clear();
                               if(Tflag) best_learnt.push(pivot);
                               for(int k=decLits.size()-1; k>=0; k--) best_learnt.push(decLits[k]);
                          }
                     }
 
                     if (best_learnt.size() < c.size()){
                              if (best_learnt.size() == 1){
                                     cancelUntil0(0);
                                     decLits.clear();
                                     if(assigns[var(best_learnt[0])] == l_Undef){
                                          confl = unitPropagation(best_learnt[0]);
      	                                  if (confl != CRef_Undef) ret=l_False;
                                     }
Del:
                                     c.mark(1);
                                     ca.free(cu_cr);
                                     learnts[cu_i]=CRef_Undef;
                                     if(ret==l_False) goto done;
                                     if (certifiedUNSAT) printDrupClause(c, 1, needExtVar);//delete
                                     goto next;
                               }
                               if (certifiedUNSAT){
                                     printDrupLits(best_learnt, 0, needExtVar);//add
                                     printDrupClause(c, 1, needExtVar);//delete
                               }
                               for (int k = 0; k < best_learnt.size(); k++) {
                                    c[k] = best_learnt[k];
                                    if(VSIDS) varBumpVSIDSactivity(var(c[k]),var_inc);
                               }
                             
                               claBumpActivity(c);
                               newLBD = computeLBD(best_learnt);
                               if(c.lbd()>newLBD || c.lbd()<=1) c.set_lbd(newLBD);
                               c.shrink(c.size() - best_learnt.size());//bug
                     }
                     attachClause(cu_cr);
               }
          }
next:      
          cu_i=i;
          nx = (nx+1)%3;
    }
done:
    free(mark);
    cancelUntil0(0);
    int j=0;
    for (int i = 0; i < learnts.size(); i++) if(learnts[i] != CRef_Undef) learnts[j++]=learnts[i];  
    learnts.shrink(learnts.size()-j);
    return ret;
}

void Solver::simpAnalyze(CRef confl, vec<Lit> & out_learnt, Lit p)
{
    if(p != lit_Undef) out_learnt.push(p);
    int index   = trail.size() - 1;
    int pathC = 0;

    do{
        Clause & c = ca[confl];
	if(c.size()==2 && value(c[0])==l_False) {
	    Lit tmp = c[0]; c[0] =  c[1], c[1] = tmp;
	}
   
        for (int j = (p == lit_Undef) ? 0 : 1; j < c.size(); j++){
            Lit q = c[j];
            if (!seen[var(q)] && level(var(q)) > 0){
                seen[var(q)] = 1;
                if (level(var(q)) >= decisionLevel()) pathC++;
                else out_learnt.push(q);
	    }
        }
        
        if (pathC == 0){
             p=lit_Undef;
             break;
        }
        // Select next clause to look at:
        while (!seen[var(trail[index--])]);
        p     = trail[index+1];
        confl = reason(var(p));
        seen[var(p)] = 0;
        pathC--;
    } while (pathC > 0);
    if(p != lit_Undef) out_learnt.push(~p);

    for (int j = 0; j < out_learnt.size(); j++) seen[var(out_learnt[j])] = 0;
}

