use std::ops::{Index, IndexMut};

pub struct UncheckedSlice<'a, T: 'a> {
    slice: &'a [T],
}

pub struct UncheckedMutSlice<'a, T: 'a> {
    slice: &'a mut [T],
}

impl<'a, T> Index<usize> for UncheckedSlice<'a, T> {
    type Output = T;

    fn index(&self, index: usize) -> &T {
        debug_assert!(index < self.slice.len());
        unsafe { self.slice.get_unchecked(index) }
    }
}

impl<'a, T> Index<usize> for UncheckedMutSlice<'a, T> {
    type Output = T;

    fn index(&self, index: usize) -> &T {
        debug_assert!(index < self.slice.len());
        unsafe { self.slice.get_unchecked(index) }
    }
}

impl<'a, T> IndexMut<usize> for UncheckedMutSlice<'a, T> {
    fn index_mut(&mut self, index: usize) -> &mut T {
        debug_assert!(index < self.slice.len());
        unsafe { self.slice.get_unchecked_mut(index) }
    }
}

pub trait UncheckedIndexing<T> {
    type Element;
    fn unchecked(&self) -> UncheckedSlice<Self::Element>;
}

pub trait UncheckedMutIndexing<T>: UncheckedIndexing<T> {
    fn unchecked_mut(&mut self) -> UncheckedMutSlice<Self::Element>;
}

impl<T> UncheckedIndexing<T> for [T] {
    type Element = T;
    fn unchecked(&self) -> UncheckedSlice<T> {
        UncheckedSlice { slice: self }
    }
}

impl<T> UncheckedMutIndexing<T> for [T] {
    fn unchecked_mut(&mut self) -> UncheckedMutSlice<T> {
        UncheckedMutSlice { slice: self }
    }
}
