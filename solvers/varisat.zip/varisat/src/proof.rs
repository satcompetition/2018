use lit::Lit;
use std::io::{BufWriter, Write};

pub struct Proof {
    target: Option<BufWriter<Box<Write>>>,
}

impl Default for Proof {
    fn default() -> Proof {
        Proof::new()
    }
}

impl Proof {
    pub fn new() -> Proof {
        Proof { target: None }
    }

    pub fn add_clause(&mut self, lits: &[Lit]) {
        if let Some(target) = self.target.as_mut() {
            for &lit in lits {
                write!(target, "{} ", lit).expect("error writing proof");
            }
            writeln!(target, "0").expect("error writing proof");
        }
    }

    pub fn delete_clause(&mut self, lits: &[Lit]) {
        if let Some(target) = self.target.as_mut() {
            write!(target, "d ").expect("error writing proof");
            for &lit in lits {
                write!(target, "{} ", lit).expect("error writing proof");
            }
            writeln!(target, "0").expect("error writing proof");
        }
    }

    pub fn open_proof<W: Write + 'static>(&mut self, write: W) {
        self.target = Some(BufWriter::new(Box::new(write)))
    }

    pub fn close_proof(&mut self) {
        if let Some(target) = self.target.as_mut() {
            target.flush().expect("error writing proof");
        }
        self.target = None
    }
}
