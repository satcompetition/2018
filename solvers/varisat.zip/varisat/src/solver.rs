use std::io::Write;
use std::time::Instant;

use context::Context;
use lit::{Lit, Var};
use schedule::EventAction;
use stats::Stats;
use trit::Trit;

pub struct Solver {
    ctx: Context,
    state: Trit,
    time_begin: Option<Instant>,
    time_end: Option<Instant>,
}

impl Default for Solver {
    fn default() -> Solver {
        Solver::new()
    }
}

impl Solver {
    pub fn new() -> Solver {
        Solver {
            ctx: Context::new(),
            state: Trit::Unk,
            time_begin: None,
            time_end: None,
        }
    }

    pub fn add_clause(&mut self, lits: &[Lit]) {
        if let Some(max_index) = lits.iter().map(|&lit| lit.index()).max() {
            if max_index >= self.ctx.var_count {
                self.ctx.set_var_count(max_index + 1);
            }
        }

        if self.state == Trit::False {
            return;
        }

        let mut lits = lits.to_vec();

        if self.state == Trit::True {
            self.ctx.cdcl().restart();
            self.state = Trit::Unk;
        }

        if lits.is_empty() {
            self.state = Trit::False;
            return;
        }

        // TODO Simplify clause?
        lits.sort_unstable();
        lits.dedup();

        let mut last = None;

        for &lit in &lits {
            if last == Some(!lit) {
                return;
            }
            last = Some(lit);
        }

        if lits.len() == 1 {
            let current_var_value = self.ctx.prop.var_value(lits[0].var());
            if current_var_value == Trit::Unk {
                self.ctx.prop.assign_lit(lits[0]);
            } else if current_var_value == lits[0].is_negative() {
                self.state = Trit::False;
            }
        } else if lits.len() == 2 {
            self.ctx.prop.add_binary([lits[0], lits[1]]);
        } else {
            self.ctx
                .clauses
                .add_irred_clause(Some(&mut self.ctx.prop), &lits);
        }
    }

    pub fn solve(&mut self) -> Trit {
        self.time_begin = Some(Instant::now());
        self.ctx.scheduler().default_schedule();
        loop {
            self.state = self.ctx.cdcl().conflict_step();
            if self.state != Trit::Unk {
                self.ctx.proof.close_proof();
                break;
            }
            while let Some(event) = self.ctx.scheduler().next_event() {
                event.perform_action(&mut self.ctx);
            }
        }
        self.time_end = Some(Instant::now());
        self.display_end_stats();
        self.state
    }

    pub fn write_proof<W: Write + 'static>(&mut self, write: W) {
        self.ctx.proof.open_proof(write)
    }

    pub fn assignments(&self) -> Vec<Lit> {
        let mut result = vec![];

        for i in 0..self.ctx.var_count {
            let var = Var::from_index(i);
            let value = self.ctx.prop.var_value(var);
            if value != Trit::Unk {
                result.push(Lit::from_var(var, value == Trit::False));
            }
        }

        result
    }

    fn display_end_stats(&self) {
        let time_begin = self.time_begin.expect("time_begin");
        let time_end = self.time_end.expect("time_end");

        let duration = time_end.duration_since(time_begin);
        let secs = duration.as_secs() as f64 + (duration.subsec_nanos() as f64) * 1e-9;

        let stats = Stats::new(&self.ctx);

        info!("total: {:.1} sec", secs);
        info!("restarts: {}", stats.restarts);
        info!(
            "conflicts: {} ({:.1} / sec)",
            stats.conflicts,
            stats.conflicts as f64 / secs
        );
        info!(
            "decisions: {} ({:.1} / sec)",
            stats.decisions,
            stats.decisions as f64 / secs
        );
        info!(
            "propagations: {} ({:.1} / sec)",
            stats.propagations,
            stats.propagations as f64 / secs
        );
    }
}
