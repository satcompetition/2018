use noisy_float::prelude::*;

use lit::Var;
use unchecked::*;

pub struct Vsids {
    activity: Vec<R32>,
    heap: Vec<Var>,
    position: Vec<Option<usize>>,
    bump: R32,
    inv_decay: R32,
}

fn rescale_limit() -> R32 {
    r32(f32::max_value() / 16.0)
}

impl Default for Vsids {
    fn default() -> Vsids {
        Vsids::new()
    }
}

impl Vsids {
    pub fn new() -> Vsids {
        Vsids {
            activity: vec![],
            heap: vec![],
            position: vec![],
            bump: r32(1.0),
            inv_decay: r32(1.0 / 0.95),
        }
    }

    pub fn set_var_count(&mut self, count: usize) {
        let old_count = self.activity.len();
        debug_assert!(!self.heap.iter().any(|&v| v.index() >= count));
        self.activity.resize(count, r32(0.0));
        self.position.resize(count, None);

        for i in old_count..count {
            self.make_available(Var::from_index(i));
        }
    }

    pub fn set_decay(&mut self, decay: R32) {
        debug_assert!(decay < r32(1.0));
        debug_assert!(decay > r32(1.0 / 16.0));
        self.inv_decay = r32(1.0) / decay;
    }

    pub fn bump(&mut self, var: Var) {
        let rescale = {
            let value = &mut self.activity.unchecked_mut()[var.index()];
            *value += self.bump;
            *value >= rescale_limit()
        };
        if rescale {
            self.rescale();
        }
        if let Some(pos) = self.position[var.index()] {
            self.sift_up(pos);
        }
    }

    pub fn decay(&mut self) {
        self.bump *= self.inv_decay;
        if self.bump >= rescale_limit() {
            self.rescale();
        }
    }

    fn rescale(&mut self) {
        let rescale_factor = r32(1.0) / rescale_limit();
        for activity in &mut self.activity {
            *activity *= rescale_factor;
        }
        self.bump *= rescale_factor;
    }

    pub fn make_available(&mut self, var: Var) {
        if self.position[var.index()].is_none() {
            let position = self.heap.len();
            self.position[var.index()] = Some(position);
            self.heap.push(var);
            self.sift_up(position);
        }
    }

    pub fn pop_available(&mut self) -> Option<Var> {
        if self.heap.is_empty() {
            None
        } else {
            let var = self.heap.swap_remove(0);
            if !self.heap.is_empty() {
                let top_var = self.heap[0];
                self.position[top_var.index()] = Some(0);
                self.sift_down(0);
            }
            self.position[var.index()] = None;
            Some(var)
        }
    }

    pub fn pop_available_filtered<F>(&mut self, mut filter: F) -> Option<Var>
    where
        F: FnMut(Var) -> bool,
    {
        loop {
            match self.pop_available() {
                None => return None,
                Some(var) => {
                    if filter(var) {
                        return Some(var);
                    }
                }
            }
        }
    }

    fn sift_up(&mut self, mut pos: usize) {
        let var = self.heap[pos];
        loop {
            if pos == 0 {
                return;
            }
            let parent_pos = (pos - 1) / 2;
            let parent_var = self.heap[parent_pos];
            if self.activity[parent_var.index()] >= self.activity[var.index()] {
                return;
            }
            self.position[var.index()] = Some(parent_pos);
            self.heap[parent_pos] = var;
            self.position[parent_var.index()] = Some(pos);
            self.heap[pos] = parent_var;
            pos = parent_pos;
        }
    }

    fn sift_down(&mut self, mut pos: usize) {
        let var = self.heap[pos];
        loop {
            let mut largest_pos = pos;
            let mut largest_var = var;

            let left_pos = pos * 2 + 1;
            if left_pos < self.heap.len() {
                let left_var = self.heap[left_pos];

                if self.activity[largest_var.index()] < self.activity[left_var.index()] {
                    largest_pos = left_pos;
                    largest_var = left_var;
                }
            }

            let right_pos = pos * 2 + 2;
            if right_pos < self.heap.len() {
                let right_var = self.heap[right_pos];

                if self.activity[largest_var.index()] < self.activity[right_var.index()] {
                    largest_pos = right_pos;
                    largest_var = right_var;
                }
            }

            if largest_pos == pos {
                return;
            }

            self.position[var.index()] = Some(largest_pos);
            self.heap[largest_pos] = var;
            self.position[largest_var.index()] = Some(pos);
            self.heap[pos] = largest_var;
            pos = largest_pos;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rescale_bump() {
        let mut vsids = Vsids::new();
        vsids.set_var_count(4);
        vsids.set_decay(r32(1.0 / 8.0));

        for _ in 0..4 {
            vsids.pop_available();
        }

        for i in 0..4 {
            for _ in 0..i {
                vsids.bump(Var::from_index(i));
            }
        }

        for _ in 0..41 {
            vsids.decay();
        }

        for _ in 0..30 {
            vsids.bump(var!(4));
        }

        {
            // Decay is a power of two so these values are exact
            #![allow(float_cmp)]
            assert_eq!(vsids.activity[0], 0.0);
            assert_eq!(vsids.activity[2], vsids.activity[1] * r32(2.0));
            assert!(vsids.activity[3] > vsids.activity[2]);
        }
    }

    #[test]
    fn rescale_decay() {
        let mut vsids = Vsids::new();
        vsids.set_var_count(4);
        vsids.set_decay(r32(1.0 / 8.0));

        for _ in 0..4 {
            vsids.pop_available();
        }

        for i in 0..4 {
            for _ in 0..i {
                vsids.bump(Var::from_index(i));
            }
        }

        for _ in 0..60 {
            vsids.decay();
        }

        {
            // Decay is a power of two so these values are exact
            #![allow(float_cmp)]
            assert_eq!(vsids.activity[0], 0.0);
            assert_eq!(vsids.activity[2], vsids.activity[1] * r32(2.0));
            assert_eq!(vsids.activity[3], vsids.activity[1] * r32(3.0));
        }
    }

    #[test]
    fn heap_sorts() {
        let mut vsids = Vsids::new();
        vsids.set_var_count(8);

        for _ in 0..8 {
            vsids.pop_available();
        }

        for i in 0..8 {
            for _ in 0..i {
                vsids.bump(Var::from_index(i));
            }
        }

        for i in 0..8 {
            vsids.make_available(Var::from_index((i * 5) % 8));
        }

        for i in (0..8).rev() {
            assert_eq!(vsids.pop_available(), Some(Var::from_index(i)));
        }
        assert_eq!(vsids.pop_available(), None);
    }

    #[test]
    fn heap_bump() {
        let mut vsids = Vsids::new();
        vsids.set_var_count(8);
        vsids.set_decay(r32(1.0 / 8.0));

        for _ in 0..8 {
            vsids.pop_available();
        }

        for i in 0..8 {
            for _ in 0..i {
                vsids.bump(Var::from_index(i));
            }
        }

        for i in 0..8 {
            vsids.make_available(Var::from_index((i * 5) % 8));
        }

        for i in (0..4).rev() {
            assert_eq!(vsids.pop_available(), Some(Var::from_index(i + 4)));
        }

        vsids.decay();
        vsids.decay();

        for i in 0..8 {
            for _ in 0..(8 - i) {
                vsids.bump(Var::from_index(i));
            }
        }

        for i in 0..4 {
            assert_eq!(vsids.pop_available(), Some(Var::from_index(i)));
        }

        assert_eq!(vsids.pop_available(), None);
    }
}
