use std::result::Result;

use clause::{ClauseAlloc, ClauseRef};
use lit::{Lit, LitIdx, Var};
use trit::Trit;
use unchecked::*;

#[derive(Copy, Clone)]
struct Watch {
    cref: ClauseRef,
    blocking: Lit,
}

#[derive(Debug, Copy, Clone)]
pub struct PropInfo {
    pub reason: Reason,
    pub level: LitIdx,
}

impl Default for PropInfo {
    fn default() -> PropInfo {
        PropInfo {
            reason: Reason::Assumption,
            level: 0,
        }
    }
}

#[derive(Debug, Eq, PartialEq, Copy, Clone)]
pub enum Reason {
    Assumption,
    Binary([Lit; 1]),
    Long(ClauseRef),
}

impl Reason {
    pub fn lits<'a>(&'a self, clauses: &'a ClauseAlloc) -> &'a [Lit] {
        match *self {
            Reason::Assumption => &[],
            Reason::Binary(ref lits) => lits,
            Reason::Long(cref) => &clauses.lits(cref)[1..],
        }
    }
}

#[derive(Debug, Eq, PartialEq)]
pub enum Conflict {
    Binary([Lit; 2]),
    Long(ClauseRef),
}

impl Conflict {
    pub fn lits<'a>(&'a self, clauses: &'a ClauseAlloc) -> &'a [Lit] {
        match *self {
            Conflict::Binary(ref lits) => lits,
            Conflict::Long(cref) => clauses.lits(cref),
        }
    }
}

pub struct UnitProp {
    assignments: Vec<Trit>,
    saved: Vec<Trit>,
    trail: Vec<Lit>,
    levels: Vec<LitIdx>,
    depth: usize,
    watches: Vec<Vec<Watch>>,
    binaries: Vec<Vec<Lit>>,
    prop_info: Vec<PropInfo>,
    propagation_count: usize,
}

fn is_true(assignments: &[Trit], lit: Lit) -> bool {
    assignments.unchecked()[lit.index()] == lit.is_positive()
}

fn is_false(assignments: &[Trit], lit: Lit) -> bool {
    assignments.unchecked()[lit.index()] == lit.is_negative()
}

fn set_true(assignments: &mut [Trit], lit: Lit) {
    assignments.unchecked_mut()[lit.index()] = lit.is_positive().into();
}

impl Default for UnitProp {
    fn default() -> UnitProp {
        UnitProp::new()
    }
}

impl UnitProp {
    pub fn new() -> UnitProp {
        UnitProp {
            assignments: vec![],
            saved: vec![],
            trail: vec![],
            levels: vec![],
            depth: 0,
            watches: vec![],
            binaries: vec![],
            prop_info: vec![],
            propagation_count: 0,
        }
    }

    pub fn set_var_count(&mut self, count: usize) {
        self.assignments.resize(count, Trit::Unk);
        self.saved.resize(count, Trit::Unk);
        self.watches.resize(count * 2, vec![]);
        self.binaries.resize(count * 2, vec![]);
        self.prop_info.resize(count, Default::default());
    }

    pub fn add_watch(&mut self, cref: ClauseRef, lits: [Lit; 2]) {
        #[allow(needless_range_loop)]
        for i in 0..2 {
            let watch = Watch {
                cref: cref,
                blocking: lits[i ^ 1],
            };
            self.watches.unchecked_mut()[(!lits[i]).code()].push(watch);
        }
    }

    pub fn clear_watchlists(&mut self) {
        for watches in &mut self.watches {
            watches.clear();
        }
    }

    pub fn add_binary(&mut self, lits: [Lit; 2]) {
        #[allow(needless_range_loop)]
        for i in 0..2 {
            self.binaries[..].unchecked_mut()[(!lits[i]).code()].push(lits[i ^ 1]);
        }
    }

    pub fn var_value(&self, var: Var) -> Trit {
        self.assignments.unchecked()[var.index()]
    }

    pub fn saved_var_value(&self, var: Var) -> Trit {
        self.saved.unchecked()[var.index()]
    }

    pub fn assign_lit(&mut self, lit: Lit) {
        self.assign_lit_reason(lit, Reason::Assumption);
    }

    pub fn assign_lit_reason(&mut self, lit: Lit, reason: Reason) {
        debug_assert_eq!(self.assignments.unchecked_mut()[lit.index()], Trit::Unk);
        set_true(&mut self.assignments, lit);
        self.trail.push(lit);
        self.prop_info.unchecked_mut()[lit.index()] = PropInfo {
            reason: reason,
            level: self.levels.len() as LitIdx,
        }
    }

    pub fn propagate(&mut self, clauses: &mut ClauseAlloc) -> Result<(), Conflict> {
        while self.depth < self.trail.len() {
            self.propagation_count += 1;
            let assignment = self.trail[self.depth];
            self.depth += 1;
            self.propagate_binary(assignment)?;
            self.propagate_long(assignment, clauses)?;
        }
        Ok(())
    }

    fn propagate_binary(&mut self, assignment: Lit) -> Result<(), Conflict> {
        for &lit in &self.binaries.unchecked()[assignment.code()] {
            let lit_value = &mut self.assignments.unchecked_mut()[lit.index()];
            if *lit_value == Trit::Unk {
                *lit_value = lit.is_positive().into();
                self.trail.push(lit);
                self.prop_info.unchecked_mut()[lit.index()] = PropInfo {
                    reason: Reason::Binary([!assignment]),
                    level: self.levels.len() as LitIdx,
                }
            } else if *lit_value == lit.is_negative() {
                return Err(Conflict::Binary([lit, !assignment]));
            }
        }
        Ok(())
    }

    fn propagate_long(
        &mut self,
        assignment: Lit,
        clauses: &mut ClauseAlloc,
    ) -> Result<(), Conflict> {
        // TODO: Can this be done nicer without being slower?
        unsafe {
            let watch_begin;
            let watch_end;
            {
                let watch_list = &mut self.watches.unchecked_mut()[assignment.code()];
                watch_begin = watch_list.as_mut_ptr();
                watch_end = watch_begin.offset(watch_list.len() as isize);
            }
            let mut watch_ptr = watch_begin;

            let false_lit = !assignment;

            let mut watch_write = watch_ptr;

            'watchers: while watch_ptr != watch_end {
                let watch = *watch_ptr;
                watch_ptr = watch_ptr.offset(1);
                if is_true(&self.assignments, watch.blocking) {
                    *watch_write = watch;
                    watch_write = watch_write.offset(1);
                    continue;
                }

                let cref = watch.cref;

                let clause_ptr = clauses.lits_ptr_mut(cref);
                let &mut header = clauses.header_mut(cref);

                let mut first = *clause_ptr.offset(0);
                if first == false_lit {
                    let c1 = *clause_ptr.offset(1);
                    first = c1;
                    *clause_ptr.offset(0) = c1;
                    *clause_ptr.offset(1) = false_lit;
                }

                let new_watch = Watch {
                    cref: cref,
                    blocking: first,
                };

                if first != watch.blocking && is_true(&self.assignments, first) {
                    *watch_write = new_watch;
                    watch_write = watch_write.offset(1);
                    continue;
                }

                let clause_len = header.len();

                let mut lit_ptr = clause_ptr.offset(2);
                let lit_end = clause_ptr.offset(clause_len as isize);

                while lit_ptr != lit_end {
                    let ck = *lit_ptr;
                    if !is_false(&self.assignments, ck) {
                        *clause_ptr.offset(1) = ck;
                        *lit_ptr = false_lit;
                        self.watches.unchecked_mut()[(!ck).code()].push(new_watch);
                        continue 'watchers;
                    }
                    lit_ptr = lit_ptr.offset(1);
                }

                *watch_write = new_watch;
                watch_write = watch_write.offset(1);

                if is_false(&self.assignments, first) {
                    while watch_ptr != watch_end {
                        *watch_write = *watch_ptr;
                        watch_write = watch_write.offset(1);
                        watch_ptr = watch_ptr.offset(1);
                    }
                    let out_size = watch_begin.offset_to(watch_write).unwrap();

                    self.watches.unchecked_mut()[assignment.code()].truncate(out_size as usize);

                    return Err(Conflict::Long(cref));
                }

                set_true(&mut self.assignments, first);

                self.trail.push(first);
                self.prop_info.unchecked_mut()[first.index()] = PropInfo {
                    reason: Reason::Long(cref),
                    level: self.levels.len() as LitIdx,
                }
            }

            let out_size = watch_begin.offset_to(watch_write).unwrap();
            self.watches.unchecked_mut()[assignment.code()].truncate(out_size as usize);
        }
        Ok(())
    }

    pub fn current_level(&self) -> usize {
        self.levels.len()
    }

    pub fn next_level(&mut self) {
        debug_assert_eq!(self.depth, self.trail.len());
        self.levels.push(self.trail.len() as LitIdx);
    }

    pub fn backtrack<F>(&mut self, level: usize, unassign: F)
    where
        F: FnOnce(&[Lit]),
    {
        self.depth = self.levels[level] as usize;
        self.levels.truncate(level);
        {
            let trail_end = &self.trail[self.depth..];
            unassign(trail_end);
            for &lit in trail_end {
                let assignment = &mut self.assignments.unchecked_mut()[lit.index()];
                self.saved.unchecked_mut()[lit.index()] = *assignment;
                *assignment = Trit::Unk;
            }
        }
        self.trail.truncate(self.depth);
    }

    pub fn prop_info(&self, var: Var) -> &PropInfo {
        &self.prop_info[var.index()]
    }

    pub fn update_prop_reason(&mut self, var: Var, cref: ClauseRef) {
        if cfg!(debug_assertions) {
            assert_ne!(self.assignments[var.index()], Trit::Unk);
            match self.prop_info[var.index()].reason {
                Reason::Long(_) => (),
                _ => panic!("invalid var to update"),
            }
        }

        self.prop_info[var.index()].reason = Reason::Long(cref);
    }

    pub fn trail(&self) -> &[Lit] {
        &self.trail
    }

    pub fn toplevel(&self) -> &[Lit] {
        let len = self.levels
            .get(0)
            .map_or(self.trail.len(), |&len| len as usize);
        &self.trail[..len]
    }

    pub fn binary_clause_count(&self) -> usize {
        let double_counted: usize = self.binaries.iter().map(|lits| lits.len()).sum();
        debug_assert_eq!(double_counted % 2, 0);
        double_counted / 2
    }

    pub fn propagation_count(&self) -> usize {
        self.propagation_count
    }

    pub fn is_asserting(&self, cref: ClauseRef, var: Var) -> bool {
        self.assignments.unchecked()[var.index()] != Trit::Unk
            && self.prop_info.unchecked()[var.index()].reason == Reason::Long(cref)
    }
}

#[cfg(test)]
pub mod tests {
    use super::*;
    use clause::ClauseHeader;
    use lit::Var;

    pub fn load_clauses(uprop: &mut UnitProp, ca: &mut ClauseAlloc, clauses: &[&[Lit]]) {
        for clause in clauses {
            if clause.len() == 2 {
                uprop.add_binary([clause[0], clause[1]]);
            } else {
                let cref = ca.add_clause(ClauseHeader::new(clause.len()), clause);
                uprop.add_watch(cref, [clause[0], clause[1]]);
            }
        }
    }

    #[test]
    fn binary_only() {
        let mut uprop = UnitProp::new();
        uprop.set_var_count(9);

        uprop.add_binary(lits![-1, 2]);
        uprop.add_binary(lits![-1, 3]);
        uprop.add_binary(lits![-2, 4]);
        uprop.add_binary(lits![-2, 3]);
        uprop.add_binary(lits![-3, -6]);
        uprop.add_binary(lits![5, -6]);
        uprop.add_binary(lits![5, 7]);
        uprop.add_binary(lits![-7, -8]);

        uprop.assign_lit(lit!(1));

        assert!(uprop.propagate(&mut ClauseAlloc::new()).is_ok());

        assert_eq!(uprop.assignments[var!(1).index()], Trit::True);
        assert_eq!(uprop.assignments[var!(2).index()], Trit::True);
        assert_eq!(uprop.assignments[var!(3).index()], Trit::True);
        assert_eq!(uprop.assignments[var!(4).index()], Trit::True);
        assert_eq!(uprop.assignments[var!(5).index()], Trit::Unk);
        assert_eq!(uprop.assignments[var!(6).index()], Trit::False);
        assert_eq!(uprop.assignments[var!(7).index()], Trit::Unk);
        assert_eq!(uprop.assignments[var!(8).index()], Trit::Unk);
        assert_eq!(uprop.assignments[var!(9).index()], Trit::Unk);

        uprop.assign_lit(lit!(-5));
        uprop.assign_lit(lit!(8));

        assert_eq!(
            uprop.propagate(&mut ClauseAlloc::new()),
            Err(Conflict::Binary(lits![-7, -8]))
        );
    }

    #[test]
    fn test_mixed() {
        let mut uprop = UnitProp::new();
        let mut ca = ClauseAlloc::new();

        uprop.set_var_count(11);

        load_clauses(
            &mut uprop,
            &mut ca,
            &cnf![
                2, -9, -1;
                -7, -5, -3;
                8, 1, 10;
                1, -2;
                1, 3;
                1, -4;
                1, 5;
                -2, 3;
                -2, -4;
                -2, 5;
                3, -4;
                3, 5;
                -4, 5;
                -6, 7;
                -6, -8;
                -6, 9;
                7, -8;
                7, 9;
                -1, 10, 11, 5;
                -1, 10, 11, 2;
                -1, 10, 11, 3;
                -1, 10, 11, 4;
                10, -11;
            ],
        );

        uprop.next_level();

        uprop.assign_lit(lit!(-3));

        assert!(uprop.propagate(&mut ca).is_ok());

        let check_props = |uprop: &UnitProp| {
            assert_eq!(uprop.assignments[var!(1).index()], Trit::True);
            assert_eq!(uprop.assignments[var!(2).index()], Trit::False);
            assert_eq!(uprop.assignments[var!(3).index()], Trit::False);
            assert_eq!(uprop.assignments[var!(4).index()], Trit::False);
            assert_eq!(uprop.assignments[var!(5).index()], Trit::True);
            assert_eq!(uprop.assignments[var!(6).index()], Trit::False);
            assert_eq!(uprop.assignments[var!(7).index()], Trit::True);
            assert_eq!(uprop.assignments[var!(8).index()], Trit::Unk);
            assert_eq!(uprop.assignments[var!(9).index()], Trit::False);
            assert_eq!(uprop.assignments[var!(10).index()], Trit::Unk);
            assert_eq!(uprop.assignments[var!(11).index()], Trit::Unk);
        };

        check_props(&uprop);

        uprop.next_level();

        uprop.assign_lit(lit!(-8));
        assert!(uprop.propagate(&mut ca).is_ok());

        assert_eq!(uprop.assignments[var!(10).index()], Trit::Unk);
        assert_eq!(uprop.assignments[var!(11).index()], Trit::Unk);

        uprop.next_level();

        uprop.assign_lit(lit!(-10));

        assert!(uprop.propagate(&mut ca).is_err());

        uprop.backtrack(2, |_| ());
        assert_eq!(uprop.current_level(), 2);

        uprop.assign_lit(lit!(11));

        assert!(uprop.propagate(&mut ca).is_ok());

        assert_eq!(uprop.assignments[var!(10).index()], Trit::True);

        uprop.backtrack(1, |_| ());
        assert_eq!(uprop.current_level(), 1);

        check_props(&uprop);

        for _ in 0..2 {
            uprop.backtrack(0, |_| ());
            assert_eq!(uprop.current_level(), 0);
            assert_eq!(uprop.trail.len(), 0);
            uprop.next_level();

            uprop.assign_lit(lit!(1));
            uprop.assign_lit(lit!(-3));

            assert!(uprop.propagate(&mut ca).is_ok());

            check_props(&uprop);
        }
    }
}
