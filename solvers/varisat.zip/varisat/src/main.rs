#![feature(alloc, offset_to, nll)]
#![cfg_attr(not(clippy), allow(unknown_lints))]
extern crate alloc;
extern crate env_logger;
extern crate noisy_float;

#[macro_use]
extern crate clap;
#[macro_use]
extern crate log;
#[macro_use]
extern crate quick_error;

#[macro_use]
mod lit;

mod analyze_conflict;
mod cdcl;
mod clause;
mod cli;
mod context;
mod dimacs;
mod lbd;
mod proof;
mod schedule;
mod solver;
mod stats;
mod trit;
mod unchecked;
mod unit_prop;
mod util;
mod vsids;

fn main() {
    cli::main();
}
