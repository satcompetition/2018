use std::cmp::Reverse;
use std::collections::BinaryHeap;

use cdcl::CdclStats;
use clause::Tier;
use context::Context;
use stats::Stats;
use util::keyed::Keyed;
use util::luby::luby_sequence;

pub trait EventAction {
    fn perform_action(self, ctx: &mut Context);
}

pub enum ScheduleEvent {
    Restart,
    ReduceLocals,
    ReduceMids,
    DisplayStats,
}

impl EventAction for ScheduleEvent {
    fn perform_action(self, ctx: &mut Context) {
        match self {
            ScheduleEvent::Restart => {
                ctx.cdcl().restart();
                let next = 128 * luby_sequence(ctx.cdcl_stats.restarts);
                ctx.scheduler()
                    .schedule_conflict(next, ScheduleEvent::Restart);
            }
            ScheduleEvent::ReduceLocals => {
                ctx.clause_assessment().reduce_locals();
                ctx.scheduler()
                    .schedule_conflict(15000, ScheduleEvent::ReduceLocals);
                ctx.clauses.check_collect_garbage(&mut ctx.prop);
            }
            ScheduleEvent::ReduceMids => {
                ctx.clause_assessment().reduce_mids();
                ctx.scheduler()
                    .schedule_conflict(10000, ScheduleEvent::ReduceMids);
                ctx.clauses.check_collect_garbage(&mut ctx.prop);
            }
            ScheduleEvent::DisplayStats => {
                let stats = Stats::new(ctx);
                info!(
                    "restarts: {} conflicts: {} decisions: {} propagations: {}",
                    stats.restarts, stats.conflicts, stats.decisions, stats.propagations
                );
                info!(
                    "free: {}, unit: {} binary: {}, irred: {}, core: {}, mid: {}, local: {}",
                    stats.vars - stats.unit_clauses,
                    stats.unit_clauses,
                    stats.binary_clauses,
                    stats.long_clauses[Tier::Irred as usize],
                    stats.long_clauses[Tier::Core as usize],
                    stats.long_clauses[Tier::Mid as usize],
                    stats.long_clauses[Tier::Local as usize],
                );

                let next = if ctx.cdcl_stats.conflicts < 50000 {
                    5000
                } else {
                    25000
                };
                ctx.scheduler()
                    .schedule_conflict(next, ScheduleEvent::DisplayStats);
            }
        }
    }
}

pub struct Schedule {
    conflict_queue: BinaryHeap<Keyed<Reverse<usize>, ScheduleEvent>>,
}

impl Default for Schedule {
    fn default() -> Schedule {
        Schedule::new()
    }
}

impl Schedule {
    pub fn new() -> Schedule {
        Schedule {
            conflict_queue: BinaryHeap::new(),
        }
    }
}

pub struct Scheduler<'a> {
    pub schedule: &'a mut Schedule,
    pub cdcl_stats: &'a mut CdclStats,
}

impl<'a> Scheduler<'a> {
    pub fn schedule_conflict(&mut self, when: usize, event: ScheduleEvent) {
        let timestamp = self.cdcl_stats.conflicts + when;
        self.schedule.conflict_queue.push(Keyed {
            key: Reverse(timestamp),
            value: event,
        })
    }

    pub fn next_event(&mut self) -> Option<ScheduleEvent> {
        if let Some(next_event) = self.schedule.conflict_queue.peek() {
            if next_event.key.0 <= self.cdcl_stats.conflicts {
                return self.schedule.conflict_queue.pop().map(|keyed| keyed.value);
            }
        }
        None
    }

    pub fn default_schedule(&mut self) {
        self.schedule_conflict(128, ScheduleEvent::Restart);
        self.schedule_conflict(15000, ScheduleEvent::ReduceLocals);
        self.schedule_conflict(10000, ScheduleEvent::ReduceMids);
        self.schedule_conflict(5000, ScheduleEvent::DisplayStats);
    }
}
