use clause::{Tier, TIER_COUNT};
use context::Context;

pub struct Stats {
    pub vars: usize,
    pub propagations: usize,
    pub decisions: usize,
    pub conflicts: usize,
    pub restarts: usize,

    pub unit_clauses: usize,
    pub binary_clauses: usize,
    pub long_clauses: [usize; TIER_COUNT],
}

impl Stats {
    pub fn new(ctx: &Context) -> Stats {
        let mut stats = Stats {
            vars: ctx.var_count,
            propagations: ctx.prop.propagation_count(),
            decisions: ctx.cdcl_stats.decisions,
            conflicts: ctx.cdcl_stats.conflicts,
            restarts: ctx.cdcl_stats.restarts,
            unit_clauses: ctx.prop.toplevel().len(),
            binary_clauses: ctx.prop.binary_clause_count(),
            long_clauses: [0; TIER_COUNT],
        };
        for i in 0..TIER_COUNT {
            stats.long_clauses[i] = ctx.clauses.tier_count(Tier::from_index(i));
        }
        stats
    }
}
