use std::env;
use std::error::Error;
use std::fs;
use std::io;
use std::io::Write;
use std::process;

use clap::App;
use env_logger::{Builder, Formatter, Target};
use log::{Level, LevelFilter, Record};

use dimacs;
use lit::Lit;
use solver::Solver;
use trit::Trit;

quick_error! {
    #[derive(Debug)]
    pub enum CliError {
        Parser(err: dimacs::ParserError) {
            from()
            description("Parser error")
            display("Parser error: {}", err)
            cause(err)
        }
        Io(err: io::Error) {
            from()
            description("IO error")
            display("IO error: {}", err)
            cause(err)
        }
    }
}

pub fn main_with_err() -> Result<(), Box<Error>> {
    let matches = App::new("varisat")
        .version("0.1.0")
        .arg_from_usage("[INPUT] 'The input file to use (stdin if omitted)'")
        .arg_from_usage("-p, --proof-file=[FILE] 'Write a DRAT proof to FILE'")
        .get_matches();

    let format = |buf: &mut Formatter, record: &Record| {
        if record.level() == Level::Info {
            writeln!(buf, "c {}", record.args())
        } else {
            writeln!(buf, "c {}: {}", record.level(), record.args())
        }
    };

    let mut builder = Builder::new();
    builder
        .target(Target::Stdout)
        .format(format)
        .filter(None, LevelFilter::Info);

    if let Ok(ref env_var) = env::var("VARISAT_LOG") {
        builder.parse(env_var);
    }

    builder.init();

    info!("This is varisat {}", "0.1.0");

    let stdin = io::stdin();

    let mut locked_stdin;
    let mut opened_file;

    let mut file = match matches.value_of("INPUT") {
        Some(path) => {
            info!("Reading file '{}'", path);
            opened_file = fs::File::open(path)?;
            &mut opened_file as &mut io::Read
        }
        None => {
            info!("Reading from stdin");
            locked_stdin = stdin.lock();
            &mut locked_stdin as &mut io::Read
        }
    };

    let mut solver = Solver::new();

    if let Some(path) = matches.value_of("proof-file") {
        info!("Writing DRAT proof to file '{}'", path);
        solver.write_proof(fs::File::create(path)?);
    }

    // Parsing input

    let mut buffered = io::BufReader::new(&mut file);
    let mut parser = dimacs::Parser::new();
    let mut counter = 0;

    {
        let callback = &mut |vec: &[Lit]| -> Result<(), CliError> {
            solver.add_clause(vec);
            counter += 1;
            Ok(())
        };
        parser.parse_buf_read(&mut buffered, callback)?;
        parser.eof(callback)?;
    }

    info!("Read {} clauses", counter);

    match solver.solve() {
        Trit::True => {
            println!("s SATISFIABLE");
            print!("v");
            for l in solver.assignments() {
                print!(" {}", l);
            }
            println!(" 0");
            process::exit(10)
        }
        Trit::False => {
            println!("s UNSATISFIABLE");
            process::exit(20)
        }
        Trit::Unk => {
            println!("s UNKNOWN");
            process::exit(0)
        }
    }
}

pub fn main() {
    match main_with_err() {
        Ok(()) => (),
        Err(e) => {
            error!("{}", e);
            process::exit(1)
        }
    }
}
