use std::cmp::min;

use noisy_float::prelude::*;

use clause::Tier;
use lit::{LitIdx, Var};

#[derive(Copy, Clone)]
#[repr(C)]
pub struct ClauseHeader {
    activity: R32,
    data: u32,
    len: LitIdx,
}

const TIER_OFFSET: usize = 0;
const TIER_MASK: u32 = 0b11;

const LBD_OFFSET: usize = 2;
const LBD_MASK: u32 = 0b111111;

const ACTIVE_OFFSET: usize = 8;
const DELETED_OFFSET: usize = 9;
const FLAG_OFFSET: usize = 10;

impl ClauseHeader {
    pub fn new(len: usize) -> ClauseHeader {
        debug_assert!(len >= 3);
        debug_assert!(len <= Var::max_var().index());
        ClauseHeader {
            activity: r32(0.0),
            data: 0,
            len: len as LitIdx,
        }
    }

    pub fn len(&self) -> usize {
        self.len as usize
    }

    pub fn shrink_to(&mut self, len: usize) {
        debug_assert!(len >= 3);
        debug_assert!(self.len as usize >= len);
        self.len = len as LitIdx;
    }

    pub fn activity(&self) -> R32 {
        self.activity
    }

    pub fn set_activity(&mut self, activity: R32) {
        self.activity = activity;
    }

    pub fn tier(&self) -> Tier {
        Tier::from_index(((self.data >> TIER_OFFSET) & TIER_MASK) as usize)
    }

    pub fn set_tier(&mut self, tier: Tier) {
        self.data = (self.data & !(TIER_MASK << TIER_OFFSET)) | ((tier as u32) << TIER_OFFSET);
    }

    pub fn lbd(&self) -> usize {
        ((self.data >> LBD_OFFSET) & LBD_MASK) as usize
    }

    pub fn set_lbd(&mut self, lbd: usize) {
        self.set_small_lbd(min(LBD_MASK as usize, lbd));
    }

    pub fn set_small_lbd(&mut self, lbd: usize) {
        debug_assert!(lbd <= LBD_MASK as usize);
        self.data = (self.data & !(LBD_MASK << LBD_OFFSET)) | ((lbd as u32) << LBD_OFFSET);
    }

    pub fn active(&self) -> bool {
        ((self.data >> ACTIVE_OFFSET) & 1) != 0
    }

    pub fn set_active(&mut self, active: bool) {
        self.data = (self.data & !(1 << ACTIVE_OFFSET)) | ((active as u32) << ACTIVE_OFFSET);
    }

    pub fn deleted(&self) -> bool {
        ((self.data >> DELETED_OFFSET) & 1) != 0
    }

    pub fn set_deleted(&mut self, deleted: bool) {
        self.data = (self.data & !(1 << DELETED_OFFSET)) | ((deleted as u32) << DELETED_OFFSET);
    }

    pub fn flag(&self) -> bool {
        ((self.data >> FLAG_OFFSET) & 1) != 0
    }

    pub fn set_flag(&mut self, flag: bool) {
        self.data = (self.data & !(1 << FLAG_OFFSET)) | ((flag as u32) << FLAG_OFFSET);
    }
}
