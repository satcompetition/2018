use alloc::raw_vec::RawVec;
use std::mem::size_of;
use std::ptr::{copy_nonoverlapping, write};
use std::slice;

use clause::ClauseHeader;
use lit::Lit;

type ClauseIdx = u32;

#[derive(Debug, Copy, Clone, Eq, PartialEq, Ord, PartialOrd)]
pub struct ClauseRef {
    index: ClauseIdx,
}

pub struct ClauseAlloc {
    buffer: RawVec<Lit>,
    size: usize,
}

fn header_size() -> usize {
    (size_of::<ClauseHeader>() + size_of::<Lit>() - 1) / size_of::<Lit>()
}

impl Default for ClauseAlloc {
    fn default() -> ClauseAlloc {
        ClauseAlloc::new()
    }
}

impl ClauseAlloc {
    pub fn new() -> ClauseAlloc {
        ClauseAlloc {
            buffer: RawVec::new(),
            size: 0,
        }
    }

    pub fn add_clause(&mut self, header: ClauseHeader, clause: &[Lit]) -> ClauseRef {
        let old_size = self.size;
        let increment = header_size() + clause.len();
        self.buffer.reserve(self.size, increment);
        self.size += increment;

        let index = old_size + header_size();

        if index > ClauseIdx::max_value() as usize {
            panic!("ClauseRef overflow in ClauseAlloc")
        }

        unsafe {
            let header_ptr = self.buffer.ptr().offset(old_size as isize);
            let lits_ptr = header_ptr.offset(header_size() as isize);
            write(header_ptr as *mut ClauseHeader, header);
            copy_nonoverlapping(clause.as_ptr(), lits_ptr as *mut Lit, clause.len());
        }

        ClauseRef {
            index: index as ClauseIdx,
        }
    }

    fn check_cref(&self, cref: ClauseRef) {
        if cfg!(debug_assertions) {
            let index = cref.index as usize;
            assert!(index >= header_size());
            assert!(index < self.size);
            let offset = unsafe { (*self.header_unsafe(cref)).len() as usize };
            assert!(index + offset <= self.size);
        }
    }

    unsafe fn header_unsafe(&self, cref: ClauseRef) -> *mut ClauseHeader {
        let offset = cref.index as isize - header_size() as isize;
        let header_ptr = self.buffer.ptr().offset(offset);
        header_ptr as *mut ClauseHeader
    }

    pub fn header(&self, cref: ClauseRef) -> &ClauseHeader {
        self.check_cref(cref);
        unsafe { &*self.header_unsafe(cref) }
    }

    pub fn header_mut(&mut self, cref: ClauseRef) -> &mut ClauseHeader {
        self.check_cref(cref);
        unsafe { &mut *self.header_unsafe(cref) }
    }

    unsafe fn lits_ptr_unsafe(&self, cref: ClauseRef) -> *mut Lit {
        self.buffer.ptr().offset(cref.index as isize)
    }

    pub fn lits_ptr(&self, cref: ClauseRef) -> *const Lit {
        self.check_cref(cref);
        unsafe { self.lits_ptr_unsafe(cref) }
    }

    pub fn lits_ptr_mut(&mut self, cref: ClauseRef) -> *mut Lit {
        self.check_cref(cref);
        unsafe { self.lits_ptr_unsafe(cref) }
    }

    unsafe fn lit_unsafe(&self, cref: ClauseRef, offset: usize) -> *mut Lit {
        self.lits_ptr_unsafe(cref).offset(offset as isize)
    }

    pub fn lit(&self, cref: ClauseRef, offset: usize) -> &Lit {
        self.check_cref(cref);
        unsafe { &*self.lit_unsafe(cref, offset) }
    }

    pub fn lit_mut(&mut self, cref: ClauseRef, offset: usize) -> &mut Lit {
        self.check_cref(cref);
        unsafe { &mut *self.lit_unsafe(cref, offset) }
    }

    pub fn lits(&self, cref: ClauseRef) -> &[Lit] {
        unsafe {
            let header = self.header_unsafe(cref);
            let lits_ptr = self.lits_ptr_unsafe(cref);
            slice::from_raw_parts(lits_ptr, (*header).len() as usize)
        }
    }

    pub fn lits_mut(&mut self, cref: ClauseRef) -> &mut [Lit] {
        unsafe {
            let header = self.header_unsafe(cref);
            let lits_ptr = self.lits_ptr_unsafe(cref);
            slice::from_raw_parts_mut(lits_ptr, (*header).len() as usize)
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use noisy_float::prelude::*;

    fn test_clause_123(alloc: &mut ClauseAlloc, cref: ClauseRef) {
        assert_eq!(alloc.header(cref).len(), 4);

        assert_eq!(alloc.lit(cref, 0).to_dimacs(), 1);
        assert_eq!(alloc.lit(cref, 1).to_dimacs(), 2);
        assert_eq!(alloc.lit(cref, 2).to_dimacs(), -3);
        assert_eq!(alloc.lit(cref, 3).to_dimacs(), 4);

        assert_eq!(alloc.lits(cref), lits![1, 2, -3, 4]);

        *alloc.lit_mut(cref, 0) = lit!(-1);
        alloc.header_mut(cref).shrink_to(3);

        assert_eq!(alloc.lits(cref), lits![-1, 2, -3]);

        alloc.header_mut(cref).set_activity(r32(23.42));
        alloc.lits_mut(cref).reverse();

        assert_eq!(alloc.lits(cref), lits![-3, 2, -1]);

        assert_eq!(alloc.lits_ptr(cref), alloc.lits(cref).as_ptr());
        assert_eq!(alloc.lits_ptr_mut(cref), alloc.lits_mut(cref).as_mut_ptr());

        assert_eq!(alloc.header(cref).activity(), r32(23.42));
    }

    fn add_dummy_clauses(alloc: &mut ClauseAlloc, count: usize) {
        let some_lits = lits![4, -5, 6, -7, 8, 9, 10, 11, 12, -13, 14, -15];

        for i in 0..count {
            let len = 3 + i % 10;
            alloc.add_clause(ClauseHeader::new(len), &some_lits[..len]);
        }
    }

    #[test]
    fn single_clause() {
        let mut alloc = ClauseAlloc::new();

        let cref = alloc.add_clause(ClauseHeader::new(4), &lits![1, 2, -3, 4]);

        test_clause_123(&mut alloc, cref);
    }

    #[test]
    fn two_clauses() {
        let mut alloc = ClauseAlloc::new();

        let cref_1 = alloc.add_clause(ClauseHeader::new(4), &lits![1, 2, -3, 4]);
        let cref_2 = alloc.add_clause(ClauseHeader::new(4), &lits![1, 2, -3, 4]);

        test_clause_123(&mut alloc, cref_1);
        test_clause_123(&mut alloc, cref_2);
    }

    #[test]
    fn many_clauses() {
        let mut alloc = ClauseAlloc::new();

        let cref_1 = alloc.add_clause(ClauseHeader::new(4), &lits![1, 2, -3, 4]);

        add_dummy_clauses(&mut alloc, 100);

        let cref_2 = alloc.add_clause(ClauseHeader::new(4), &lits![1, 2, -3, 4]);

        add_dummy_clauses(&mut alloc, 20);

        test_clause_123(&mut alloc, cref_1);

        add_dummy_clauses(&mut alloc, 3000);

        test_clause_123(&mut alloc, cref_2);
    }
}
