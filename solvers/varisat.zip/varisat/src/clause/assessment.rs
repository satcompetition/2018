use clause::{ClauseDb, ClauseHeader, ClauseRef, Tier};
use lbd::compute_lbd;
use lit::Lit;
use proof::Proof;
use unit_prop::UnitProp;

pub struct ClauseAssessment<'a> {
    pub clauses: &'a mut ClauseDb,
    pub prop: &'a mut UnitProp,
    pub flags: &'a mut [bool],
    pub proof: &'a mut Proof,
}

impl<'a> ClauseAssessment<'a> {
    pub fn add_conflict_clause(&mut self, lits: &[Lit]) -> ClauseRef {
        self.clauses.decay_activity();
        let mut header = ClauseHeader::new(lits.len());

        // Resolving the conflict will reduce the LBD by one, but we haven't done that yet.
        // We subtract one to adjust for that.
        let lbd = compute_lbd(self.flags, self.prop, lits) - 1;

        header.set_lbd(lbd);
        header.set_tier(Self::select_tier(lbd));
        header.set_active(true);

        self.clauses.add_clause(Some(&mut self.prop), header, lits)
    }

    pub fn bump_clause(&mut self, cref: ClauseRef) {
        self.clauses.bump_activity(cref);
        let mut new_tier = None;
        {
            let alloc = self.clauses.alloc_mut();
            let lbd = compute_lbd(self.flags, self.prop, alloc.lits(cref));
            let header = alloc.header_mut(cref);

            header.set_active(true);

            if lbd < header.lbd() {
                header.set_small_lbd(lbd);
                if header.tier() != Tier::Irred {
                    new_tier = Some(Self::select_tier(lbd));
                }
            }
        }
        if let Some(tier) = new_tier {
            self.clauses.set_tier(cref, tier);
        }
    }

    pub fn reduce_locals(&mut self) {
        let prop = &mut self.prop;
        let proof = &mut self.proof;
        self.clauses.reduce_tier(Tier::Local, |locals, clauses| {
            locals.sort_unstable_by_key(|&cref| -clauses.alloc().header(cref).activity());

            let mut limit = locals.len() / 2;

            locals.retain(|&cref| {
                clauses.alloc_mut().header_mut(cref).set_flag(false);
                if limit == 0 {
                    if clauses.try_delete(prop, cref) {
                        proof.delete_clause(clauses.alloc().lits(cref));
                        false
                    } else {
                        true
                    }
                } else {
                    limit -= 1;
                    true
                }
            })
        });
    }

    pub fn reduce_mids(&mut self) {
        self.clauses.reduce_tier(Tier::Mid, |mids, clauses| {
            mids.retain(|&cref| {
                clauses.alloc_mut().header_mut(cref).set_flag(false);

                let active = clauses.alloc().header(cref).active();
                if active {
                    clauses.alloc_mut().header_mut(cref).set_active(false);
                    true
                } else {
                    clauses.set_tier(cref, Tier::Local);
                    false
                }
            });
        });
    }

    fn select_tier(lbd: usize) -> Tier {
        if lbd <= 2 {
            Tier::Core
        } else if lbd <= 6 {
            Tier::Mid
        } else {
            Tier::Local
        }
    }
}
