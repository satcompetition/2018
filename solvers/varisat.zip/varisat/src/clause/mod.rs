pub mod alloc;
pub mod header;
pub mod assessment;

use std::mem::{replace, transmute};

use noisy_float::prelude::*;

pub use clause::alloc::{ClauseAlloc, ClauseRef};
pub use clause::header::ClauseHeader;
use lit::Lit;
use unit_prop::{Reason, UnitProp};

#[derive(Debug, Copy, Clone, PartialEq, Eq)]
#[repr(u8)]
pub enum Tier {
    Irred = 0,
    Core = 1,
    Mid = 2,
    Local = 3,
}

pub const TIER_COUNT: usize = 4;

impl Tier {
    pub fn from_index(index: usize) -> Tier {
        debug_assert!(index < TIER_COUNT);
        unsafe { transmute(index as u8) }
    }
}

pub struct ClauseDb {
    alloc: ClauseAlloc,
    clauses: Vec<ClauseRef>,
    by_tier: [Vec<ClauseRef>; TIER_COUNT],
    tier_counts: [usize; TIER_COUNT],
    watchlists_up_to_date: bool,
    bump: R32,
    inv_decay: R32,
    total_size: usize,
    garbage_size: usize,
}

fn rescale_limit() -> R32 {
    r32(f32::max_value() / 16.0)
}

impl Default for ClauseDb {
    fn default() -> ClauseDb {
        ClauseDb::new()
    }
}

impl ClauseDb {
    pub fn new() -> ClauseDb {
        ClauseDb {
            alloc: ClauseAlloc::new(),
            clauses: vec![],
            by_tier: [vec![], vec![], vec![], vec![]],
            tier_counts: [0; TIER_COUNT],
            watchlists_up_to_date: true,
            bump: r32(1.0),
            inv_decay: r32(1.0 / 0.999),
            total_size: 0,
            garbage_size: 0,
        }
    }

    pub fn alloc_mut(&mut self) -> &mut ClauseAlloc {
        &mut self.alloc
    }

    pub fn alloc(&self) -> &ClauseAlloc {
        &self.alloc
    }

    pub fn clauses(&self) -> &[ClauseRef] {
        &self.clauses
    }

    pub fn tier_count(&self, tier: Tier) -> usize {
        self.tier_counts[tier as usize]
    }

    pub fn by_tier_mut(&mut self, tier: Tier) -> &mut Vec<ClauseRef> {
        &mut self.by_tier[tier as usize]
    }

    pub fn add_clause(
        &mut self,
        prop: Option<&mut UnitProp>,
        header: ClauseHeader,
        lits: &[Lit],
    ) -> ClauseRef {
        self.total_size += lits.len() + 3;
        let cref = self.alloc.add_clause(header, lits);

        self.clauses.push(cref);
        self.by_tier[header.tier() as usize].push(cref);
        self.tier_counts[header.tier() as usize] += 1;

        if let Some(prop) = prop {
            if self.watchlists_up_to_date {
                prop.add_watch(cref, [lits[0], lits[1]]);
            }
        } else {
            self.watchlists_up_to_date = false;
        }

        cref
    }

    pub fn add_irred_clause(&mut self, prop: Option<&mut UnitProp>, lits: &[Lit]) -> ClauseRef {
        let mut header = ClauseHeader::new(lits.len());
        header.set_lbd(lits.len() - 1);
        self.add_clause(prop, header, lits)
    }

    pub fn set_tier(&mut self, cref: ClauseRef, tier: Tier) {
        let old_tier = self.alloc.header(cref).tier();
        if old_tier != tier {
            self.tier_counts[old_tier as usize] -= 1;
            self.tier_counts[tier as usize] += 1;

            self.alloc.header_mut(cref).set_tier(tier);
            self.by_tier[tier as usize].push(cref);
        }
    }

    pub fn reduce_tier<F>(&mut self, tier: Tier, mut action: F)
    where
        F: FnMut(&mut Vec<ClauseRef>, &mut ClauseDb),
    {
        let mut tier_clauses = replace(&mut self.by_tier[tier as usize], vec![]);

        {
            let alloc = &mut self.alloc;
            tier_clauses.retain(|&cref| {
                let header = alloc.header_mut(cref);
                let retain = !header.deleted() && !header.flag() && header.tier() == tier;
                if retain {
                    header.set_flag(true);
                }
                retain
            });
        }

        action(&mut tier_clauses, self);

        debug_assert!(!tier_clauses
            .iter()
            .any(|&cref| self.alloc.header(cref).flag()));

        debug_assert!(self.by_tier[tier as usize].is_empty());

        self.by_tier[tier as usize] = tier_clauses;
    }

    pub fn try_delete(&mut self, prop: &mut UnitProp, cref: ClauseRef) -> bool {
        let first_var = self.alloc.lit(cref, 0).var();
        if !prop.is_asserting(cref, first_var) {
            let header = self.alloc.header_mut(cref);
            debug_assert!(!header.deleted());
            header.set_deleted(true);
            self.tier_counts[header.tier() as usize] -= 1;
            self.watchlists_up_to_date = false;
            self.garbage_size += header.len() + 3;
            true
        } else {
            false
        }
    }

    pub fn bump_activity(&mut self, cref: ClauseRef) {
        let rescale = {
            let header = self.alloc.header_mut(cref);
            let value = header.activity() + self.bump;
            header.set_activity(value);
            value > rescale_limit()
        };

        if rescale {
            self.rescale_activities();
        }
    }

    pub fn decay_activity(&mut self) {
        self.bump *= self.inv_decay;
        if self.bump >= rescale_limit() {
            self.rescale_activities();
        }
    }

    fn rescale_activities(&mut self) {
        let rescale_factor = r32(1.0) / rescale_limit();

        let alloc = &mut self.alloc;
        self.clauses.retain(|&cref| {
            let header = alloc.header_mut(cref);
            if !header.deleted() {
                let activity = header.activity();
                header.set_activity(activity * rescale_factor);
                true
            } else {
                false
            }
        });

        self.bump *= rescale_factor;
    }

    pub fn rebuild_watchlists(&mut self) {
        self.watchlists_up_to_date = false;
    }

    pub fn update_watchlists(&mut self, prop: &mut UnitProp) {
        if !self.watchlists_up_to_date {
            prop.clear_watchlists();

            let alloc = &self.alloc;
            self.clauses.retain(|&cref| {
                if !alloc.header(cref).deleted() {
                    let initial = [*alloc.lit(cref, 0), *alloc.lit(cref, 1)];
                    prop.add_watch(cref, initial);
                    true
                } else {
                    false
                }
            });

            self.watchlists_up_to_date = true;
        }
    }

    pub fn check_collect_garbage(&mut self, prop: &mut UnitProp) {
        if self.garbage_size * 2 > self.total_size + 1024 {
            self.collect_garbage(prop);
        }
    }

    pub fn collect_garbage(&mut self, prop: &mut UnitProp) {
        for &lit in prop.trail() {
            if let Reason::Long(cref) = prop.prop_info(lit.var()).reason {
                self.alloc.header_mut(cref).set_flag(true);
            }
        }
        for clauses in &mut self.by_tier {
            clauses.clear();
        }

        {
            let alloc = &self.alloc;
            self.clauses.sort_unstable_by_key(|&cref| {
                let header = alloc.header(cref);
                (header.lbd(), -header.activity())
            });
        }

        let mut new_alloc = ClauseAlloc::new();

        let mut new_clauses = vec![];

        self.total_size = 0;
        self.garbage_size = 0;

        for &cref in &self.clauses {
            let mut header = *self.alloc.header(cref);
            let lits = self.alloc.lits(cref);

            self.total_size += lits.len() + 3;

            let asserting = header.flag();
            header.set_flag(false);

            let new_cref = new_alloc.add_clause(header, lits);

            if asserting {
                prop.update_prop_reason(lits[0].var(), new_cref);
            }

            new_clauses.push(new_cref);
            self.by_tier[header.tier() as usize].push(new_cref);
        }

        self.clauses = new_clauses;
        self.alloc = new_alloc;

        self.watchlists_up_to_date = false;
    }
}
