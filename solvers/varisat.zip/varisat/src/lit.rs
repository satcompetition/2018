use std::fmt;
use std::ops;

pub type LitIdx = u32;

#[derive(Copy, Clone, PartialEq, Eq, PartialOrd, Ord)]
pub struct Var {
    index: LitIdx,
}

impl Var {
    pub fn from_dimacs(number: isize) -> Var {
        debug_assert!(number > 0);
        debug_assert!(number <= Var::max_var().index as isize);
        Var::from_index((number - 1) as usize)
    }

    pub fn from_index(index: usize) -> Var {
        debug_assert!(index <= Var::max_var().index());
        Var {
            index: index as LitIdx,
        }
    }

    pub fn to_dimacs(self) -> isize {
        (self.index + 1) as isize
    }

    pub fn index(self) -> usize {
        self.index as usize
    }

    pub fn max_var() -> Var {
        // Allow for sign or tag bits
        Var {
            index: LitIdx::max_value() >> 4,
        }
    }
}

impl fmt::Debug for Var {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(f, "{}", self.to_dimacs())
    }
}

impl fmt::Display for Var {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        fmt::Debug::fmt(self, f)
    }
}

#[derive(Copy, Clone, PartialEq, Eq, PartialOrd, Ord)]
pub struct Lit {
    code: LitIdx,
}

impl Lit {
    pub fn from_var(var: Var, negative: bool) -> Lit {
        Lit::from_index(var.index, negative)
    }

    pub fn from_index(index: LitIdx, negative: bool) -> Lit {
        debug_assert!(index <= Var::max_var().index);
        Lit {
            code: (index << 1) | (negative as LitIdx),
        }
    }

    pub fn from_dimacs(number: isize) -> Lit {
        Lit::from_var(Var::from_dimacs(number.abs()), number < 0)
    }

    pub fn to_dimacs(self) -> isize {
        let mut number = self.var().to_dimacs();
        if self.is_negative() {
            number = -number
        }
        number
    }

    pub fn index(self) -> usize {
        (self.code >> 1) as usize
    }

    pub fn var(self) -> Var {
        Var {
            index: self.code >> 1,
        }
    }

    pub fn is_negative(self) -> bool {
        (self.code & 1) != 0
    }

    pub fn is_positive(self) -> bool {
        !self.is_negative()
    }

    pub fn code(self) -> usize {
        self.code as usize
    }
}

impl ops::Not for Lit {
    type Output = Lit;
    fn not(self) -> Lit {
        Lit {
            code: self.code ^ 1,
        }
    }
}

impl fmt::Debug for Lit {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(f, "{}", self.to_dimacs())
    }
}

impl fmt::Display for Lit {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        fmt::Debug::fmt(self, f)
    }
}

#[cfg(test)]
macro_rules! lit {
    ( $x:expr ) => (Lit::from_dimacs($x))
}

#[cfg(test)]
macro_rules! var {
    ( $x:expr ) => (Var::from_dimacs($x))
}

#[cfg(test)]
macro_rules! lits {
    ( $( $x:expr ),* ) => { [ $( lit!( $x ) ),* ] };
    ( $( $x:expr ),* , ) => { lits! [ $( $ x),* ] };
}

#[cfg(test)]
macro_rules! vars {
    ( $( $x:expr ),* ) => { [ $( var!( $x ) ),* ] };
    ( $( $x:expr ),* , ) => { vars! [ $( $ x),* ] };
}

#[cfg(test)]
macro_rules! cnf {
    ( $( $( $x:expr ),+ );* ) => { [ $( &[ $( lit!( $x ) ),* ] ),* ] };
    ( $( $( $x:expr ),+ );* ; ) => { [ $( &[ $( lit!( $x ) ),* ] ),* ] };
}
