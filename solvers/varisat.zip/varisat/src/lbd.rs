use lit::Lit;
use unchecked::*;
use unit_prop::UnitProp;

pub fn compute_lbd(flags: &mut [bool], prop: &mut UnitProp, lits: &[Lit]) -> usize {
    debug_assert!(!flags.iter().any(|&x| x));

    let mut lbd = 0;
    for &lit in lits {
        let level = prop.prop_info(lit.var()).level as usize;
        let flag = &mut flags.unchecked_mut()[level];
        if !*flag {
            *flag = true;
            lbd += 1;
        }
    }
    for &lit in lits {
        let level = prop.prop_info(lit.var()).level as usize;
        flags.unchecked_mut()[level] = false;
    }
    lbd
}

#[cfg(test)]
mod tests {
    use super::*;
    use analyze_conflict::AnalyzeConflict;
    use clause::ClauseAlloc;
    use unit_prop::tests::load_clauses;

    #[test]
    fn unique_levels() {
        let mut uprop = UnitProp::new();
        let mut ca = ClauseAlloc::new();
        let mut analyze = AnalyzeConflict::new();
        let mut flags = vec![];

        uprop.set_var_count(6);
        analyze.set_var_count(6);
        flags.resize(6, false);

        load_clauses(
            &mut uprop,
            &mut ca,
            &cnf![
                -1, 2;
                -3, 4;
                -5, 6;
                -2, -4, -5, -6;
            ],
        );

        uprop.next_level();
        uprop.assign_lit(lit!(1));

        assert!(uprop.propagate(&mut ca).is_ok());

        uprop.next_level();
        uprop.assign_lit(lit!(3));

        assert!(uprop.propagate(&mut ca).is_ok());

        uprop.next_level();
        uprop.assign_lit(lit!(5));

        let conflict = uprop.propagate(&mut ca).expect_err("conflict expected");

        let analysis = analyze.analyze(&ca, &uprop, conflict);

        let lbd = compute_lbd(&mut flags, &mut uprop, analysis.lits);

        assert_eq!(analysis.lits.len(), 3);
        assert_eq!(lbd, 3);
    }

    #[test]
    fn shared_levels() {
        let mut uprop = UnitProp::new();
        let mut ca = ClauseAlloc::new();
        let mut analyze = AnalyzeConflict::new();
        let mut flags = vec![];

        uprop.set_var_count(6);
        analyze.set_var_count(6);
        flags.resize(6, false);

        load_clauses(
            &mut uprop,
            &mut ca,
            &cnf![
                -1, 2;
                -1, 4;
                -5, 6;
                -2, -4, -5, -6;
            ],
        );

        uprop.next_level();
        uprop.assign_lit(lit!(1));

        assert!(uprop.propagate(&mut ca).is_ok());

        uprop.next_level();
        uprop.assign_lit(lit!(3));

        assert!(uprop.propagate(&mut ca).is_ok());

        uprop.next_level();
        uprop.assign_lit(lit!(5));

        let conflict = uprop.propagate(&mut ca).expect_err("conflict expected");

        let analysis = analyze.analyze(&ca, &uprop, conflict);

        let lbd = compute_lbd(&mut flags, &mut uprop, analysis.lits);

        assert_eq!(analysis.lits.len(), 3);
        assert_eq!(lbd, 2);
    }
}
