pub fn luby_sequence(i: usize) -> usize {
    fn recursion(i: usize) -> usize {
        if i.is_power_of_two() {
            i >> 1
        } else {
            let k_pow = i.next_power_of_two() >> 1;
            recursion(i - k_pow + 1)
        }
    }
    recursion(i + 2)
}
