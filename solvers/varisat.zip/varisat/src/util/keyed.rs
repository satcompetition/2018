use std::cmp::Ordering;

pub struct Keyed<K, V> {
    pub key: K,
    pub value: V,
}

impl<K: PartialEq, V> PartialEq for Keyed<K, V> {
    fn eq(&self, other: &Keyed<K, V>) -> bool {
        self.key == other.key
    }

    fn ne(&self, other: &Keyed<K, V>) -> bool {
        self.key != other.key
    }
}

impl<K: PartialOrd, V> PartialOrd for Keyed<K, V> {
    fn partial_cmp(&self, other: &Keyed<K, V>) -> Option<Ordering> {
        self.key.partial_cmp(&other.key)
    }

    fn lt(&self, other: &Keyed<K, V>) -> bool {
        self.key.lt(&other.key)
    }

    fn le(&self, other: &Keyed<K, V>) -> bool {
        self.key.le(&other.key)
    }

    fn gt(&self, other: &Keyed<K, V>) -> bool {
        self.key.gt(&other.key)
    }

    fn ge(&self, other: &Keyed<K, V>) -> bool {
        self.key.ge(&other.key)
    }
}

impl<K: Eq, V> Eq for Keyed<K, V> {}

impl<K: Ord, V> Ord for Keyed<K, V> {
    fn cmp(&self, other: &Keyed<K, V>) -> Ordering {
        self.key.cmp(&other.key)
    }
}
