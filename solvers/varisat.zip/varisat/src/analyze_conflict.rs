use std::cmp::max;
use std::mem::replace;

use clause::{ClauseAlloc, ClauseRef};
use lit::{Lit, Var};
use unchecked::*;
use unit_prop::{Conflict, Reason, UnitProp};

#[derive(Debug)]
pub struct Analysis<'a> {
    pub lits: &'a [Lit],
    pub backtrack_to: usize,
    pub bump_vars: &'a [Var],
    pub bump_clauses: &'a [ClauseRef],
}

struct LevelAbstraction {
    bits: u64,
}

impl Default for LevelAbstraction {
    fn default() -> LevelAbstraction {
        LevelAbstraction::new()
    }
}

impl LevelAbstraction {
    pub fn new() -> LevelAbstraction {
        LevelAbstraction { bits: 0 }
    }

    pub fn add(&mut self, level: u32) {
        self.bits |= 1 << (level % 64)
    }

    pub fn test(&self, level: u32) -> bool {
        self.bits & (1 << (level % 64)) != 0
    }
}

pub struct AnalyzeConflict {
    clause: Vec<Lit>,
    current_level_count: usize,
    var_flags: Vec<bool>,
    to_clean: Vec<Var>,
    bump_vars: Vec<Var>,
    bump_clauses: Vec<ClauseRef>,
    backtrack_to: usize,
    stack: Vec<Lit>,
}

impl Default for AnalyzeConflict {
    fn default() -> AnalyzeConflict {
        AnalyzeConflict::new()
    }
}

impl AnalyzeConflict {
    pub fn new() -> AnalyzeConflict {
        AnalyzeConflict {
            clause: vec![],
            current_level_count: 0,
            var_flags: vec![],
            to_clean: vec![],
            bump_clauses: vec![],
            bump_vars: vec![],
            backtrack_to: 0,
            stack: vec![],
        }
    }

    pub fn set_var_count(&mut self, count: usize) {
        self.var_flags.resize(count, false);
    }

    pub fn analyze(
        &mut self,
        clauses: &ClauseAlloc,
        prop: &UnitProp,
        conflict: Conflict,
    ) -> Analysis {
        self.clause.clear();
        self.bump_vars.clear();
        self.bump_clauses.clear();

        self.backtrack_to = 0;

        // self.var_flags + self.clause represent the currently resolved clause

        // Start with conflict clause
        for &lit in conflict.lits(clauses) {
            self.add_literal(prop, lit);
        }

        if let Conflict::Long(cref) = conflict {
            self.bump_clauses.push(cref)
        }

        // Resolve literals of the current clause in the current level with their reason
        for &lit in prop.trail().iter().rev() {
            if self.var_flags.unchecked()[lit.index()] {
                self.var_flags.unchecked_mut()[lit.index()] = false;
                self.current_level_count -= 1;
                if self.current_level_count == 0 {
                    // The learned clause will assert !lit, so move it to index 0
                    self.clause.push(!lit);
                    let end = self.clause.len() - 1;
                    self.clause.swap(0, end);
                    break;
                } else {
                    let reason = prop.prop_info(lit.var()).reason;
                    for &lit in reason.lits(clauses) {
                        self.add_literal(prop, lit);
                    }
                    if let Reason::Long(cref) = reason {
                        self.bump_clauses.push(cref)
                    }
                }
            }
        }

        debug_assert_eq!(self.current_level_count, 0);

        self.minimize_clause(clauses, prop);

        debug_assert!(!self.var_flags.iter().any(|&flag| flag));

        Analysis {
            lits: &self.clause,
            backtrack_to: self.backtrack_to,
            bump_vars: &self.bump_vars,
            bump_clauses: &self.bump_clauses,
        }
    }

    fn add_literal(&mut self, prop: &UnitProp, lit: Lit) {
        let level = prop.prop_info(lit.var()).level as usize;
        if level > 0 && !self.var_flags.unchecked()[lit.index()] {
            self.bump_vars.push(lit.var());
            self.var_flags.unchecked_mut()[lit.index()] = true;
            if level == prop.current_level() {
                self.current_level_count += 1;
            } else {
                self.clause.push(lit);
                self.to_clean.push(lit.var());
                let level = prop.prop_info(lit.var()).level as usize;
                self.backtrack_to = max(self.backtrack_to, level);
            }
        }
    }

    fn minimize_clause(&mut self, clauses: &ClauseAlloc, prop: &UnitProp) {
        let mut involved_levels = LevelAbstraction::new();

        for &lit in &self.clause {
            involved_levels.add(prop.prop_info(lit.var()).level);
        }

        let mut first = true;

        let mut clause = replace(&mut self.clause, vec![]);

        clause.retain(|&lit| {
            if first {
                first = false;
                true
            } else if prop.prop_info(lit.var()).reason == Reason::Assumption {
                true
            } else {
                self.stack.clear();
                self.stack.push(lit);
                let top = self.to_clean.len();
                let mut redundant = true;
                'outer: while let Some(lit) = self.stack.pop() {
                    let reason = prop.prop_info(lit.var()).reason;
                    for &reason_lit in reason.lits(clauses) {
                        let &prop_info = prop.prop_info(reason_lit.var());

                        if !self.var_flags.unchecked()[reason_lit.index()] && prop_info.level > 0 {
                            if prop_info.reason != Reason::Assumption
                                && involved_levels.test(prop_info.level)
                            {
                                self.var_flags.unchecked_mut()[reason_lit.index()] = true;
                                self.to_clean.push(reason_lit.var());
                                self.stack.push(reason_lit);
                            } else {
                                redundant = false;
                                break 'outer;
                            }
                        }
                    }
                }
                if !redundant {
                    for lit in self.to_clean.drain(top..) {
                        self.var_flags.unchecked_mut()[lit.index()] = false;
                    }
                }
                !redundant
            }
        });

        for lit in self.to_clean.drain(..) {
            self.var_flags.unchecked_mut()[lit.index()] = false;
        }

        self.clause = clause;
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use unit_prop::tests::load_clauses;

    fn sorted<T: Clone + Ord>(slice: &[T]) -> Vec<T> {
        let mut result = slice.to_vec();
        result.sort();
        result
    }

    #[test]
    fn simple() {
        let mut uprop = UnitProp::new();
        let mut ca = ClauseAlloc::new();
        let mut analyze = AnalyzeConflict::new();

        uprop.set_var_count(11);
        analyze.set_var_count(11);

        load_clauses(
            &mut uprop,
            &mut ca,
            &cnf![1, 2, 3; -1, -2, -3; -2, 3; 2, -3],
        );

        uprop.next_level();
        uprop.assign_lit(lit!(1));

        assert!(uprop.propagate(&mut ca).is_ok());

        uprop.next_level();
        uprop.assign_lit(lit!(2));

        let conflict = uprop.propagate(&mut ca).expect_err("conflict expected");

        let analysis = analyze.analyze(&ca, &uprop, conflict);

        assert_eq!(analysis.lits, lits![-2, -1]);
        assert_eq!(analysis.backtrack_to, 1);

        assert_eq!(sorted(analysis.bump_vars), vars![1, 2, 3]);

        assert_eq!(analysis.bump_clauses.len(), 1);
        assert_eq!(sorted(ca.lits(analysis.bump_clauses[0])), lits![-1, -2, -3]);
    }

    #[test]
    fn long_clause_as_reason() {
        let mut uprop = UnitProp::new();
        let mut ca = ClauseAlloc::new();
        let mut analyze = AnalyzeConflict::new();

        uprop.set_var_count(14);
        analyze.set_var_count(14);

        load_clauses(
            &mut uprop,
            &mut ca,
            &cnf![
                1, 2, 3, 4;
                1, -2;
                2, -3;
                5, 6, 7, 8;
                5, -6;
                6, -7;
                9, 10, 11;
                9, -10;
                -4, -8, -11, 12;
                -4, -8, -11, -12;
                13, 14;
                13, -14, -1;
            ],
        );

        uprop.next_level();
        uprop.assign_lit(lit!(-1));
        assert!(uprop.propagate(&mut ca).is_ok());

        uprop.next_level();
        uprop.assign_lit(lit!(-5));
        assert!(uprop.propagate(&mut ca).is_ok());

        uprop.next_level();
        uprop.assign_lit(lit!(-13));
        assert!(uprop.propagate(&mut ca).is_ok());

        uprop.next_level();
        uprop.assign_lit(lit!(-9));

        let conflict = uprop.propagate(&mut ca).expect_err("conflict expected");

        let analysis = analyze.analyze(&ca, &uprop, conflict);

        assert_eq!(analysis.lits, lits![-11, -8, -4]);
        assert_eq!(analysis.backtrack_to, 2);
    }

    #[test]
    fn minimize() {
        let mut uprop = UnitProp::new();
        let mut ca = ClauseAlloc::new();
        let mut analyze = AnalyzeConflict::new();

        uprop.set_var_count(14);
        analyze.set_var_count(14);

        load_clauses(
            &mut uprop,
            &mut ca,
            &cnf![
                1, 2, 3, 4;
                1, -2;
                2, -3;
                -4, 6, 7, 8;
                -4, -6;
                6, -7;
                9, 10, 11;
                9, -10;
                -4, -8, -11, 12;
                -4, -8, -11, -12;
                13, 14;
                13, -14, -1;
            ],
        );

        uprop.next_level();
        uprop.assign_lit(lit!(-1));
        assert!(uprop.propagate(&mut ca).is_ok());

        uprop.next_level();
        uprop.assign_lit(lit!(-13));
        assert!(uprop.propagate(&mut ca).is_ok());

        uprop.next_level();
        uprop.assign_lit(lit!(-9));

        let conflict = uprop.propagate(&mut ca).expect_err("conflict expected");

        let analysis = analyze.analyze(&ca, &uprop, conflict);

        assert_eq!(analysis.lits, lits![-11, -4]);
        assert_eq!(analysis.backtrack_to, 1);
    }
}
