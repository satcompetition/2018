use std::io;

use lit::*;

quick_error! {
    #[derive(Debug, Clone)]
    pub enum ParserError {
        UnexpectedInput(unexpected: u8) {
            display("Unexpected character in DIMACS CNF input: '{}'",
                *unexpected as char)
        }
        LiteralTooLarge(number: isize) {
            display("Literal number is too large: {}...", number)
        }
    }
}

pub struct Parser {
    clause: Vec<Lit>,
    number: isize,
    in_number: bool,
    negative: bool,
    in_comment: bool,
    start_of_line: bool,
    error: Option<ParserError>,
}

impl Default for Parser {
    fn default() -> Parser {
        Parser::new()
    }
}

impl Parser {
    pub fn new() -> Parser {
        Parser {
            clause: Vec::new(),
            number: 0,
            in_number: false,
            negative: false,
            in_comment: false,
            start_of_line: true,
            error: None,
        }
    }

   pub fn parse_chunk<F, E>(&mut self, chunk: &[u8], callback: &mut F) -> Result<(), E>
    where
        F: FnMut(&[Lit]) -> Result<(), E>,
        E: From<ParserError>,
    {
        if let Some(ref err) = self.error {
            return Err(err.clone().into());
        }
        for c in chunk {
            match *c {
                b'\n' | b'\r' if self.in_comment => {
                    self.in_comment = false;
                    self.start_of_line = true
                }
                _ if self.in_comment => {
                    // comment
                }
                b'0'...b'9' => {
                    self.in_number = true;
                    self.number = self.number * 10 + (*c - b'0') as isize;
                    if self.number >= Var::max_var().index() as isize {
                        let err = ParserError::LiteralTooLarge(self.number);
                        self.error = Some(err.clone());
                        return Err(err.into());
                    }
                    self.start_of_line = false
                }
                b' ' => {
                    self.add_literal(callback)?;
                    self.negative = false;
                    self.in_number = false;
                    self.number = 0;
                    self.start_of_line = false
                }
                b'-' if !self.negative && !self.in_number => {
                    self.negative = true;
                    self.start_of_line = false
                }
                b'\n' | b'\r' => {
                    self.add_literal(callback)?;
                    self.negative = false;
                    self.in_number = false;
                    self.number = 0;
                    self.complete_clause(callback)?;
                    self.start_of_line = true
                }
                b'c' | b'p' | b's' if self.start_of_line => self.in_comment = true,
                b'v' if self.start_of_line => self.start_of_line = false,
                c => {
                    let err = ParserError::UnexpectedInput(c);
                    self.error = Some(err.clone());
                    return Err(err.into());
                }
            }
        }
        Ok(())
    }

    pub fn eof<F, E>(&mut self, callback: &mut F) -> Result<(), E>
    where
        F: FnMut(&[Lit]) -> Result<(), E>,
    {
        self.add_literal(callback)?;
        self.complete_clause(callback)
    }

    fn add_literal<F, E>(&mut self, callback: &mut F) -> Result<(), E>
    where
        F: FnMut(&[Lit]) -> Result<(), E>,
    {
        if self.in_number {
            if self.number == 0 {
                self.complete_clause(callback)?
            } else {
                if self.negative {
                    self.number = -self.number;
                }
                self.clause.push(Lit::from_dimacs(self.number));
            }
        }
        Ok(())
    }

    fn complete_clause<F, E>(&mut self, callback: &mut F) -> Result<(), E>
    where
        F: FnMut(&[Lit]) -> Result<(), E>,
    {
        if !self.clause.is_empty() {
            callback(&self.clause)?;
            self.clause.clear()
        }
        Ok(())
    }

    pub fn parse_buf_read<R, F, E>(&mut self, read: &mut R, callback: &mut F) -> Result<(), E>
    where
        R: io::BufRead,
        F: FnMut(&[Lit]) -> Result<(), E>,
        E: From<io::Error> + From<ParserError>,
    {
        loop {
            let len = {
                let buf = read.fill_buf()?;
                if buf.is_empty() {
                    break;
                }
                self.parse_chunk(buf, callback)?;
                buf.len()
            };
            read.consume(len);
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn conforming() {
        let cnf = "c comment
c more comment
p cnf 3 3
1 -2 3 0
-1 0
2 0
";
        let mut parser = Parser::new();

        let mut clauses = vec![];

        {
            let mut parse = || {
                let cb = &mut |clause: &[Lit]| -> Result<(), ParserError> {
                    clauses.push(clause.to_vec());
                    Ok(())
                };

                for chunk in cnf.as_bytes().chunks(7) {
                    parser.parse_chunk(chunk, cb)?
                }
                parser.eof(cb)
            };
            assert!(parse().is_ok());
        }

        let expected: &[&[Lit]] = &cnf![
            1, -2, 3;
            -1;
            2;
        ];

        assert_eq!(clauses, expected);
    }

    #[test]
    fn short() {
        let cnf = "1 -2 3\n-1\n2";
        let mut parser = Parser::new();

        let mut clauses = vec![];

        {
            let mut parse = || {
                let cb = &mut |clause: &[Lit]| -> Result<(), ParserError> {
                    clauses.push(clause.to_vec());
                    Ok(())
                };

                for chunk in cnf.as_bytes().chunks(7) {
                    parser.parse_chunk(chunk, cb)?
                }
                parser.eof(cb)
            };
            assert!(parse().is_ok());
        }

        let expected: &[&[Lit]] = &cnf![
            1, -2, 3;
            -1;
            2;
        ];

        assert_eq!(clauses, expected);
    }

    #[test]
    fn unexpected() {
        let cnf = "1 -2 3\n-1\n2fail\n4";
        let mut parser = Parser::new();

        let mut parse = || {
            let cb = &mut |_: &[Lit]| -> Result<(), ParserError> { Ok(()) };

            for chunk in cnf.as_bytes().chunks(7) {
                parser.parse_chunk(chunk, cb)?
            }
            parser.eof(cb)
        };
        match parse() {
            Err(ParserError::UnexpectedInput(b'f')) => (),
            x => panic!("incorrect error {:?}", x),
        }
    }

    #[test]
    fn too_large() {
        let cnf = "1 -2 3\n-1\n-18446744073709551619\n4";
        let mut parser = Parser::new();

        let mut parse = || {
            let cb = &mut |_: &[Lit]| -> Result<(), ParserError> { Ok(()) };

            for chunk in cnf.as_bytes().chunks(7) {
                parser.parse_chunk(chunk, cb)?
            }
            parser.eof(cb)
        };
        match parse() {
            Err(ParserError::LiteralTooLarge(_)) => (),
            x => panic!("incorrect error {:?}", x),
        }
    }
}
