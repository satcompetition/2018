use analyze_conflict::AnalyzeConflict;
use cdcl::{Cdcl, CdclStats};
use clause::ClauseDb;
use clause::assessment::ClauseAssessment;
use proof::Proof;
use schedule::{Schedule, Scheduler};
use unit_prop::UnitProp;
use vsids::Vsids;

#[derive(Default)]
pub struct Context {
    pub var_count: usize,
    pub clauses: ClauseDb,
    pub prop: UnitProp,
    pub analyze: AnalyzeConflict,
    pub vsids: Vsids,
    pub cdcl_stats: CdclStats,
    pub flags: Vec<bool>,
    pub proof: Proof,
    pub schedule: Schedule,
}

impl Context {
    pub fn new() -> Context {
        Context::default()
    }

    pub fn cdcl(&mut self) -> Cdcl {
        Cdcl {
            clauses: &mut self.clauses,
            prop: &mut self.prop,
            analyze: &mut self.analyze,
            vsids: &mut self.vsids,
            stats: &mut self.cdcl_stats,
            flags: &mut self.flags,
            proof: &mut self.proof,
        }
    }

    pub fn clause_assessment(&mut self) -> ClauseAssessment {
        ClauseAssessment {
            clauses: &mut self.clauses,
            prop: &mut self.prop,
            flags: &mut self.flags,
            proof: &mut self.proof,
        }
    }

    pub fn scheduler(&mut self) -> Scheduler {
        Scheduler {
            schedule: &mut self.schedule,
            cdcl_stats: &mut self.cdcl_stats,
        }
    }

    pub fn set_var_count(&mut self, count: usize) {
        self.var_count = count;
        self.prop.set_var_count(count);
        self.analyze.set_var_count(count);
        self.vsids.set_var_count(count);
        self.flags.resize(count, false);
    }
}
