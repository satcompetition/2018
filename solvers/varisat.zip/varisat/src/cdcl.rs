use analyze_conflict::AnalyzeConflict;
use clause::ClauseDb;
use clause::assessment::ClauseAssessment;
use lit::Lit;
use proof::Proof;
use trit::Trit;
use unit_prop::{Conflict, Reason, UnitProp};
use vsids::Vsids;

pub struct CdclStats {
    pub decisions: usize,
    pub conflicts: usize,
    pub restarts: usize,
}

impl Default for CdclStats {
    fn default() -> CdclStats {
        CdclStats::new()
    }
}

impl CdclStats {
    pub fn new() -> CdclStats {
        CdclStats {
            decisions: 0,
            conflicts: 0,
            restarts: 0,
        }
    }
}

pub struct Cdcl<'a> {
    pub clauses: &'a mut ClauseDb,
    pub prop: &'a mut UnitProp,
    pub analyze: &'a mut AnalyzeConflict,
    pub vsids: &'a mut Vsids,
    pub stats: &'a mut CdclStats,
    pub flags: &'a mut [bool],
    pub proof: &'a mut Proof,
}

macro_rules! assessment {
    ($x:expr) => {
        ClauseAssessment {
            clauses: $x.clauses,
            prop: $x.prop,
            flags: $x.flags,
            proof: $x.proof,
        }
    }
}

impl<'a> Cdcl<'a> {
    pub fn restart(&mut self) {
        if self.prop.current_level() > 0 {
            self.stats.restarts += 1;
            Self::backtrack(&mut self.prop, &mut self.vsids, 0);
        }
    }

    fn backtrack(prop: &mut UnitProp, vsids: &mut Vsids, level: usize) {
        prop.backtrack(level, |lits| {
            for &lit in lits {
                vsids.make_available(lit.var());
            }
        });
    }

    pub fn conflict_step(&mut self) -> Trit {
        let conflict = match self.find_conflict() {
            Ok(()) => return Trit::True,
            Err(conflict) => conflict,
        };

        self.stats.conflicts += 1;

        let analyzed = self.analyze
            .analyze(self.clauses.alloc_mut(), self.prop, conflict);

        if analyzed.lits.is_empty() {
            return Trit::False;
        }

        for &var in analyzed.bump_vars {
            self.vsids.bump(var);
        }
        self.vsids.decay();

        for &cref in analyzed.bump_clauses {
            assessment!(self).bump_clause(cref);
        }

        Self::backtrack(&mut self.prop, &mut self.vsids, analyzed.backtrack_to);

        let mut reason = Reason::Assumption;

        self.proof.add_clause(&analyzed.lits);

        if analyzed.lits.len() == 2 {
            self.prop.add_binary([analyzed.lits[0], analyzed.lits[1]]);
            reason = Reason::Binary([analyzed.lits[1]]);
        } else if analyzed.lits.len() >= 3 {
            let cref = assessment!(self).add_conflict_clause(analyzed.lits);
            reason = Reason::Long(cref);
        }

        self.prop.assign_lit_reason(analyzed.lits[0], reason);

        Trit::Unk
    }

    fn find_conflict(&mut self) -> Result<(), Conflict> {
        loop {
            self.clauses.update_watchlists(&mut self.prop);
            self.prop.propagate(self.clauses.alloc_mut())?;

            let var = {
                let prop = &self.prop;
                match self.vsids
                    .pop_available_filtered(|var| prop.var_value(var) == Trit::Unk)
                {
                    Some(var) => var,
                    None => return Ok(()),
                }
            };

            self.stats.decisions += 1;

            let lit = Lit::from_var(var, self.prop.saved_var_value(var) == Trit::False);

            self.prop.next_level();
            self.prop.assign_lit(lit);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use context::Context;
    use unit_prop::tests::load_clauses;

    #[test]
    fn unsat() {
        let mut ctx = Context::new();
        ctx.set_var_count(5);

        load_clauses(
            &mut ctx.prop,
            ctx.clauses.alloc_mut(),
            &cnf![
                -1, -2, -3;
                -1, -2, -4;
                -1, -2, -5;
                -1, -3, -4;
                -1, -3, -5;
                -1, -4, -5;
                -2, -3, -4;
                -2, -3, -5;
                -2, -4, -5;
                -3, -4, -5;
                1, 2, 5;
                1, 2, 3;
                1, 2, 4;
                1, 5, 3;
                1, 5, 4;
                1, 3, 4;
                2, 5, 3;
                2, 5, 4;
                2, 3, 4;
                5, 3, 4;
            ],
        );

        let mut cdcl = ctx.cdcl();

        let mut state = Trit::Unk;

        for _ in 0..10 {
            state = cdcl.conflict_step();
            if state != Trit::Unk {
                break;
            }
        }
        assert_eq!(state, Trit::False);
    }

    #[test]
    fn sat() {
        let mut ctx = Context::new();
        ctx.set_var_count(15);

        load_clauses(
            &mut ctx.prop,
            ctx.clauses.alloc_mut(),
            &cnf![
                -1, -2;
                -1, -3;
                -1, -4;
                -1, -5;
                -2, -3;
                -2, -4;
                -2, -5;
                -3, -4;
                -3, -5;
                -4, -5;
                -6, -7;
                -6, -8;
                -6, -9;
                -6, -10;
                -7, -8;
                -7, -9;
                -7, -10;
                -8, -9;
                -8, -10;
                -9, -10;
                -11, -12;
                -11, -13;
                -11, -14;
                -11, -15;
                -12, -13;
                -12, -14;
                -12, -15;
                -13, -14;
                -13, -15;
                -14, -15;
                1, 15, 3, 11, 7;
                14, 13, 8, 4, 10;
                5, 12, 2, 9, 6;
                6, 2, 3, 10, 13;
                14, 15, 8, 1, 9;
                11, 12, 4, 7, 5;
            ],
        );

        let mut cdcl = ctx.cdcl();

        let mut state = Trit::Unk;

        for _ in 0..10 {
            state = cdcl.conflict_step();
            if state != Trit::Unk {
                break;
            }
        }
        assert_eq!(state, Trit::True);
    }
}
