use std::mem;
use std::ops;

#[allow(dead_code)]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[repr(u8)]
pub enum Trit {
    False = 0,
    True = 1,
    Unk = 3,
}

impl From<bool> for Trit {
    fn from(value: bool) -> Trit {
        // Safe because of explicit repr and bool range
        unsafe { mem::transmute(value as u8) }
    }
}

impl PartialEq<bool> for Trit {
    fn eq(&self, other: &bool) -> bool {
        *self == Trit::from(*other)
    }
}

impl ops::BitXor<bool> for Trit {
    type Output = Trit;

    fn bitxor(self, other: bool) -> Trit {
        // This rather ugly bit twiddeling makes sure no branches are involved
        unsafe {
            let val: u8 = mem::transmute(self); // in 0, 1, 3
            let mut res = val ^ (other as u8); // in 0, 1, 2, 3
            res |= val >> 1; // in 0, 1, 3
            mem::transmute(res)
        }
    }
}
