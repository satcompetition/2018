pub type c_char = u8;

pub const SYS_perf_event_open: ::c_long = 319;
