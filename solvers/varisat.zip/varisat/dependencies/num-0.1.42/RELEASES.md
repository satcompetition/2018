# Release 0.1.42

- [All of the num sub-crates now have their own source repositories][num-356].
- Updated num sub-crates to their latest versions.

**Contributors**: @cuviper

[num-356]: https://github.com/rust-num/num/pull/356


# Prior releases

No prior release notes were kept.  Thanks all the same to the many
contributors that have made this crate what it is!
